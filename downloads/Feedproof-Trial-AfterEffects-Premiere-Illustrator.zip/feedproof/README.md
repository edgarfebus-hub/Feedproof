# Feedproof

© 2026 Edgar Febus. All rights reserved. See LICENSE.txt. — Meta, TikTok, YouTube & LinkedIn safe zones for After Effects, Premiere Pro, Photoshop and Illustrator

*Formerly “Safe Zones”. The installer removes the old panel.*

One panel, four apps. Pick a platform and aspect ratio, see the safe zone live,
then build a comp / sequence / document at the deliverable size with the zones
as **guides**, a **mask layer**, or **both** — one at a time or as a batch.

## Install

1. Quit your Adobe apps.
2. **Mac:** double-click `install/install-mac.command`
   (first time: right-click → Open, because it's an unsigned script).
   **Windows:** double-click `install/install-win.bat`.
3. Open the app → **Window ▸ Extensions ▸ Feedproof**
   (After Effects / Premiere may list it under *Extensions (Legacy)*).

The installer copies the panel into Adobe's CEP extensions folder and turns on
`PlayerDebugMode`, which Adobe requires for extensions that aren't signed and
distributed through the Exchange.

## What each app builds

| App | New … | Guides | Mask layer |
|---|---|---|---|
| After Effects | Comp (size, fps, duration) in a "Safe Zones" folder | Comp ruler guides (AE 2020+) | Locked **guide layer** shape layer — visible while you work, never renders |
| Photoshop | 72-ppi RGB document | Ruler guides | Locked group *"SAFE ZONES … (hide before export)"* |
| Illustrator | Document, or one document with an artboard per deliverable | Real guides | Locked, **non-printing** layer |
| Premiere Pro | Sequence at the deliverable size and frame rate | Drawn into the overlay PNG | Transparent PNG on the top track, track locked |

**Add to Active** reads the open comp / document / artboard / sequence size and
drops the matching overlay on it. **Show / hide overlays** toggles it — in
Premiere it disables the overlay clip so you can export without deleting it.
**Export PNG** saves a transparent overlay to `Documents/Feedproof/Overlays`
for any other tool (Resolve, CapCut, Avid).

**Crop guides** draw centred 4:5 / 1:1 / 9:16 / 16:9 crops inside the frame,
so key visuals survive when the same master is re-cropped for other placements.

**Deliverables batch** works like Overlord's artboard-to-comp flow: add sizes
(or a preset set — Meta, TikTok, YouTube or LinkedIn core, cross-platform masters, Meta 1440)
and create them all in one click.

## Spec sources (checked October 21, 2026)

| Placement | Keep clear | Status |
|---|---|---|
| Meta Reels + Stories, 9:16 (unified March 2026) | top 14% · bottom 35% · sides 6% | Official |
| Meta Stories only | top 14% · bottom 20% · sides 6% | Official (legacy) |
| Meta Reels with disclaimer | bottom 40% | Official |
| Meta Feed 4:5 / 1:1, in-stream 16:9 | no UI over media — 5% title-safe | Padding only |
| TikTok In-Feed / Spark 9:16 | 160 / 440 / 80 px on 720×1280 + right action rail (x 520–640 from y 560) | Official — verified against template Feed.png |
| TikTok TopView, first 3 s | 160 top / 160 bottom / 80 sides on 720×1280 | Official |
| TikTok 1:1 | 60 / 130 / 60 / 140 px on 640×640 | **Estimate** (Download Card zone) |
| TikTok 16:9 | 10% / 20% / 8% / 15% | **Estimate** — placeholder |
| YouTube Shorts + vertical ads, 9:16 (universal) | 288 / 672 / 48 / 192 px on 1080×1920 (top / bottom / left / right) | Official — Google universal safe zone |
| YouTube Shorts ads — minimum | top 10% · bottom 25% · right 10% | Official (Shorts-only guidance) |
| YouTube 4:5 (Demand Gen) | universal vertical zone mapped onto 4:5 | **Estimate** — Google publishes no 4:5 zone |
| YouTube 1:1 | universal vertical zone mapped onto 1:1 | **Estimate** — Google's square overlay is image-only |
| YouTube 16:9 in-stream + horizontal (universal) | 38 / 387 / 58 / 162 px on 1920×1080 + top-corner notches 496×183 (left) and 479×133 (right) | Official — Google universal safe zone |
| LinkedIn 9:16 (full-screen vertical viewer) | top 10% · bottom 18% · sides 6% | **Estimate** — LinkedIn publishes no safe zone (third-party measurement) |
| LinkedIn 4:5 / 1:1 / 16:9 feed | no UI over media — 5% title-safe; max side 1920 px | Padding only |
| Combined (tick any two or more platforms) | strictest edge of each, rail and notches included; sizes capped at 1920 px when LinkedIn is in the mix | Derived |

All values are stored as percentages in **`js/specs.js`**, so they scale to any
size. When a platform changes its guidance, edit that one file — the preview,
overlays and all four host builders read from it.

The 9:16 TikTok zone was verified pixel-for-pixel against TikTok's
*In-Feed Standard* template (Feed.png). That zip contains only the vertical
template, so the TikTok 1:1 and 16:9 entries remain **estimates**.

## Files

```
CSXS/manifest.xml   panel definition (AE 16+, PR 14+, PS 21+, AI 24+)
index.html          panel UI
css/panel.css
js/specs.js         ← platform specs (edit here)
js/geometry.js      spec → pixel rectangles, guides, crops
js/render.js        preview + PNG overlay drawing
js/main.js          panel logic, batch, host bridge
jsx/host.jsx        ExtendScript builders for AE / PS / AI / PR
install/            Mac + Windows installers
```

## Platform notes

Built on CEP so a single panel runs in all four apps today. Adobe's
announced timeline keeps CEP enabled by default until December 2028; UXP is
public in Premiere and Photoshop now, with After Effects and Illustrator UXP
betas due late 2026 / spring 2027. The spec, geometry and render files are
host-agnostic and carry over unchanged to a UXP version.
