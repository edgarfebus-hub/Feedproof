#!/bin/bash
# Feedproof — macOS installer
# Double-click this file (or run it in Terminal). Quit Adobe apps first.
set -e
SRC="$(cd "$(dirname "$0")/.." && pwd)"
EXT="$HOME/Library/Application Support/Adobe/CEP/extensions"
DEST="$EXT/com.edgarfebus.feedproof"

# Adobe apps keep the old panel in memory — refuse to install while one is open
# Match only the four main app executables, not Adobe's background helpers
RUNNING=$(ps -axo comm= | sed -E 's#.*/##' | grep -E '^(After Effects|Adobe Illustrator|Adobe Premiere Pro( [0-9]{4})?|Adobe Photoshop( [0-9]{4})?)$' | sort -u)
if [ -n "$RUNNING" ]; then
  echo "Please quit these Adobe apps first (⌘Q), then run the install again:"
  echo "$RUNNING" | sed 's/^/  • /'
  exit 1
fi

echo "Installing Feedproof to:"
echo "  $DEST"
mkdir -p "$EXT"
# Feedproof replaces the Safe Zones panel — remove the old copy so only one shows up
if [ -d "$EXT/com.edgarfebus.safezones" ]; then
  rm -rf "$EXT/com.edgarfebus.safezones"
  echo "Removed the old Safe Zones panel."
fi
rm -rf "$DEST"
mkdir -p "$DEST"
cp -R "$SRC/CSXS" "$SRC/css" "$SRC/js" "$SRC/jsx" "$SRC/index.html" "$SRC/LICENSE.txt" "$DEST/"

# Clear Adobe's cached copy of this panel so the new version loads
rm -rf "$HOME/Library/Caches/CSXS/cep_cache/"*safezones* "$HOME/Library/Caches/CSXS/cep_cache/"*feedproof* 2>/dev/null || true

# Allow unsigned extensions (CEP 9–12 cover Adobe apps 2019 → 2026)
for v in 9 10 11 12; do
  defaults write "com.adobe.CSXS.$v" PlayerDebugMode 1
done

echo ""
echo "Done. Open After Effects, Premiere Pro, Photoshop or Illustrator and choose:"
echo "  Window > Extensions > Feedproof"
echo "(In Premiere/AE it may be under Window > Extensions (Legacy).)"
