@echo off
REM Feedproof - Windows installer. Quit Adobe apps first, then double-click.
setlocal
set "SRC=%~dp0.."
set "EXT=%APPDATA%\Adobe\CEP\extensions"
set "DEST=%EXT%\com.edgarfebus.feedproof"

REM Adobe apps keep the old panel in memory - refuse to install while one is open
set "RUNNING="
for %%p in (AfterFX.exe "Adobe Premiere Pro.exe" Illustrator.exe Photoshop.exe) do (
  tasklist /FI "IMAGENAME eq %%~p" 2>nul | find /I "%%~p" >nul && set "RUNNING=1" && echo   Still open: %%~p
)
if defined RUNNING (
  echo.
  echo Please quit the apps listed above, then run this installer again.
  pause
  exit /b 1
)

echo Installing Feedproof to:
echo   %DEST%
REM Feedproof replaces the Safe Zones panel - remove the old copy
if exist "%EXT%\com.edgarfebus.safezones" rmdir /s /q "%EXT%\com.edgarfebus.safezones"
if exist "%DEST%" rmdir /s /q "%DEST%"
mkdir "%DEST%"
xcopy "%SRC%\CSXS" "%DEST%\CSXS\" /e /i /q /y >nul
xcopy "%SRC%\css"  "%DEST%\css\"  /e /i /q /y >nul
xcopy "%SRC%\js"   "%DEST%\js\"   /e /i /q /y >nul
xcopy "%SRC%\jsx"  "%DEST%\jsx\"  /e /i /q /y >nul
copy /y "%SRC%\index.html" "%DEST%\" >nul
copy /y "%SRC%\LICENSE.txt" "%DEST%\" >nul

REM Clear Adobe's cached copy of this panel so the new version loads
for /d %%d in ("%TEMP%\cep_cache\*safezones*" "%TEMP%\cep_cache\*feedproof*") do rmdir /s /q "%%d" 2>nul

REM Allow unsigned extensions (CEP 9-12)
for %%v in (9 10 11 12) do reg add "HKCU\Software\Adobe\CSXS.%%v" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul

echo.
echo Done. Open After Effects, Premiere Pro or Illustrator and choose
echo   Window ^> Extensions ^> Feedproof
echo (In Premiere / After Effects it may be under Window ^> Extensions (Legacy).)
pause
