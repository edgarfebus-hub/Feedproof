/*
 * Feedproof — Meta, TikTok & YouTube safe zones
 * © 2026 Edgar Febus. All rights reserved.
 * https://edgarfebus.com
 */
/*
 * Feedproof — geometry
 * Turns a spec (fractions) into pixel rectangles for a given frame size.
 * Everything downstream (preview, PNG overlay, AE/PS/AI/PR builders)
 * consumes this one structure, so all hosts draw identical zones.
 */
(function (root) {
  function r(n) { return Math.round(n); }

  function ratioValue(str) {
    var p = String(str).split(":");
    return parseFloat(p[0]) / parseFloat(p[1]);
  }

  function clipRect(a, b) {
    var x1 = Math.max(a.x, b.x), y1 = Math.max(a.y, b.y);
    var x2 = Math.min(a.x + a.w, b.x + b.w), y2 = Math.min(a.y + a.h, b.y + b.h);
    if (x2 <= x1 || y2 <= y1) return null;
    return { x: x1, y: y1, w: x2 - x1, h: y2 - y1 };
  }

  function uniq(arr) {
    var seen = {}, out = [];
    for (var i = 0; i < arr.length; i++) {
      var v = arr[i];
      if (!seen[v]) { seen[v] = 1; out.push(v); }
    }
    return out.sort(function (a, b) { return a - b; });
  }

  /**
   * @param spec  spec object from SZSpecs
   * @param W,H   frame size in px
   * @param opts  { crops: ["4:5","1:1",...] }
   */
  function build(spec, W, H, opts) {
    opts = opts || {};
    var m = spec.margins;
    var top = r(m.top * H), bottom = r(m.bottom * H);
    var left = r(m.left * W), right = r(m.right * W);
    var midH = H - top - bottom;

    var safe = { x: left, y: top, w: W - left - right, h: midH };
    var kind = spec.kind;
    var zones = [];

    function push(id, label, x, y, w, h, extra) {
      if (w <= 0 || h <= 0) return;
      zones.push({ id: id, label: label, x: x, y: y, w: w, h: h, kind: kind, extra: !!extra });
    }

    push("top", spec.labels.top, 0, 0, W, top);
    push("bottom", spec.labels.bottom, 0, H - bottom, W, bottom);
    push("left", spec.labels.left, 0, top, left, midH);
    push("right", spec.labels.right, W - right, top, right, midH);

    var gx = [left, W - right], gy = [top, H - bottom];

    (spec.extras || []).forEach(function (e, i) {
      var raw = { x: r(e.x1 * W), y: r(e.y1 * H), w: r((e.x2 - e.x1) * W), h: r((e.y2 - e.y1) * H) };
      var c = clipRect(raw, safe);
      if (!c) return;
      push("extra" + i, e.label, c.x, c.y, c.w, c.h, true);
      // guides on every edge of the blocked area that falls inside the safe area
      if (c.x > safe.x) gx.push(c.x);
      if (c.x + c.w < safe.x + safe.w) gx.push(c.x + c.w);
      if (c.y > safe.y) gy.push(c.y);
      if (c.y + c.h < safe.y + safe.h) gy.push(c.y + c.h);
    });

    // Crop guides — centred crops of other ratios (visual-interest framing)
    var crops = [];
    var R = W / H;
    (opts.crops || []).forEach(function (rs) {
      var t = ratioValue(rs);
      if (Math.abs(t - R) < 0.005) return; // same ratio as frame
      var cw, ch;
      if (t < R) { ch = H; cw = r(H * t); } else { cw = W; ch = r(W / t); }
      crops.push({ ratio: rs, label: rs + " centre crop", x: r((W - cw) / 2), y: r((H - ch) / 2), w: cw, h: ch });
    });

    return {
      W: W, H: H,
      spec: spec.id, kind: kind,
      margins: { top: top, bottom: bottom, left: left, right: right },
      safe: safe,
      zones: zones,
      guidesX: uniq(gx).filter(function (v) { return v > 0 && v < W; }),
      guidesY: uniq(gy).filter(function (v) { return v > 0 && v < H; }),
      crops: crops
    };
  }

  function aspectMatches(spec, W, H) {
    return Math.abs(ratioValue(spec.ratio) - W / H) < 0.01;
  }

  var api = { build: build, ratioValue: ratioValue, aspectMatches: aspectMatches };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.SZGeometry = api;
})(typeof window !== "undefined" ? window : this);
