/*
 * Feedproof — Fix layout planner
 * © 2026 Edgar Febus. All rights reserved.
 * https://edgarfebus.com
 *
 * Pure logic, no DOM and no host calls: every app (AE, Illustrator,
 * Photoshop, InDesign, Figma) sends the same list of layer boxes and gets
 * the same plan back, so the fixes are identical everywhere.
 *
 *   layer = { id, name, kind, x, y, w, h, z, locked, hidden }
 *     kind: "text" | "image" | "smart" | "shape" | "group" | "video" | "precomp" | "other"
 *     x,y,w,h: the layer's visible box in frame pixels (top-left origin)
 *     z: stacking order, 0 = top of the stack
 *
 *   geo = SZGeometry.build(...)  — safe rect + blocked zones for the frame
 *
 *   FPLayout.plan(layers, geo, opts) → {
 *     rows: [{ id, name, kind, box, score, tier, reasons, issue, include,
 *              status: "move" | "scale" | "nofit" | "ok", to, scale, note }],
 *     ignored: { background, hidden, locked, inside }
 *   }
 *   opts: { pins: {id:true}, skips: {id:true}, picks: {id:true|false},
 *           minScale: 0.8, pad: 16 }
 */
(function (root) {
  "use strict";

  // Names that usually mean "this must be seen"
  var KEY_NAMES = /\b(logo|brand|wordmark|lockup|cta|button|btn|shop|buy|order|learn|download|install|sign ?up|subscribe|super|headline|head|title|tagline|claim|price|offer|promo|discount|url|website|web|end ?card|endcard|packshot|pack ?shot|product|hero|subject|talent|face|person|copy|message|key ?message)\b/i;
  // Lines that must stay readable: move them, never shrink them much
  var LEGAL_NAMES = /\b(legal|isi|disclaimer|disclosure|fine ?print|safety|copyright|terms|footnote|super ?legal|rx|boxed ?warning|indication)\b|©|®|™/i;
  // Feedproof's own layers — never touched
  var OWN = /SAFE ZONE|FEEDPROOF/i;

  function area(b) { return Math.max(0, b.w) * Math.max(0, b.h); }
  function inter(a, b) {
    var x1 = Math.max(a.x, b.x), y1 = Math.max(a.y, b.y);
    var x2 = Math.min(a.x + a.w, b.x + b.w), y2 = Math.min(a.y + a.h, b.y + b.h);
    if (x2 <= x1 || y2 <= y1) return null;
    return { x: x1, y: y1, w: x2 - x1, h: y2 - y1 };
  }
  function interArea(a, b) { var i = inter(a, b); return i ? i.w * i.h : 0; }
  function inside(a, b, tol) {
    tol = tol || 0;
    return a.x >= b.x - tol && a.y >= b.y - tol &&
           a.x + a.w <= b.x + b.w + tol && a.y + a.h <= b.y + b.h + tol;
  }
  function inflate(b, p) { return { x: b.x - p, y: b.y - p, w: b.w + 2 * p, h: b.h + 2 * p }; }
  function round(b) { return { x: Math.round(b.x), y: Math.round(b.y), w: Math.round(b.w), h: Math.round(b.h) }; }

  // ── Importance ──────────────────────────────────────────────────────
  // 0–100. Text first, then names that say "logo / CTA / product", then
  // small things sitting on top of the stack. Pins win outright.
  function rank(l, frameArea, count) {
    var s = 0, why = [];
    var nm = String(l.name || "");
    var a = area(l) / frameArea;
    var legal = LEGAL_NAMES.test(nm);
    if (l.kind === "text") { s += 55; why.push("Text"); }
    else if (l.kind === "smart" || l.kind === "image") { s += 30; why.push(l.kind === "smart" ? "Placed graphic" : "Image"); }
    else if (l.kind === "group" || l.kind === "precomp") { s += 30; why.push(l.kind === "precomp" ? "Pre-comp" : "Group"); }
    else if (l.kind === "video") { s += 20; why.push("Video"); }
    else if (l.kind === "shape") { s += 15; why.push("Shape"); }
    else { s += 10; }
    var m = KEY_NAMES.exec(nm);
    if (legal) { s += 30; why.push("Legal / disclaimer"); }
    else if (m) { s += 30; why.push("Named “" + m[1].toLowerCase() + "”"); }
    if (a < 0.25) {
      var top = count > 1 ? 1 - (l.z || 0) / (count - 1) : 1;  // 1 = top of the stack
      var bonus = Math.round(10 * top);
      if (bonus >= 5) { s += bonus; why.push("On top"); }
    }
    s = Math.max(0, Math.min(100, s));
    return { score: s, reasons: why, legal: legal };
  }
  function tierOf(score) { return score >= 70 ? "high" : score >= 40 ? "medium" : "low"; }

  // What the layer crosses, in words: "Bottom UI 84 px"
  function issueOf(box, geo) {
    var parts = [];
    var safe = geo.safe;
    geo.zones.forEach(function (z) {
      var i = inter(box, z);
      if (!i || i.w < 1 || i.h < 1) return;
      var depth;
      if (z.id === "top") depth = i.h;
      else if (z.id === "bottom") depth = i.h;
      else if (z.id === "left" || z.id === "right") depth = i.w;
      else depth = Math.min(i.w, i.h);
      var lab = z.label || z.id, px = Math.round(depth), dup = null;
      for (var q = 0; q < parts.length; q++) if (parts[q].label === lab) dup = parts[q];
      if (dup) dup.px = Math.max(dup.px, px); else parts.push({ label: lab, px: px });
    });
    // off the frame entirely on a side (zones only cover the frame)
    if (box.x < 0 || box.y < 0 || box.x + box.w > geo.W || box.y + box.h > geo.H) {
      if (!parts.length) parts.push({ label: "Off frame", px: 0 });
    }
    if (!parts.length && !inside(box, safe, 0.5)) parts.push({ label: "Edge", px: 0 });
    return parts;
  }

  // ── Placement ───────────────────────────────────────────────────────
  // Try a handful of positions (stay put, slide to each safe edge, slide
  // past each blocked box / neighbour) at shrinking scales; keep the one
  // that moves the layer least without landing on a blocked area.
  function place(l, geo, obstacles, minScale, pad) {
    var safe = geo.safe;
    var D = Math.sqrt(geo.W * geo.W + geo.H * geo.H);
    var blocks = geo.zones.filter(function (z) { return z.extra; }).map(function (z) { return inflate(z, pad); });
    var area0 = { x: safe.x + pad, y: safe.y + pad, w: safe.w - 2 * pad, h: safe.h - 2 * pad };
    var cx = l.x + l.w / 2, cy = l.y + l.h / 2;
    var best = null, steps = [];
    for (var s = 1; s >= minScale - 1e-6; s = Math.round((s - 0.05) * 100) / 100) steps.push(s);
    if (steps[steps.length - 1] > minScale + 1e-6) steps.push(minScale);

    for (var k = 0; k < steps.length; k++) {
      var sc = steps[k], w = l.w * sc, h = l.h * sc;
      if (w > area0.w + 0.5 || h > area0.h + 0.5) continue;
      var x0 = cx - w / 2, y0 = cy - h / 2;
      var xs = [x0, area0.x, area0.x + area0.w - w], ys = [y0, area0.y, area0.y + area0.h - h];
      blocks.forEach(function (b) { xs.push(b.x - w, b.x + b.w); ys.push(b.y - h, b.y + b.h); });
      obstacles.forEach(function (o) { xs.push(o.x - pad - w, o.x + o.w + pad); ys.push(o.y - pad - h, o.y + o.h + pad); });
      for (var i = 0; i < xs.length; i++) {
        for (var j = 0; j < ys.length; j++) {
          var x = Math.min(Math.max(xs[i], area0.x), area0.x + area0.w - w);
          var y = Math.min(Math.max(ys[j], area0.y), area0.y + area0.h - h);
          var c = { x: x, y: y, w: w, h: h };
          var bad = false;
          for (var b = 0; b < blocks.length; b++) if (interArea(c, blocks[b]) > 0.5) { bad = true; break; }
          if (bad) continue;
          var hit = 0;
          for (var o = 0; o < obstacles.length; o++) hit += interArea(c, obstacles[o]);
          var dx = (x + w / 2) - cx, dy = (y + h / 2) - cy;
          var dist = Math.sqrt(dx * dx + dy * dy);
          // cost in "pixels moved": shrinking 20% ≈ moving a tenth of the frame diagonal;
          // covering a neighbour completely ≈ moving more than half of it
          var cost = dist + (1 - sc) * D * 0.5 + (hit > 0 ? 0.03 * D + Math.min(1, hit / area(c)) * D * 0.6 : 0);
          if (!best || cost < best.cost - 0.01) best = { box: c, scale: sc, cost: cost, hit: hit, dist: dist };
        }
      }
    }
    return best;
  }

  function plan(layers, geo, opts) {
    opts = opts || {};
    var pins = opts.pins || {}, skips = opts.skips || {}, picks = opts.picks || {};
    var minScale = Math.max(0.3, Math.min(1, opts.minScale || 0.8));
    var pad = Math.max(0, opts.pad == null ? 0 : +opts.pad || 0);
    var frameArea = geo.W * geo.H;
    var freeBox = geo.safe;
    var blocks = geo.zones.filter(function (z) { return z.extra; });
    var ignored = { background: 0, hidden: 0, locked: 0, inside: 0, own: 0, offFrame: 0 };

    var list = (layers || []).filter(function (l) { return l && l.w > 0 && l.h > 0; });
    var count = list.length;
    var rows = [], keep = [];

    list.forEach(function (l) {
      if (OWN.test(String(l.name || ""))) { ignored.own++; return; }
      if (l.hidden) { ignored.hidden++; return; }
      var box = { x: l.x, y: l.y, w: l.w, h: l.h };
      var vis = inter(box, { x: 0, y: 0, w: geo.W, h: geo.H });
      var bg = (area(box) >= 0.6 * frameArea) || (l.w >= 0.9 * geo.W && l.h >= 0.9 * geo.H);
      if (bg) { ignored.background++; return; }
      var r = rank(l, frameArea, count);
      if (pins[l.id]) { r.score = 100; r.reasons = ["Pinned"].concat(r.reasons); }
      var ok = inside(box, freeBox, 0.5) && !blocks.some(function (b) { var i = inter(box, b); return i && i.w >= 1 && i.h >= 1; });
      if (!vis) { ignored.offFrame++; return; }
      if (ok) { ignored.inside++; keep.push({ box: box, score: r.score }); return; }
      if (l.locked) { ignored.locked++; keep.push({ box: box, score: r.score }); return; }
      rows.push({
        id: l.id, name: l.name || "(unnamed)", kind: l.kind || "other", box: box, z: l.z || 0,
        score: r.score, tier: tierOf(r.score), reasons: r.reasons, legal: r.legal,
        issue: issueOf(box, geo), skipped: !!skips[l.id], pinned: !!pins[l.id]
      });
    });

    rows.sort(function (a, b) { return b.score - a.score || a.z - b.z; });
    rows.forEach(function (r) {
      var def = !r.skipped && r.tier !== "low";
      r.include = Object.prototype.hasOwnProperty.call(picks, r.id) ? (!!picks[r.id] && !r.skipped) : def;
    });

    // Neighbours a moved layer should avoid: everything that stays put and
    // matters (not low-priority), then each layer as it gets placed.
    var obstacles = keep.filter(function (k) { return k.score >= 40; }).map(function (k) { return k.box; });
    rows.forEach(function (r) {
      if (!r.include) { r.status = "skip"; return; }
      var min = minScale;
      var p = place(r.box, geo, obstacles, min, pad);
      if (!p) {
        r.status = "nofit";
        r.note = "Too big for the safe area" + (min < 1 ? " even at " + Math.round(min * 100) + "%" : "");
        r.include = false;
        return;
      }
      r.to = round(p.box);
      r.scale = Math.round(p.scale * 1000) / 1000;
      r.status = r.scale < 0.999 ? "scale" : "move";
      var dx = Math.round((p.box.x + p.box.w / 2) - (r.box.x + r.box.w / 2));
      var dy = Math.round((p.box.y + p.box.h / 2) - (r.box.y + r.box.h / 2));
      r.dx = dx; r.dy = dy;
      var bits = [];
      if (dy) bits.push((dy < 0 ? "↑ " : "↓ ") + Math.abs(dy) + " px");
      if (dx) bits.push((dx < 0 ? "← " : "→ ") + Math.abs(dx) + " px");
      if (r.status === "scale") bits.push("scale " + Math.round(r.scale * 100) + "%");
      r.note = bits.join(" · ") || "nudge";
      if (p.hit > 0) r.note += " · touches another layer";
      obstacles.push(p.box);
    });

    return { rows: rows, ignored: ignored };
  }

  // The jobs a host needs: target box and scale per layer
  function fixes(result) {
    return result.rows.filter(function (r) { return r.include && r.to; }).map(function (r) {
      return { id: r.id, name: r.name, kind: r.kind, from: r.box, to: r.to, scale: r.scale,
               dx: r.dx, dy: r.dy };
    });
  }

  var api = { plan: plan, fixes: fixes, rank: rank, tierOf: tierOf, _inter: inter };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.FPLayout = api;
})(typeof window !== "undefined" ? window : this);
