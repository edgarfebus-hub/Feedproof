/* Generated from feedproof-config/license.json — do not edit by hand.
 * Feedproof © 2026 Edgar Febus. All rights reserved. */
(function (root) { root.FP_LICENSE_CONFIG = {"mode": "trial", "audience": "public", "licensee": "Trial", "slug": "public-trial", "agreementSigned": null, "trialDays": 15, "hardCutoff": "2027-05-03", "reminderDays": 5, "contact": "edgar.febus@gmail.com", "seats": null, "features": {"pngWatermark": true}, "tag": "Trial"}; })(typeof window !== "undefined" ? window : (typeof globalThis !== "undefined" ? globalThis : this));
