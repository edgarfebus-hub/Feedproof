/* Generated — free build, no license screens. Feedproof © 2026 Edgar Febus. All rights reserved. */
(function (root) { root.FP_LICENSE_CONFIG = null; })(typeof window !== "undefined" ? window : (typeof globalThis !== "undefined" ? globalThis : this));
