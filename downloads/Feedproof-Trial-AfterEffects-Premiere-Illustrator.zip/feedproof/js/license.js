/*
 * Feedproof — evaluation / license logic (shared by every host)
 * © 2026 Edgar Febus. All rights reserved.
 * https://edgarfebus.com
 *
 * Pure logic, no DOM: the CEP panel (AE, Premiere, Illustrator), the UXP
 * plugins (Photoshop, InDesign), Figma (UI and main thread) and Acrobat all
 * load this same file, so dates, rules and wording are identical everywhere.
 *
 * Trial rules
 *   - 30 days (config.trialDays) from the first launch on this user account.
 *   - Hard cutoff date (config.hardCutoff): the trial ends then no matter what.
 *   - The first-launch date lives OUTSIDE the plugin's install folder, so
 *     uninstalling / reinstalling doesn't reset it. Several stores are kept
 *     (shared file, app storage); the EARLIEST first launch wins.
 *   - Clock tamper: the latest date seen is stored; a clock set back more
 *     than 2 hours behind it ends the trial (sticky). A later server date
 *     (from the spec-feed response) is used when it's ahead of the clock.
 *   - Offline use before expiry is never blocked.
 *
 * config (generated from the single config file — see license-config.js):
 *   { mode: "trial"|"licensed", licensee, slug, agreementSigned (YYYY-MM-DD),
 *     trialDays, hardCutoff (YYYY-MM-DD), reminderDays, contact, seats }
 */
(function (root) {
  "use strict";

  var DAY = 86400000;
  var TOLERANCE = 2 * 3600000;        // clock jitter allowed before "set back" counts
  var MONTHS = ["January", "February", "March", "April", "May", "June", "July",
                "August", "September", "October", "November", "December"];

  function num(v) { return (typeof v === "number" && isFinite(v) && v > 0) ? v : 0; }

  function parseYMD(s) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(s || ""));
    return m ? { y: +m[1], m: +m[2], d: +m[3] } : null;
  }
  // end of that calendar day, local time
  function endOfDay(s) {
    var p = parseYMD(s);
    return p ? new Date(p.y, p.m - 1, p.d, 23, 59, 59, 999).getTime() : 0;
  }
  function formatDate(ms) {
    var d = new Date(ms);
    return MONTHS[d.getMonth()] + " " + d.getDate() + ", " + d.getFullYear();
  }
  function formatYMD(s) {
    var p = parseYMD(s);
    return p ? formatDate(new Date(p.y, p.m - 1, p.d, 12).getTime()) : "[agreement date]";
  }

  function blank() { return { v: 1, firstLaunch: 0, lastSeen: 0, accepted: 0, tampered: false }; }

  // Combine records from several stores: earliest first launch, latest date seen,
  // acceptance from any store, tamper flag from any store.
  function merge(list) {
    var r = blank();
    for (var i = 0; i < (list || []).length; i++) {
      var x = list[i];
      if (!x || typeof x !== "object") continue;
      var f = num(x.firstLaunch);
      if (f && (!r.firstLaunch || f < r.firstLaunch)) r.firstLaunch = f;
      r.lastSeen = Math.max(r.lastSeen, num(x.lastSeen));
      r.accepted = Math.max(r.accepted, num(x.accepted));
      if (x.tampered === true) r.tampered = true;
    }
    return r;
  }

  function parseRecord(text) {
    try { var o = JSON.parse(text); return (o && typeof o === "object") ? o : null; } catch (e) { return null; }
  }

  // opts.clock: optional function returning "now" in ms (tests; defaults to Date.now)
  function create(cfg, opts) {
    cfg = cfg || {};
    var clock = (opts && typeof opts.clock === "function") ? opts.clock : function () { return Date.now(); };
    var trial = cfg.mode !== "licensed";
    var PUBLIC = cfg.audience === "public";
    var NOUN = PUBLIC ? "trial" : "evaluation";
    var rec = blank();
    var serverAhead = 0;               // ms the server clock is ahead of ours (from the feed)
    var loaded = false;

    function now() { return clock() + serverAhead; }

    function expiryOf(r) {
      var byDays = r.firstLaunch + (cfg.trialDays || 30) * DAY;
      var cut = endOfDay(cfg.hardCutoff);
      return { at: cut ? Math.min(byDays, cut) : byDays, byCutoff: !!cut && cut < byDays };
    }

    // Seen a time: record it, catch a clock that went backwards
    function see(t) {
      if (rec.lastSeen && t < rec.lastSeen - TOLERANCE) rec.tampered = true;
      if (t > rec.lastSeen) rec.lastSeen = t;
    }

    function status() {
      var info = {
        mode: trial ? "trial" : "licensed",
        state: "active", reason: "", expiry: 0, expiryText: "", daysLeft: null,
        reminder: false, accepted: !!rec.accepted, byCutoff: false
      };
      if (!trial) return info;
      var t = now();
      var e = expiryOf(rec);
      info.expiry = e.at;
      info.byCutoff = e.byCutoff;
      info.expiryText = formatDate(e.at);
      info.daysLeft = Math.max(0, Math.ceil((e.at - t) / DAY));
      if (rec.tampered) { info.state = "expired"; info.reason = "clock"; }
      else if (t >= e.at) { info.state = "expired"; info.reason = e.byCutoff ? "cutoff" : "time"; }
      else if (!rec.accepted) info.state = "agree";
      info.reminder = info.state === "active" && info.daysLeft <= (cfg.reminderDays || 5);
      return info;
    }

    var api = {
      config: cfg,
      isTrial: trial,
      DAY: DAY,
      // records: array of whatever each store returned (objects or null)
      load: function (records) {
        rec = merge(records);
        var t = now();
        if (trial && !rec.firstLaunch) rec.firstLaunch = t;
        if (trial) see(t);
        loaded = true;
        return status();
      },
      // Re-check during a session (before every action)
      check: function () {
        if (trial && loaded) see(now());
        return status();
      },
      // A trustworthy date from the network (spec-feed HTTP response)
      observeServerTime: function (ms) {
        if (!trial || !num(ms)) return status();
        var ahead = ms - clock();
        if (ahead > TOLERANCE) serverAhead = Math.max(serverAhead, ahead);
        if (ms > rec.lastSeen) rec.lastSeen = ms;
        return status();
      },
      accept: function (at) { rec.accepted = typeof at === "number" ? at : now(); return status(); },
      record: function () { return JSON.parse(JSON.stringify(rec)); },
      status: status,

      // Features a trial can switch off (config.features), e.g. { exportPng: false }
      feature: function (name) {
        if (!trial) return true;
        return !(cfg.features && cfg.features[name] === false);
      },
      expiredTitle: function () { return "Feedproof " + NOUN + " ended"; },
      agreePrompt: function () { return "Read and accept the " + NOUN + " license to continue."; },
      // On/off switches for trial-only behaviour (config.features), e.g. { pngWatermark: true }
      flag: function (name) {
        return trial && !!(cfg.features && cfg.features[name] === true);
      },
      featureMessage: function () {
        return "Not available in the trial version. To unlock it, contact Edgar Febus at " + cfg.contact + ".";
      },

      // ── Wording (identical in every host) ───────────────────────────
      // audience "public" = download trial (no named licensee / signed agreement)
      footer: function () {
        if (trial && PUBLIC) return "\u00a9 2026 Edgar Febus \u00b7 Trial version \u00b7 Not for redistribution";
        if (trial) return "© 2026 Edgar Febus · Evaluation copy licensed to " + cfg.licensee + " · Not for redistribution";
        return "© 2026 Edgar Febus. All rights reserved. · Licensed to " + cfg.licensee +
               (cfg.seats ? " — " + cfg.seats + " seat" + (cfg.seats === 1 ? "" : "s") : "");
      },
      agreement: function () {
        var st = status();
        if (PUBLIC) {
          return {
            title: "Feedproof \u2014 Trial License",
            paragraphs: [
              "\u00a9 2026 Edgar Febus. All rights reserved.",
              "This trial copy of Feedproof is provided for evaluation only. It may not be copied, shared, redistributed or reverse-engineered. All ownership and intellectual property rights remain with Edgar Febus.",
              (st.byCutoff ? "This trial ends on " + st.expiryText + "."
                           : "This trial lasts " + (cfg.trialDays || 15) + " days from your first launch, until " + st.expiryText + ".") +
                (cfg.features && cfg.features.exportPng === false ? " Some features, like Export PNG, are available only in the full version." : "") +
                (cfg.features && cfg.features.pngWatermark === true ? " PNG exports include a trial watermark." : "") +
                " Continued use after the trial requires a purchased license.",
              "Platform names (Meta, TikTok, YouTube, LinkedIn) are trademarks of their respective owners. Safe-zone specifications are provided as guidance; always verify final deliverables against current platform requirements."
            ],
            button: "I agree"
          };
        }
        var ends = st.byCutoff
          ? "This evaluation ends on " + st.expiryText + "."
          : "This evaluation ends " + (cfg.trialDays || 30) + " days after first launch, on " + st.expiryText + ".";
        return {
          title: "Feedproof — Evaluation License",
          paragraphs: [
            "© 2026 Edgar Febus. All rights reserved.",
            "This copy of Feedproof is provided to " + cfg.licensee + " for internal evaluation only, under the evaluation agreement signed " +
              formatYMD(cfg.agreementSigned) + ". It may not be copied, shared, redistributed, reverse-engineered or used outside " +
              cfg.licensee + ". All ownership and intellectual property rights remain with Edgar Febus.",
            ends + " Continued use after that requires a purchased license.",
            "Platform names (Meta, TikTok, YouTube, LinkedIn) are trademarks of their respective owners. Safe-zone specifications are provided as guidance; always verify final deliverables against current platform requirements."
          ],
          button: "I agree"
        };
      },
      expiredMessage: function () {
        var st = status();
        var lead = st.reason === "clock"
          ? "Your Feedproof " + NOUN + " has ended (the computer's date was set back)."
          : "Your Feedproof " + NOUN + " ended on " + st.expiryText + ".";
        return lead + " To keep using Feedproof, contact Edgar Febus at " + cfg.contact + ".";
      },
      reminderMessage: function () {
        var st = status();
        var left = st.daysLeft <= 1 ? "less than a day left" : st.daysLeft + " days left";
        return "Your Feedproof " + NOUN + " ends on " + st.expiryText + " (" + left + "). To keep using Feedproof, contact Edgar Febus at " + cfg.contact + ".";
      },
      storageKey: "feedproof.license." + (cfg.slug || "default"),
      fileName: ".license-" + (cfg.slug || "default") + ".json"
    };
    return api;
  }

  // ── Store helpers ─────────────────────────────────────────────────
  // A store is { name, read() -> Promise<record|null>, write(record) -> Promise }.

  // Shared settings folder outside every plugin's install folder:
  //   macOS   ~/Library/Application Support/Feedproof/
  //   Windows %APPDATA%\Feedproof\
  function sharedDir(home, platform, appData) {
    if (/^win/.test(platform)) return (appData || (home + "\\AppData\\Roaming")) + "\\Feedproof";
    return home + "/Library/Application Support/Feedproof";
  }

  // Node-style fs (CEP panels run Node): synchronous, wrapped in promises
  function nodeFileStore(fs, dir, fileName) {
    var sep = dir.indexOf("\\") >= 0 ? "\\" : "/";
    var file = dir + sep + fileName;
    return {
      name: "file:" + file,
      read: function () {
        try { return Promise.resolve(parseRecord(fs.readFileSync(file, "utf8"))); } catch (e) { return Promise.resolve(null); }
      },
      write: function (r) {
        try {
          if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
          fs.writeFileSync(file, JSON.stringify(r));
        } catch (e) {}
        return Promise.resolve();
      }
    };
  }

  // Any localStorage-like object (CEP / UXP panel storage, Figma clientStorage mirror)
  function keyValueStore(storage, key) {
    return {
      name: "storage:" + key,
      read: function () {
        try { return Promise.resolve(parseRecord(storage.getItem(key))); } catch (e) { return Promise.resolve(null); }
      },
      write: function (r) {
        try { storage.setItem(key, JSON.stringify(r)); } catch (e) {}
        return Promise.resolve();
      }
    };
  }

  // Read every store, merge, save the merged record back to all of them
  function readAll(stores) {
    return Promise.all(stores.map(function (s) {
      return s.read().then(function (r) { return r; }, function () { return null; });
    }));
  }
  function writeAll(stores, r) {
    return Promise.all(stores.map(function (s) {
      return s.write(r).then(null, function () {});
    }));
  }

  var api = {
    create: create, merge: merge, formatDate: formatDate, endOfDay: endOfDay,
    parseRecord: parseRecord, sharedDir: sharedDir,
    nodeFileStore: nodeFileStore, keyValueStore: keyValueStore,
    readAll: readAll, writeAll: writeAll
  };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.FPLicense = api;
})(typeof window !== "undefined" ? window : (typeof globalThis !== "undefined" ? globalThis : this));
