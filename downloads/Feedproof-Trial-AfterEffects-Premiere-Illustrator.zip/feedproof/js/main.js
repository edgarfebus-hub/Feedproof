/*
 * Feedproof — Meta, TikTok, YouTube & LinkedIn safe zones
 * © 2026 Edgar Febus. All rights reserved.
 * https://edgarfebus.com
 */
/*
 * Feedproof — panel controller
 * Runs inside the CEP panel in AE / PS / AI / PR, and also in a plain
 * browser (preview mode: host buttons disabled, PNG export downloads).
 */
(function () {
  "use strict";

  var S = window.SZSpecs, G = window.SZGeometry, R = window.SZRender;
  var $ = function (id) { return document.getElementById(id); };

  // ── Host bridge ─────────────────────────────────────────────────────
  // CEP panel (AE / Illustrator / Premiere) by default. The Photoshop UXP
  // plugin supplies window.SZAdapter for the parts that differ there.
  var AD = window.SZAdapter || null;
  var CEP = AD ? null : (window.__adobe_cep__ || null);
  var NODE = (!AD && typeof require === "function") ? { fs: require("fs"), path: require("path"), os: require("os"), cp: require("child_process") } : null;

  var HOSTS = {
    AEFT: { name: "After Effects", create: "New Comp", createMany: "comps", apply: "Add to Active Comp", jsx: true },
    PPRO: { name: "Premiere Pro", create: "New Sequence", createMany: "sequences", apply: "Add to Active Sequence", jsx: true, png: true },
    PHXS: { name: "Photoshop", create: "New Document", createMany: "documents", apply: "Add to Active Doc", jsx: true },
    PHSP: { name: "Photoshop", create: "New Document", createMany: "documents", apply: "Add to Active Doc", jsx: true },
    ILST: { name: "Illustrator", create: "New Document", createMany: "documents", apply: "Add to Active Artboard", jsx: true },
    IDSN: { name: "InDesign", create: "New Document", createMany: "documents", apply: "Add to Active Page", jsx: true },
    FIGMA: { name: "Figma", create: "New Frame", createMany: "frames", apply: "Add to Selected Frame", jsx: true },
    BROWSER: { name: "Preview", create: "New Comp", createMany: "comps", apply: "Add to Active", jsx: false }
  };

  function hostId() {
    if (AD) return AD.host;
    if (!CEP) return "BROWSER";
    try { return JSON.parse(CEP.getHostEnvironment()).appName; } catch (e) { return "BROWSER"; }
  }
  var VERSION = "1.4.1";
  var HOST = hostId();
  var H = HOSTS[HOST] || HOSTS.BROWSER;

  // ── Evaluation / license (shared logic in license.js, settings in license-config.js) ──
  // No config (Edgar's own builds) = no license screens at all.
  var LCFG = window.FP_LICENSE_CONFIG || null;
  var LIC = (LCFG && window.FPLicense) ? window.FPLicense.create(LCFG) : null;
  var LSTORES = [];
  if (LIC) {
    // 1) a hidden file outside every plugin's install folder (shared by all Adobe apps)
    if (AD && AD.licenseStores) LSTORES = LSTORES.concat(AD.licenseStores(LIC));
    else if (NODE) {
      try {
        var penv = (typeof process !== "undefined" && process.env) || {};
        var dir = window.FPLicense.sharedDir(NODE.os.homedir(), (typeof process !== "undefined" && process.platform) || "darwin", penv.APPDATA);
        LSTORES.push(window.FPLicense.nodeFileStore(NODE.fs, dir, LIC.fileName));
      } catch (e) {}
    }
    // 2) this app's own storage (Figma: clientStorage)
    try { LSTORES.push(window.FPLicense.keyValueStore(window.localStorage, LIC.storageKey)); } catch (e) {}
  }
  function saveLicense() { return LIC ? window.FPLicense.writeAll(LSTORES, LIC.record()) : Promise.resolve(); }
  function evalExpired() {
    if (!LIC) return false;
    var st = LIC.check();
    saveLicense();
    if (st.state === "expired") { showExpired(); return true; }
    return false;
  }

  function evalHost(script) {
    return new Promise(function (resolve) {
      if (!CEP) return resolve("ERR|Open this panel inside After Effects, Premiere, Photoshop or Illustrator.");
      CEP.evalScript(script, function (res) { resolve(String(res)); });
    });
  }

  function runJob(job) {
    if (evalExpired()) return Promise.resolve("ERR|" + LIC.expiredMessage());
    if (AD) { job.host = HOST; return AD.run(job); }
    // Object literal is valid ExtendScript, so JSON goes straight in.
    job.host = HOST; // tell the script which app it's in — never let it guess
    return evalHost("FeedproofFX.run(" + JSON.stringify(job) + ")").then(function (res) {
      if (res === "EvalScript error.") return "ERR|The host script failed to load. Reload the panel.";
      return res;
    });
  }

  function openExternal(url) {
    if (AD && AD.openExternal) return AD.openExternal(url);
    try {
      if (window.cep && window.cep.util) return window.cep.util.openURLInDefaultBrowser(url);
    } catch (e) {}
    window.open(url, "_blank");
  }

  // Buttons: real <button>s in CEP; drawn <div role="button">s where the host
  // ignores button styling (Photoshop UXP).
  function mkBtn() {
    if (AD && AD.divButtons) {
      var d = document.createElement("div");
      d.setAttribute("role", "button");
      d.setAttribute("tabindex", "0");
      return d;
    }
    return document.createElement("button");
  }
  function setDis(el, v) {
    el.disabled = !!v;
    if (v) el.classList.add("is-disabled"); else el.classList.remove("is-disabled");
    el.setAttribute("aria-disabled", v ? "true" : "false");
  }
  function setHidden(el, v) {
    el.hidden = !!v;
    el.style.display = v ? "none" : "";
  }
  // Disabled drawn buttons must not react to clicks
  document.addEventListener("click", function (e) {
    var t = e.target;
    while (t && t !== document.body) {
      if (t.disabled === true || (t.getAttribute && t.getAttribute("aria-disabled") === "true")) {
        e.stopPropagation(); e.preventDefault();
        return;
      }
      t = t.parentNode;
    }
  }, true);

  // ── State ───────────────────────────────────────────────────────────
  var DEFAULTS = {
    platform: "meta", ratio: "9:16", specId: "meta-916-unified", sizeKey: "0",
    customW: 1080, customH: 1920,
    mode: "both", outline: true, labels: true, opacity: 35,
    crops: [], prefix: "", fps: "29.97", duration: 15, oneDoc: true,
    cropColors: { "9:16": "#ffffff", "4:5": "#e45cff", "1:1": "#ffd84d", "16:9": "#9b8cff" },
    comboSet: ["meta", "tiktok", "youtube", "linkedin"],   // platforms in the Combined master
    batch: []
  };
  var STATE_KEY = "feedproof.state";
  var state = load();

  function load() {
    var s = {};
    try {
      // settings from the Safe Zones panel carry over on first launch
      s = JSON.parse(localStorage.getItem(STATE_KEY) || localStorage.getItem("safezones.state") || "{}") || {};
    } catch (e) {}
    var out = {};
    for (var k in DEFAULTS) out[k] = (s[k] !== undefined) ? s[k] : DEFAULTS[k];
    var cur = S.byId(out.specId);
    if (!cur) { out.platform = DEFAULTS.platform; out.ratio = DEFAULTS.ratio; out.specId = DEFAULTS.specId; out.sizeKey = "0"; }
    else { out.platform = cur.platform; out.ratio = cur.ratio; }
    out.comboSet = Array.isArray(s.comboSet) ? s.comboSet.filter(function (p) { return S.PLATFORM_IDS.indexOf(p) >= 0; }) :
      (cur && cur.platform === "combo" ? cur.platforms.slice() : DEFAULTS.comboSet.slice());
    if (out.comboSet.length < 2) out.comboSet = DEFAULTS.comboSet.slice();
    out.crops = Array.isArray(out.crops) ? out.crops.filter(function (r) { return S.RATIOS.indexOf(r) >= 0; }) : [];
    out.batch = Array.isArray(out.batch) ? out.batch.filter(function (b) { return b && S.byId(b.specId); }) : [];
    // keep a valid colour for every ratio, even if older saved state lacks one
    var cc = {}, saved = (s.cropColors && typeof s.cropColors === "object") ? s.cropColors : {};
    for (var r in DEFAULTS.cropColors) {
      cc[r] = /^#[0-9a-f]{6}$/i.test(saved[r] || "") ? saved[r] : DEFAULTS.cropColors[r];
    }
    out.cropColors = cc;
    return out;
  }
  function save() {
    try { localStorage.setItem(STATE_KEY, JSON.stringify(state)); } catch (e) {}
  }

  function spec() { return S.byId(state.specId); }

  function frameSize() {
    var sp = spec();
    if (state.sizeKey === "custom") return { w: clampInt(state.customW), h: clampInt(state.customH) };
    var s = sp.sizes[parseInt(state.sizeKey, 10)] || sp.sizes[0];
    return { w: s.w, h: s.h };
  }
  function clampInt(v) { v = parseInt(v, 10); if (!(v > 0)) v = 1080; return Math.max(16, Math.min(16000, v)); }

  function colorsForHost() {
    var c = R.COLORS, f = function (hex) { return R.hexToRgb(hex).map(function (n) { return Math.round(n / 255 * 1000) / 1000; }); };
    return { ui: f(c.ui), comfort: f(c.ui), estimate: f(c.ui), safe: f(c.safe), crop: f(c.crop) };   // all masks red
  }

  var PLATFORM_CODE = { meta: "META", tiktok: "TIKTOK", youtube: "YT", linkedin: "LI" };
  var SPEC_CODE = {
    "meta-916-unified": "ReelsStories", "meta-916-stories": "Stories", "meta-916-disclaimer": "Reels-Disclaimer",
    "meta-45-feed": "Feed", "meta-11-feed": "Feed", "meta-169-instream": "InStream",
    "tiktok-916-infeed": "InFeed", "tiktok-916-topview": "TopView", "tiktok-11-infeed": "InFeed", "tiktok-169-infeed": "InFeed",
    "yt-916-universal": "Vertical", "yt-916-shorts-min": "Shorts", "yt-45-feed": "DemandGen", "yt-11-square": "Square",
    "yt-169-instream": "InStream",
    "li-916-vertical": "Vertical", "li-45-feed": "Feed", "li-11-feed": "Feed", "li-169-feed": "Feed"
  };
  function platformsOf(sp) { return sp.platform === "combo" ? (sp.platforms || []) : [sp.platform]; }

  function itemName(sp, w, h) {
    var code = platformsOf(sp).map(function (p) { return PLATFORM_CODE[p] || p.toUpperCase(); }).join("-");
    var kind = sp.platform === "combo" ? "Master" : (SPEC_CODE[sp.id] || "Custom");
    return (state.prefix || "") + code + "_" + kind + "_" + sp.ratio.replace(":", "x") + "_" + w + "x" + h;
  }
  function itemTitle(sp) {
    var names = platformsOf(sp).map(function (p) { return S.PLATFORM_NAMES[p] || p; }).join("+");
    if (sp.platform === "combo") return names + " " + sp.ratio + " master";
    return names + " " + sp.ratio + " " + sp.name;
  }

  function buildGeo(sp, w, h) {
    var g = G.build(sp, w, h, { crops: state.crops });
    g.crops.forEach(function (c) {
      c.hex = state.cropColors[c.ratio] || R.COLORS.crop;
      c.color = R.hexToRgb(c.hex).map(function (n) { return Math.round(n / 255 * 1000) / 1000; });
    });
    return g;
  }

  // NTSC rates as exact rationals (29.97 → 30000/1001) so timecode doesn't drift
  function exactFps(v) {
    var f = parseFloat(v);
    var ntsc = { "23.976": 24000 / 1001, "29.97": 30000 / 1001, "59.94": 60000 / 1001 };
    return ntsc[String(v)] || f;
  }

  function opts() {
    return {
      mode: state.mode, outline: state.outline, labels: state.labels,
      opacity: state.opacity, fps: exactFps(state.fps), duration: Math.max(1, parseFloat(state.duration) || 15),
      aiOneDoc: !!state.oneDoc, colors: colorsForHost(), folder: "Safe Zones"
    };
  }

  // ── Rendering of controls ───────────────────────────────────────────
  function seg(container, items, current, onPick, isDisabled) {
    container.innerHTML = "";
    items.forEach(function (it) {
      var b = mkBtn();
      b.textContent = it.label;
      b.setAttribute("role", "tab");
      b.className = it.id === current ? "on" : "";
      b.setAttribute("aria-selected", it.id === current ? "true" : "false");
      if (isDisabled && isDisabled(it.id)) { setDis(b, true); b.title = "Not offered on this platform"; }
      b.addEventListener("click", function () { onPick(it.id); });
      container.appendChild(b);
    });
  }

  // Placements offered for a platform + ratio. Combined = the one master for the ticked platforms.
  function placements(platform, ratio) {
    if (platform === "combo") { var c = S.combo(ratio, state.comboSet); return c ? [c] : []; }
    return S.forPlatformRatio(platform, ratio);
  }
  function ratiosFor(platform) {
    return S.RATIOS.filter(function (r) { return placements(platform, r).length > 0; });
  }
  function pickFirst(platform) {
    if (!placements(platform, state.ratio).length) state.ratio = ratiosFor(platform)[0];
    state.specId = placements(platform, state.ratio)[0].id;
    state.sizeKey = "0";
  }

  function renderComboChips() {
    var row = $("comboRow"), box = $("comboChips");
    var on = state.platform === "combo";
    setHidden(row, !on);
    if (!on) return;
    box.innerHTML = "";
    S.PLATFORM_IDS.forEach(function (p) {
      var b = mkBtn();
      var picked = state.comboSet.indexOf(p) >= 0, has = S.hasRatio(p, state.ratio);
      b.className = "chip combo-chip" + (picked && has ? " on" : "");
      b.textContent = S.PLATFORM_NAMES[p];
      if (!has) { setDis(b, true); b.title = "No " + S.PLATFORM_NAMES[p] + " " + state.ratio + " placement"; }
      b.addEventListener("click", function () {
        var i = state.comboSet.indexOf(p), next = state.comboSet.slice();
        if (i >= 0) next.splice(i, 1); else next.push(p);
        if (!S.combo(state.ratio, next)) { setStatus("A Combined master needs at least two platforms with " + state.ratio + ".", "err"); return; }
        state.comboSet = next;
        state.specId = S.combo(state.ratio, next).id;
        update();
      });
      box.appendChild(b);
    });
  }

  function renderPickers() {
    seg($("platformSeg"), S.PLATFORMS, state.platform, function (p) {
      state.platform = p;
      pickFirst(p);
      update();
    });

    var avail = ratiosFor(state.platform);
    seg($("ratioSeg"), S.RATIOS.map(function (r) { return { id: r, label: r }; }), state.ratio, function (r) {
      state.ratio = r;
      state.specId = placements(state.platform, r)[0].id;
      state.sizeKey = "0";
      update();
    }, function (r) { return avail.indexOf(r) < 0; });
    renderComboChips();

    var specSel = $("specSel");
    specSel.innerHTML = "";
    placements(state.platform, state.ratio).forEach(function (sp) {
      var o = document.createElement("option");
      o.value = sp.id;
      o.textContent = sp.name + (sp.kind === "estimate" ? "  (estimate)" : "");
      specSel.appendChild(o);
    });
    specSel.value = state.specId;

    var sizeSel = $("sizeSel");
    sizeSel.innerHTML = "";
    spec().sizes.forEach(function (s, i) {
      var o = document.createElement("option");
      o.value = String(i);
      o.textContent = s.label;
      sizeSel.appendChild(o);
    });
    var oc = document.createElement("option");
    oc.value = "custom";
    oc.textContent = "Custom…";
    sizeSel.appendChild(oc);
    sizeSel.value = state.sizeKey;
    if (sizeSel.value !== state.sizeKey) { state.sizeKey = "0"; sizeSel.value = "0"; }

    setHidden($("customRow"), state.sizeKey !== "custom");
    $("customW").value = state.customW;
    $("customH").value = state.customH;
  }

  function renderCropChips() {
    var box = $("cropChips");
    box.innerHTML = "";
    var f = frameSize();
    S.RATIOS.forEach(function (r) {
      var col = state.cropColors[r];
      var on = state.crops.indexOf(r) >= 0;
      var same = Math.abs(G.ratioValue(r) - f.w / f.h) < 0.005;

      var wrap = document.createElement("span");
      wrap.className = "chip-wrap";

      var b = mkBtn();
      b.className = "chip" + (on ? " on" : "");
      b.textContent = r;
      if (on) { b.style.borderColor = col; b.style.background = hexA(col, 0.2); }
      if (same) { setDis(b, true); b.title = "Same ratio as the frame"; }
      b.addEventListener("click", function () {
        var i = state.crops.indexOf(r);
        if (i >= 0) state.crops.splice(i, 1); else state.crops.push(r);
        update();
      });
      wrap.appendChild(b);

      if (!same && AD && !AD.colorInput) {
        var sw2 = document.createElement("div");
        sw2.className = "swatch";
        sw2.setAttribute("role", "button");
        sw2.title = "Click to change the " + r + " crop colour";
        sw2.style.background = col;
        sw2.addEventListener("click", function (e) {
          e.stopPropagation();
          var pal = CROP_PALETTE, i = pal.indexOf(state.cropColors[r]);
          state.cropColors[r] = pal[(i + 1) % pal.length];
          if (state.crops.indexOf(r) < 0) state.crops.push(r);
          update();
        });
        wrap.appendChild(sw2);
      } else if (!same) {
        var sw = document.createElement("label");
        sw.className = "swatch";
        sw.title = "Change " + r + " crop colour";
        sw.style.background = col;
        var inp = document.createElement("input");
        inp.type = "color";
        inp.value = col;
        inp.setAttribute("aria-label", r + " crop guide colour");
        inp.addEventListener("input", function () {
          state.cropColors[r] = inp.value;
          sw.style.background = inp.value;
          if (state.crops.indexOf(r) < 0) state.crops.push(r);   // picking a colour turns the guide on
          save();
          renderPreview();
        });
        inp.addEventListener("change", function () { update(); });
        sw.appendChild(inp);
        wrap.appendChild(sw);
      }
      box.appendChild(wrap);
    });
  }

  var CROP_PALETTE = ["#ffffff", "#e45cff", "#ffd84d", "#9b8cff", "#00e0c6", "#ff8a3d", "#5cc8ff", "#ff5c8a"];

  function hexA(hex, a) {
    var c = R.hexToRgb(hex);
    return "rgba(" + c[0] + "," + c[1] + "," + c[2] + "," + a + ")";
  }

  function renderPreview() {
    var sp = spec(), f = frameSize();
    var g = buildGeo(sp, f.w, f.h);
    var box = $("previewBox"), cv = $("preview");
    var bw = box.clientWidth || box.offsetWidth || 300;
    var ih = window.innerHeight || document.documentElement.clientHeight || 800;
    var maxW = Math.max(120, bw - 22);
    var maxH = Math.min(380, Math.max(200, ih * 0.42));
    var scale = Math.min(maxW / f.w, maxH / f.h);
    if (AD && AD.drawPreview) {
      AD.drawPreview(cv, g, { scale: scale, mode: state.mode, outline: state.outline, labels: state.labels, opacity: state.opacity });
      return g;
    }
    var dpr = window.devicePixelRatio || 1;
    cv.style.width = Math.round(f.w * scale) + "px";
    cv.style.height = Math.round(f.h * scale) + "px";
    cv.width = Math.round(f.w * scale * dpr);
    cv.height = Math.round(f.h * scale * dpr);
    var ctx = cv.getContext("2d");
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    R.draw(ctx, g, {
      scale: scale * dpr, mode: state.mode, outline: state.outline, labels: state.labels,
      opacity: state.opacity, background: true, hatch: true, hatchWidth: dpr, hatchStep: dpr
    });
    return g;
  }

  var KIND_TEXT = {
    ui: "Platform UI covers the red areas",
    comfort: "No platform UI · title-safe padding",
    estimate: "Estimate — verify in the platform's preview"
  };

  function renderMeta(g) {
    var sp = spec(), f = frameSize();
    var kb = $("kindBadge");
    kb.className = "kind " + sp.kind;
    kb.textContent = KIND_TEXT[sp.kind];

    var src = sp.source || (sp.sources && sp.sources[0]);
    var link = $("srcLink");
    if (sp.platform === "combo") {
      link.textContent = "Sources (" + sp.sources.length + ")";
      link.title = sp.sources.map(function (s) { return s.title; }).join("\n");
    } else {
      link.textContent = "Source · " + (S.active().checked || "");
      link.title = src.title;
    }
    link.href = src.url;

    $("specNote").textContent = sp.note;

    var warn = $("aspectWarn"), msgs = [];
    if (!G.aspectMatches(sp, f.w, f.h)) msgs.push(f.w + "×" + f.h + " isn't " + sp.ratio + ". Zones are scaled as percentages, so check them against the platform preview.");
    if (sp.maxSide && Math.max(f.w, f.h) > sp.maxSide) msgs.push("LinkedIn rejects files with a side over " + sp.maxSide + " px — deliver LinkedIn at " + sp.maxSide + " or less.");
    setHidden(warn, !msgs.length);
    if (msgs.length) warn.textContent = msgs.join(" ");

    // Measurements
    var t = $("measure");
    var rows = [];
    var pct = function (v, of) { return (Math.round(v / of * 1000) / 10) + "%"; };
    var col = R.COLORS.ui;
    var sw = '<span class="sw" style="background:' + col + '"></span>';
    rows.push(["Frame", f.w + " × " + f.h, sp.ratio]);
    rows.push([sw + "Top", g.margins.top + " px", pct(g.margins.top, f.h)]);
    rows.push([sw + "Bottom", g.margins.bottom + " px", pct(g.margins.bottom, f.h)]);
    rows.push([sw + "Left", g.margins.left + " px", pct(g.margins.left, f.w)]);
    rows.push([sw + "Right", g.margins.right + " px", pct(g.margins.right, f.w)]);
    g.zones.filter(function (z) { return z.extra; }).forEach(function (z) {
      rows.push([sw + String(z.label).split(" — ")[0], "x " + z.x + "–" + (z.x + z.w), "y " + z.y + "–" + (z.y + z.h)]);
    });
    rows.push(['<span class="sw" style="background:' + R.COLORS.safe + '"></span>Safe area', g.safe.w + " × " + g.safe.h, g.safe.x + "," + g.safe.y]);
    t.innerHTML = rows.map(function (r, i) {
      return '<tr class="' + (i === rows.length - 1 ? "safe" : "") + '"><td>' + r[0] + "</td><td>" + r[1] + "</td><td>" + r[2] + "</td></tr>";
    }).join("");
  }

  function renderOptions() {
    Array.prototype.forEach.call($("modeSeg").children, function (b) {
      b.className = b.getAttribute("data-mode") === state.mode ? "on" : "";
    });
    $("optOutline").checked = state.outline;
    $("optLabels").checked = state.labels;
    $("optOneDoc").checked = state.oneDoc;
    $("optOpacity").value = state.opacity;
    $("opVal").textContent = state.opacity + "%";
    $("optPrefix").value = state.prefix;
    $("optFps").value = state.fps;
    $("optDur").value = state.duration;
    // Premiere overlays are a single PNG — "guides" only means lines in the PNG
    $("modeSeg").title = HOST === "PPRO" ? "Premiere has no scriptable guides: the overlay is a PNG on the top track." : "";
  }

  function renderBatch() {
    var ul = $("batchList");
    ul.innerHTML = "";
    state.batch.forEach(function (b, i) {
      var sp = S.byId(b.specId);
      if (!sp) return;
      var li = document.createElement("li");
      li.innerHTML = '<span class="dot"></span><span class="txt"><span class="name"></span><span class="sub"></span></span>' + (AD && AD.divButtons ? '<div role="button" class="x" title="Remove">×</div>' : '<button class="x" title="Remove">×</button>') + '';
      li.querySelector(".dot").style.background = R.COLORS[sp.kind];
      li.querySelector(".name").textContent = itemTitle(sp);
      li.querySelector(".sub").textContent = b.w + " × " + b.h;
      li.querySelector(".x").addEventListener("click", function () { state.batch.splice(i, 1); update(); });
      ul.appendChild(li);
    });
    $("batchCount").textContent = state.batch.length;
    var cb = $("createBatch");
    setDis(cb, !state.batch.length || !H.jsx);
    var n = state.batch.length;
    cb.textContent = n ? "Create " + n + " " + (n === 1 ? H.createMany.replace(/s$/, "") : H.createMany) : "Create all";
  }

  function renderHost() {
    document.body.className = "h-" + HOST;
    var pill = $("hostPill");
    pill.textContent = H.name;
    pill.title = "Feedproof v" + VERSION;
    pill.className = "host-pill" + (H.jsx ? " live" : "");
    $("createBtn").textContent = H.create;
    $("applyBtn").textContent = H.apply;
    ["createBtn", "applyBtn", "toggleBtn"].forEach(function (id) { setDis($(id), !H.jsx); });
    if (AD && !AD.png) setHidden($("pngBtn"), true);
    if (LIC && LIC.flag("pngWatermark")) {
      var wb = $("pngBtn");
      wb.title = "Trial PNGs include a FEEDPROOF TRIAL watermark. The full version exports clean overlays.";
      wb.innerHTML = "";
      wb.appendChild(document.createTextNode("Export PNG "));
      var wt = document.createElement("span");
      wt.className = "lock-tag";
      wt.textContent = "Trial watermark";
      wb.appendChild(wt);
      wb.classList.add("trial-tagged");
    }
    // Trial builds can lock Export PNG: the button stays visible so people know it exists
    if (LIC && !LIC.feature("exportPng")) {
      var pb = $("pngBtn");
      pb.classList.add("trial-locked");
      pb.title = LIC.featureMessage();
      pb.innerHTML = "";
      pb.appendChild(document.createTextNode("Export PNG "));
      var tag = document.createElement("span");
      tag.className = "lock-tag";
      tag.textContent = "Full version";
      pb.appendChild(tag);
    }
    if (!H.jsx) setStatus("Preview mode — install the extension to build comps and documents.", "");
    else setStatus("Feedproof v" + VERSION + " · " + H.name, "");
  }

  function update() {
    save();
    renderPickers();
    renderCropChips();
    renderOptions();
    var g = renderPreview();
    renderMeta(g);
    renderBatch();
  }

  // ── Status ──────────────────────────────────────────────────────────
  function setStatus(msg, cls, revealPath) {
    var s = $("status");
    s.className = "status " + (cls || "");
    s.textContent = msg;
    if (revealPath && NODE) {
      var a = document.createElement("a");
      a.textContent = " Show in folder";
      a.addEventListener("click", function () { reveal(revealPath); });
      s.appendChild(a);
    }
  }
  function report(res) {
    var parts = String(res).split("|");
    var kind = parts.shift();
    setStatus(parts.join("|") || kind, kind === "OK" ? "ok" : "err");
  }

  // ── PNG overlays ────────────────────────────────────────────────────
  // watermark: true → trial copy of Export PNG ("FEEDPROOF TRIAL" tiled across the overlay)
  function renderPngDataUrl(sp, w, h, watermark) {
    var g = buildGeo(sp, w, h);
    var cv = document.createElement("canvas");
    cv.width = w; cv.height = h;
    var line = Math.max(1, Math.round(Math.min(w, h) / 540));
    var ctx = cv.getContext("2d");
    R.draw(ctx, g, {
      scale: 1, mode: state.mode, outline: state.outline, labels: state.labels,
      opacity: state.opacity, background: false, hatch: true, hatchWidth: line, hatchStep: line * 2, exportLine: line
    });
    if (watermark) drawTrialWatermark(ctx, w, h);
    return cv.toDataURL("image/png");
  }

  function drawTrialWatermark(ctx, w, h) {
    var size = Math.max(14, Math.round(Math.min(w, h) * 0.05));
    var text = "FEEDPROOF TRIAL";
    ctx.save();
    ctx.font = "800 " + size + "px -apple-system, 'Segoe UI', Roboto, Arial, sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.lineWidth = Math.max(1, size / 18);
    ctx.fillStyle = "rgba(255,255,255,0.22)";
    ctx.strokeStyle = "rgba(0,0,0,0.22)";
    ctx.translate(w / 2, h / 2);
    ctx.rotate(-Math.PI / 6);
    var tw = ctx.measureText(text).width + size * 2.2, th = size * 3.2;
    var reach = Math.sqrt(w * w + h * h) / 2 + tw;
    for (var y = -reach, row = 0; y <= reach; y += th, row++) {
      for (var x = -reach + (row % 2) * tw / 2; x <= reach; x += tw) {
        ctx.strokeText(text, x, y);
        ctx.fillText(text, x, y);
      }
    }
    ctx.restore();
  }

  function overlayDir() {
    var dir = NODE.path.join(NODE.os.homedir(), "Documents", "Feedproof", "Overlays");
    NODE.fs.mkdirSync(dir, { recursive: true });
    return dir;
  }

  function writePng(sp, w, h, name, watermark) {
    var data = renderPngDataUrl(sp, w, h, watermark).split(",")[1];
    var file = NODE.path.join(overlayDir(), name + "_" + state.mode + ".png");
    NODE.fs.writeFileSync(file, Buffer.from(data, "base64"));
    return file;
  }

  function reveal(p) {
    if (!NODE) return;
    var cmd = process.platform === "win32" ? 'explorer /select,"' + p + '"' : 'open -R "' + p + '"';
    NODE.cp.exec(cmd);
  }

  // ── Actions ─────────────────────────────────────────────────────────
  function makeItem(sp, w, h) {
    var name = itemName(sp, w, h);
    var it = { name: name, title: itemTitle(sp), w: w, h: h, geo: buildGeo(sp, w, h) };
    if (HOST === "PPRO") {
      if (!NODE) throw new Error("Node.js is disabled for this panel — check the manifest.");
      it.png = writePng(sp, w, h, name);
    }
    return it;
  }

  function busy(on) {
    ["createBtn", "applyBtn", "createBatch", "toggleBtn"].forEach(function (id) {
      var b = $(id);
      if (on) { b.setAttribute("data-was", b.disabled ? "1" : ""); setDis(b, true); }
      else setDis(b, b.getAttribute("data-was") === "1");
    });
  }

  function doCreate(list) {
    busy(true);
    setStatus("Building…", "");
    var items;
    try { items = list.map(function (d) { return makeItem(S.byId(d.specId), d.w, d.h); }); }
    catch (e) { busy(false); return setStatus(e.message, "err"); }
    runJob({ action: "create", items: items, opts: opts() }).then(function (r) { busy(false); report(r); });
  }

  function doApply() {
    busy(true);
    runJob({ action: "size" }).then(function (res) {
      var p = res.split("|");
      if (p[0] !== "OK") { busy(false); return report(p[0] === "NONE" ? "ERR|" + p[1] : res); }
      var w = parseInt(p[1], 10), h = parseInt(p[2], 10), sp = spec();
      var item;
      try { item = makeItem(sp, w, h); } catch (e) { busy(false); return setStatus(e.message, "err"); }
      var mismatch = !G.aspectMatches(sp, w, h);
      runJob({ action: "apply", items: [item], opts: opts() }).then(function (r) {
        busy(false);
        if (mismatch && r.indexOf("OK|") === 0) r += " — note: " + w + "×" + h + " isn't " + sp.ratio + "; zones scaled by percentage.";
        report(r);
      });
    });
  }

  function doExportPng() {
    if (LIC && !LIC.feature("exportPng")) { setStatus("Export PNG \u2014 " + LIC.featureMessage(), "err"); return; }
    var wm = !!(LIC && LIC.flag("pngWatermark"));
    var sp = spec(), f = frameSize(), name = itemName(sp, f.w, f.h) + (wm ? "_TRIAL" : "");
    if (NODE) {
      try {
        var file = writePng(sp, f.w, f.h, name, wm);
        setStatus("Saved " + NODE.path.basename(file) + (wm ? " (trial watermark)." : "."), "ok", file);
      } catch (e) { setStatus("Couldn't save PNG: " + e.message, "err"); }
      return;
    }
    var a = document.createElement("a");
    a.href = renderPngDataUrl(sp, f.w, f.h, wm);
    a.download = name + "_" + state.mode + ".png";
    document.body.appendChild(a); a.click(); a.remove();
    setStatus("Downloaded " + a.download, "ok");
  }

  function measurementsText() {
    var sp = spec(), f = frameSize(), g = buildGeo(sp, f.w, f.h);
    var lines = [
      itemTitle(sp) + " — " + f.w + "×" + f.h,
      "Keep clear: top " + g.margins.top + "px, bottom " + g.margins.bottom + "px, left " + g.margins.left + "px, right " + g.margins.right + "px"
    ];
    g.zones.filter(function (z) { return z.extra; }).forEach(function (z) {
      lines.push(z.label + ": x " + z.x + "–" + (z.x + z.w) + ", y " + z.y + "–" + (z.y + z.h));
    });
    lines.push("Safe area: " + g.safe.w + "×" + g.safe.h + " at (" + g.safe.x + ", " + g.safe.y + ")");
    lines.push(sp.note);
    return lines.join("\n");
  }

  function copyText(txt) {
    if (AD && AD.copy) {
      AD.copy(txt).then(function () { setStatus("Measurements copied.", "ok"); },
                        function () { setStatus("Couldn't copy to the clipboard.", "err"); });
      return;
    }
    var ta = document.createElement("textarea");
    ta.value = txt;
    ta.style.position = "fixed"; ta.style.opacity = "0";
    document.body.appendChild(ta); ta.select();
    var ok = false;
    try { ok = document.execCommand("copy"); } catch (e) {}
    ta.remove();
    if (!ok && navigator.clipboard) navigator.clipboard.writeText(txt);
    setStatus("Measurements copied.", "ok");
  }

  var SETS = {
    "meta-core": [["meta-916-unified", 0], ["meta-45-feed", 0], ["meta-11-feed", 0], ["meta-169-instream", 0]],
    "meta-hires": [["meta-916-unified", 1], ["meta-45-feed", 1], ["meta-11-feed", 1]],
    "tiktok-core": [["tiktok-916-infeed", 0], ["tiktok-11-infeed", 0], ["tiktok-169-infeed", 0]],
    "youtube-core": [["yt-916-universal", 0], ["yt-45-feed", 0], ["yt-11-square", 0], ["yt-169-instream", 0]],
    "linkedin-core": [["li-916-vertical", 0], ["li-45-feed", 0], ["li-11-feed", 0], ["li-169-feed", 0]],
    "combo-core": [["combo-916-mtyl", 0], ["combo-45-myl", 0], ["combo-11-mtyl", 0], ["combo-169-mtyl", 0]]
  };

  function addToBatch(specId, w, h) {
    for (var i = 0; i < state.batch.length; i++) {
      var b = state.batch[i];
      if (b.specId === specId && b.w === w && b.h === h) return false;
    }
    state.batch.push({ specId: specId, w: w, h: h });
    return true;
  }

  // ── Wire up ─────────────────────────────────────────────────────────
  function wire() {
    $("specSel").addEventListener("change", function (e) { state.specId = e.target.value; state.sizeKey = "0"; update(); });
    $("sizeSel").addEventListener("change", function (e) { state.sizeKey = e.target.value; update(); });
    $("customW").addEventListener("change", function (e) { state.customW = clampInt(e.target.value); update(); });
    $("customH").addEventListener("change", function (e) { state.customH = clampInt(e.target.value); update(); });

    Array.prototype.forEach.call($("modeSeg").children, function (b) {
      b.addEventListener("click", function () { state.mode = b.getAttribute("data-mode"); update(); });
    });
    $("optOutline").addEventListener("change", function (e) { state.outline = e.target.checked; update(); });
    $("optLabels").addEventListener("change", function (e) { state.labels = e.target.checked; update(); });
    $("optOneDoc").addEventListener("change", function (e) { state.oneDoc = e.target.checked; save(); });
    $("optOpacity").addEventListener("input", function (e) { state.opacity = parseInt(e.target.value, 10); update(); });
    $("optOpacity").addEventListener("change", function (e) { state.opacity = parseInt(e.target.value, 10); update(); });
    $("optPrefix").addEventListener("input", function (e) { state.prefix = e.target.value.replace(/[\\/:*?"<>|]/g, ""); save(); });
    $("optFps").addEventListener("change", function (e) { state.fps = e.target.value; save(); });
    $("optDur").addEventListener("change", function (e) { state.duration = Math.max(1, parseFloat(e.target.value) || 15); update(); });

    $("createBtn").addEventListener("click", function () {
      var f = frameSize();
      doCreate([{ specId: state.specId, w: f.w, h: f.h }]);
    });
    $("applyBtn").addEventListener("click", doApply);
    $("pngBtn").addEventListener("click", doExportPng);
    $("toggleBtn").addEventListener("click", function () { runJob({ action: "toggle" }).then(report); });
    $("copyBtn").addEventListener("click", function () { copyText(measurementsText()); });

    $("addBatch").addEventListener("click", function () {
      var f = frameSize();
      if (!addToBatch(state.specId, f.w, f.h)) setStatus("Already in the batch.", "");
      update();
    });
    $("quickSet").addEventListener("change", function (e) {
      var set = SETS[e.target.value];
      if (set) set.forEach(function (p) {
        var sp = S.byId(p[0]);
        if (!sp) return;
        var s = sp.sizes[p[1]] || sp.sizes[0];
        addToBatch(p[0], s.w, s.h);
      });
      e.target.value = "";
      update();
    });
    $("clearBatch").addEventListener("click", function () { state.batch = []; update(); });
    $("createBatch").addEventListener("click", function () { doCreate(state.batch.slice()); });

    $("srcLink").addEventListener("click", function (e) {
      if (CEP || AD) { e.preventDefault(); openExternal(this.href); }
    });

    var raf = 0;
    window.addEventListener("resize", function () {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(renderPreview);
    });
  }

  // Load the host script explicitly too (covers panels reloaded from debug)
  function loadHostScript() {
    if (AD || !CEP || !H.jsx) return;
    try {
      var ext = CEP.getSystemPath("extension").replace(/\\/g, "/");
      var isWin = /^Win/.test(navigator.platform);
      if (/^file:/.test(ext)) ext = decodeURI(ext.replace(/^file:\/\/\/?/, isWin ? "" : "/"));
      evalHost('$.evalFile("' + ext + '/jsx/host.jsx")');
    } catch (e) {}
  }

  // ── Spec & panel update check ───────────────────────────────────────
  // A small public JSON file on GitHub holds the latest Meta/TikTok/YouTube/LinkedIn specs.
  // The panel checks it on open; new specs apply with one click, no reinstall.
  // feedproof-specs.json (v1.3+) skips platforms a panel doesn't know, so new platforms can't break it.
  // feedproof-feed.json stays for v1.2.x panels; specs-feed.json for Safe Zones v1.1.x.
  var FEED_URL = "https://raw.githubusercontent.com/edgarfebus-hub/feedproof/main/feedproof-specs.json";
  var FEED_KEY = "feedproof.feed";
  var DISMISS_KEY = "feedproof.dismissed";

  function semverGt(a, b) {
    var x = String(a).split("."), y = String(b).split(".");
    for (var i = 0; i < 3; i++) {
      var d = (parseInt(x[i], 10) || 0) - (parseInt(y[i], 10) || 0);
      if (d) return d > 0;
    }
    return false;
  }
  function isDate(v) { return typeof v === "string" && /^\d{4}-\d{2}-\d{2}$/.test(v); }
  function prettyDate(v) {
    var m = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    var p = String(v).split("-");
    return m[parseInt(p[1], 10) - 1] + " " + parseInt(p[2], 10) + ", " + p[0];
  }
  function monthLabel(v) { var p = prettyDate(v).split(" "); return p[0] + " " + p[2]; }

  // Use specs downloaded earlier, if they're newer than the ones built in
  function applyCachedFeed() {
    var f = null;
    try { f = JSON.parse(localStorage.getItem(FEED_KEY) || "null"); } catch (e) {}
    if (!f || !isDate(f.specsVersion) || f.specsVersion <= S.SPECS_VERSION) return;
    S.load(f.specs, { version: f.specsVersion, source: "update", checked: monthLabel(f.specsVersion) });
    if (!S.byId(state.specId)) { state.platform = "meta"; state.ratio = "9:16"; state.specId = "meta-916-unified"; state.sizeKey = "0"; }
  }

  // Server date from the response (Date header; Expires − 5 min where Date is hidden by CORS)
  function serverTime(r) {
    try {
      var d = Date.parse(r.headers.get("date") || "");
      if (d > 0) return d;
      var x = Date.parse(r.headers.get("expires") || "");
      if (x > 0) return x - 300000;
    } catch (e) {}
    return 0;
  }

  function fetchFeed() {
    if (LIC && LIC.status().state === "expired") return Promise.reject(new Error("evaluation ended"));
    return new Promise(function (resolve, reject) {
      var done = false;
      var timer = setTimeout(function () { if (!done) { done = true; reject(new Error("timeout")); } }, 8000);
      fetch(FEED_URL + "?t=" + Date.now(), { cache: "no-store" })
        .then(function (r) {
          if (LIC) {
            var st = LIC.observeServerTime(serverTime(r));
            saveLicense();
            if (st.state === "expired") { showExpired(); throw new Error("evaluation ended"); }
          }
          if (!r.ok) throw new Error("HTTP " + r.status);
          return r.json();
        })
        .then(function (j) { if (!done) { done = true; clearTimeout(timer); resolve(j); } })
        .catch(function (e) { if (!done) { done = true; clearTimeout(timer); reject(e); } });
    });
  }

  function showBanner(feed, specsNew, panelNew) {
    var box = $("updateBanner");
    box.innerHTML = "";
    var add = function (tag, cls, text) {
      var el = document.createElement(tag);
      if (cls) el.className = cls;
      if (text != null) el.textContent = text;   // feed text is never parsed as HTML
      box.appendChild(el);
      return el;
    };
    if (specsNew) {
      add("div", "ub-title", "Spec update · " + prettyDate(feed.specsVersion));
      var current = S.active().version;
      var list = (Array.isArray(feed.changes) ? feed.changes : []).filter(function (c) {
        return c && isDate(c.date) && c.date > current && typeof c.text === "string";
      }).slice(0, 6);
      if (list.length) {
        var ul = add("ul", "ub-list");
        list.forEach(function (c) {
          var li = document.createElement("li");
          li.textContent = c.text.slice(0, 220);
          ul.appendChild(li);
        });
      }
    }
    if (panelNew) {
      add("div", "ub-title", "Panel v" + String(feed.panel.latest).slice(0, 12) + " available");
      if (typeof feed.panel.notes === "string") add("div", "ub-note", feed.panel.notes.slice(0, 240));
    }
    var row = add("div", "ub-actions");
    if (specsNew) {
      var ap = mkBtn();
      ap.className = "ub-apply";
      ap.textContent = "Apply update";
      ap.addEventListener("click", function () {
        var ok = S.load(feed.specs, { version: feed.specsVersion, source: "update", checked: monthLabel(feed.specsVersion) });
        if (!ok) { setStatus("The update couldn't be applied (invalid data). Your current specs are unchanged.", "err"); return; }
        try { localStorage.setItem(FEED_KEY, JSON.stringify({ specsVersion: feed.specsVersion, specs: feed.specs })); } catch (e) {}
        if (!S.byId(state.specId)) { state.platform = "meta"; state.ratio = "9:16"; state.specId = "meta-916-unified"; state.sizeKey = "0"; }
        setHidden(box, true);
        update();
        renderAbout(panelNew);
        setStatus("Specs updated to " + prettyDate(feed.specsVersion) + ".", "ok");
      });
      row.appendChild(ap);
    }
    if (panelNew && typeof feed.panel.url === "string" && /^https:\/\//.test(feed.panel.url)) {
      var dl = mkBtn();
      dl.className = "ub-link";
      dl.textContent = "Get panel";
      dl.addEventListener("click", function () { openExternal(feed.panel.url); });
      row.appendChild(dl);
    }
    var later = mkBtn();
    later.className = "ub-later";
    later.textContent = "Later";
    later.addEventListener("click", function () {
      try { localStorage.setItem(DISMISS_KEY, (specsNew ? feed.specsVersion : "") + "|" + (panelNew ? feed.panel.latest : "")); } catch (e) {}
      setHidden(box, true);
    });
    row.appendChild(later);
    setHidden(box, false);
  }

  var lastFeed = null;
  function checkForUpdates(manual) {
    if (manual) setStatus("Checking for updates…", "");
    fetchFeed().then(function (feed) {
      if (!feed || typeof feed !== "object" || !isDate(feed.specsVersion)) throw new Error("bad feed");
      lastFeed = feed;
      var specsNew = feed.specsVersion > S.active().version && S.validate(feed.specs);
      var panelNew = !!(feed.panel && typeof feed.panel.latest === "string" && semverGt(feed.panel.latest, VERSION));
      var dismissed = "";
      try { dismissed = localStorage.getItem(DISMISS_KEY) || ""; } catch (e) {}
      var key = (specsNew ? feed.specsVersion : "") + "|" + (panelNew ? feed.panel.latest : "");
      if ((specsNew || panelNew) && (manual || key !== dismissed)) showBanner(feed, specsNew, panelNew);
      else if (manual) setStatus("You're up to date — specs " + prettyDate(S.active().version) + ", panel v" + VERSION + ".", "ok");
      renderAbout(specsNew || panelNew);
    }).catch(function () {
      if (manual) setStatus("Couldn't reach the update server. Your current specs still work.", "err");
    });
  }

  function renderAbout(pending) {
    var a = S.active();
    $("specsInfo").textContent = "Specs " + prettyDate(a.version) + (a.source === "update" ? " (updated)" : "");
    $("checkUpdates").textContent = pending ? "Update available" : "Check for updates";
    $("checkUpdates").className = "link" + (pending ? " pending" : "");
  }

  // Self-check: make sure the script the app is running matches this panel.
  // Adobe apps keep old scripts in memory until fully quit.
  function selfCheck(attempt) {
    if (AD) {
      if (H.jsx) setStatus("Feedproof v" + VERSION + " · " + H.name + " · ready", "ok");
      return;
    }
    if (!CEP || !H.jsx) return;
    runJob({ action: "ping" }).then(function (res) {
      var p = String(res).split("|");
      if (p[0] === "OK" && p[1] === VERSION) {
        setStatus("Feedproof v" + VERSION + " · " + H.name + " · ready", "ok");
        return;
      }
      if (p[0] === "ERR" && (p[1] === "collision" || p[1] === "dispatch")) {
        setStatus("Script self-test failed (" + p[2] + "). Send Claude a screenshot.", "err");
        lockButtons();
        return;
      }
      if (p[0] === "OK") {
        // The app answered with a different version: a stale copy is loaded.
        setStatus("The panel is v" + VERSION + " but " + H.name + " is running v" + p[1] +
          " of its script. Quit " + H.name + " completely (⌘Q), reopen it, then open this panel again.", "err");
        lockButtons();
        return;
      }
      // No usable answer yet — the app may still be starting up. Keep trying (~30 s).
      if (attempt < 15) {
        if (attempt === 2) setStatus("Waiting for " + H.name + " to finish loading…", "");
        setTimeout(function () { selfCheck(attempt + 1); }, 2000);
      } else {
        setStatus(H.name + " isn't answering the panel. Close and reopen the panel; if it persists, restart " + H.name + ".", "err");
      }
    });
  }

  function lockButtons() {
    ["createBtn", "applyBtn", "toggleBtn", "createBatch"].forEach(function (id) { setDis($(id), true); });
  }

  // ── License screens ─────────────────────────────────────────────────
  function showBody(on) { setHidden($("panelBody"), !on); setHidden($("gate"), on); }

  function renderLegal() {
    var bar = $("legalBar");
    if (!LIC) { setHidden(bar, true); return; }
    bar.textContent = LIC.footer();
    setHidden(bar, false);
    document.body.classList.add("has-legal");
    fitLegal();
    window.addEventListener("resize", fitLegal);
  }
  // Fixed-footer layouts (CEP, Figma): the status line sits right on top of the legal
  // line, however many lines it wraps to. (UXP stacks them in its flex column.)
  function fitLegal() {
    if (AD && AD.divButtons) { if (window.SZUXP && window.SZUXP.fitScroll) window.SZUXP.fitScroll(); return; }
    var bar = $("legalBar"), st = $("status");
    if (!bar || bar.hidden) return;
    var h = bar.offsetHeight || 22;
    st.style.bottom = h + "px";
    document.querySelector("main").style.paddingBottom = (h + 64) + "px";
  }

  function gateEl(cls) {
    var g = $("gate");
    g.innerHTML = "";
    g.className = "gate " + cls;
    showBody(false);
    return g;
  }
  function addEl(parent, tag, cls, text) {
    var el = document.createElement(tag);
    if (cls) el.className = cls;
    if (text != null) el.textContent = text;
    parent.appendChild(el);
    return el;
  }

  function showAgreement() {
    var t = LIC.agreement();
    var g = gateEl("gate-agree");
    addEl(g, "div", "gate-title", t.title);
    t.paragraphs.forEach(function (p, i) { addEl(g, "p", i === 0 ? "gate-copy" : "", p); });
    var b = mkBtn();
    b.className = "primary gate-btn";
    b.textContent = t.button;
    b.addEventListener("click", function () {
      if (evalExpired()) return;
      LIC.accept();
      saveLicense().then(function () { startPanel(); });
    });
    g.appendChild(b);
    setStatus(LIC.agreePrompt(), "");
  }

  var expiredShown = false;
  function showExpired() {
    if (expiredShown) return;
    expiredShown = true;
    var g = gateEl("gate-expired");
    addEl(g, "div", "gate-title", LIC.expiredTitle());
    addEl(g, "p", "", LIC.expiredMessage());
    addEl(g, "p", "gate-note", "Everything you already made with Feedproof stays in your files, untouched.");
    ["createBtn", "applyBtn", "toggleBtn", "createBatch", "pngBtn"].forEach(function (id) { var b = $(id); if (b) setDis(b, true); });
    setStatus("Evaluation ended.", "err");
  }

  function renderReminder() {
    var box = $("trialBanner");
    var st = LIC ? LIC.status() : null;
    if (!st || !st.reminder) { setHidden(box, true); return; }
    box.textContent = LIC.reminderMessage();
    setHidden(box, false);
  }

  // The normal panel — only after the license allows it
  var started = false;
  function startPanel() {
    showBody(true);
    renderReminder();
    try { window.scrollTo(0, 0); document.querySelector("main").scrollTop = 0; } catch (e) {}
    if (started) return;
    started = true;
    applyCachedFeed();
    wire();
    update();
    renderAbout();
    loadHostScript();
    selfCheck(0);
    setTimeout(function () { checkForUpdates(false); }, 1200);
    $("checkUpdates").addEventListener("click", function () {
      try { localStorage.removeItem(DISMISS_KEY); } catch (e) {}
      checkForUpdates(true);
    });
    // re-check now and then while the panel stays open
    if (LIC) setInterval(function () { if (!evalExpired()) renderReminder(); }, 15 * 60000);
  }

  renderHost();
  renderLegal();
  $("siteLink").addEventListener("click", function (e) { e.preventDefault(); openExternal("https://edgarfebus.com"); });
  if (!LIC) startPanel();
  else {
    showBody(false);
    window.FPLicense.readAll(LSTORES).then(function (records) {
      var st = LIC.load(records);
      return saveLicense().then(function () { return st; });
    }).then(function (st) {
      if (st.state === "expired") showExpired();
      else if (st.state === "agree") showAgreement();
      else startPanel();
    });
  }

  // test hook
  window.SZPanel = { drawTrialWatermark: drawTrialWatermark, license: LIC, state: state, update: update, buildGeo: buildGeo, makeItem: makeItem, itemName: itemName, opts: opts, renderPngDataUrl: renderPngDataUrl };
})();
