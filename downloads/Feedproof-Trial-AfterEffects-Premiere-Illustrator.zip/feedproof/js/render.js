/*
 * Feedproof — Meta, TikTok & YouTube safe zones
 * © 2026 Edgar Febus. All rights reserved.
 * https://edgarfebus.com
 */
/*
 * Feedproof — canvas renderer
 * Draws a geometry object onto a 2D canvas context. Used for the live
 * preview in the panel and for the transparent PNG overlays (Premiere,
 * "Export PNG").
 */
(function (root) {
  var COLORS = {
    ui: "#ff3b30",
    estimate: "#ff7a1a",
    comfort: "#ffb020",
    safe: "#2fd16b",
    guide: "#22c3ff",
    crop: "#e45cff",
    label: "#ffffff"
  };

  function hexToRgb(hex) {
    var h = hex.replace("#", "");
    return [parseInt(h.substr(0, 2), 16), parseInt(h.substr(2, 2), 16), parseInt(h.substr(4, 2), 16)];
  }

  function rgba(hex, a) {
    var c = hexToRgb(hex);
    return "rgba(" + c[0] + "," + c[1] + "," + c[2] + "," + a + ")";
  }

  // Every mask is red: the message is always "keep clear". How solid the numbers are
  // (official / estimate / padding) is shown by the badge, not the mask colour.
  function zoneColor(kind) {
    return COLORS.ui;
  }

  /**
   * opts: {
   *   scale: number (canvas px per frame px),
   *   mode: "guides" | "mask" | "both",
   *   outline: bool, labels: bool, opacity: 0-100,
   *   background: bool (preview backdrop), hatch: bool
   * }
   */
  function draw(ctx, g, opts) {
    var s = opts.scale || 1;
    var W = g.W * s, H = g.H * s;
    var op = (opts.opacity == null ? 35 : opts.opacity) / 100;
    var showMask = opts.mode !== "guides";
    var showGuides = opts.mode !== "mask";

    ctx.save();
    ctx.clearRect(0, 0, W, H);

    if (opts.background) {
      var grd = ctx.createLinearGradient(0, 0, W, H);
      grd.addColorStop(0, "#2a2d34");
      grd.addColorStop(1, "#16181c");
      ctx.fillStyle = grd;
      ctx.fillRect(0, 0, W, H);
      // faint 10% grid so proportions read at a glance
      ctx.strokeStyle = "rgba(255,255,255,0.05)";
      ctx.lineWidth = 1;
      for (var i = 1; i < 10; i++) {
        ctx.beginPath(); ctx.moveTo(Math.round(W * i / 10) + 0.5, 0); ctx.lineTo(Math.round(W * i / 10) + 0.5, H); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(0, Math.round(H * i / 10) + 0.5); ctx.lineTo(W, Math.round(H * i / 10) + 0.5); ctx.stroke();
      }
    }

    // ── Unsafe zones (mask) ──
    if (showMask) {
      g.zones.forEach(function (z) {
        var col = zoneColor(z.kind);
        ctx.fillStyle = rgba(col, z.kind === "comfort" ? op * 0.7 : op);
        ctx.fillRect(z.x * s, z.y * s, z.w * s, z.h * s);
        if (opts.hatch && z.kind !== "comfort") {
          ctx.save();
          ctx.beginPath();
          ctx.rect(z.x * s, z.y * s, z.w * s, z.h * s);
          ctx.clip();
          ctx.strokeStyle = rgba(col, Math.min(1, op + 0.15));
          ctx.lineWidth = Math.max(1, 1.2 * (opts.hatchWidth || 1));
          var step = Math.max(6, 10 * (opts.hatchStep || 1));
          for (var d = -H; d < W + H; d += step) {
            ctx.beginPath();
            ctx.moveTo(d, 0); ctx.lineTo(d + H, H);
            ctx.stroke();
          }
          ctx.restore();
        }
      });
    }

    // ── Crop guides ──
    if (g.crops && g.crops.length) {
      ctx.save();

      ctx.lineWidth = Math.max(1.5, 2 * s * (opts.exportLine || 1));
      ctx.setLineDash([Math.max(4, 14 * s), Math.max(3, 9 * s)]);
      g.crops.forEach(function (c) {
        ctx.strokeStyle = c.hex || COLORS.crop;
        ctx.strokeRect(c.x * s + ctx.lineWidth / 2, c.y * s + ctx.lineWidth / 2, c.w * s - ctx.lineWidth, c.h * s - ctx.lineWidth);
      });
      ctx.restore();
    }

    // ── Guides ──
    if (showGuides) {
      ctx.save();
      ctx.strokeStyle = COLORS.guide;
      ctx.lineWidth = Math.max(1, s * (opts.exportLine || 1));
      g.guidesX.forEach(function (x) {
        var px = Math.round(x * s) + 0.5;
        ctx.beginPath(); ctx.moveTo(px, 0); ctx.lineTo(px, H); ctx.stroke();
      });
      g.guidesY.forEach(function (y) {
        var py = Math.round(y * s) + 0.5;
        ctx.beginPath(); ctx.moveTo(0, py); ctx.lineTo(W, py); ctx.stroke();
      });
      ctx.restore();
    }

    // ── Safe outline ──
    if (opts.outline) {
      ctx.save();
      ctx.strokeStyle = COLORS.safe;
      ctx.lineWidth = Math.max(1.5, 3 * s * (opts.exportLine || 1));
      var sa = g.safe;
      ctx.strokeRect(sa.x * s + ctx.lineWidth / 2, sa.y * s + ctx.lineWidth / 2, sa.w * s - ctx.lineWidth, sa.h * s - ctx.lineWidth);
      ctx.restore();
    }

    // ── Labels ──
    if (opts.labels) {
      var fs = Math.max(9, Math.round(Math.min(g.W, g.H) * 0.026 * s));
      ctx.font = "600 " + fs + "px -apple-system, 'Segoe UI', Roboto, sans-serif";
      ctx.textBaseline = "top";
      g.zones.forEach(function (z) {
        if (!z.label) return;
        var zw = z.w * s, zh = z.h * s;
        if (zh < fs * 1.6 || zw < fs * 8) return; // too narrow to label legibly
        var pad = Math.max(4, fs * 0.5);
        var text = z.label;
        var px = zoneMeasure(z, g);
        var maxW = zw - pad * 2;
        if (ctx.measureText(text).width > maxW) {
          while (text.length > 4 && ctx.measureText(text + "…").width > maxW) text = text.slice(0, -1);
          text += "…";
        }
        ctx.fillStyle = "rgba(0,0,0,0.55)";
        var tw = ctx.measureText(text).width;
        var tx = z.x * s + pad, ty = z.y * s + pad;
        ctx.fillRect(tx - 3, ty - 2, tw + 6, fs + 4);
        ctx.fillStyle = COLORS.label;
        ctx.fillText(text, tx, ty);
        // pixel measurement under the label
        if (zh > fs * 3.2) {
          ctx.font = "500 " + Math.round(fs * 0.85) + "px -apple-system, 'Segoe UI', Roboto, sans-serif";
          ctx.fillStyle = "rgba(255,255,255,0.85)";
          ctx.fillText(px, tx, ty + fs + 6);
          ctx.font = "600 " + fs + "px -apple-system, 'Segoe UI', Roboto, sans-serif";
        }
      });
    }

    ctx.restore();
  }

  function zoneMeasure(z, g) {
    if (z.id === "top" || z.id === "bottom") return z.h + " px (" + Math.round(z.h / g.H * 1000) / 10 + "%)";
    if (z.id === "left" || z.id === "right") return z.w + " px (" + Math.round(z.w / g.W * 1000) / 10 + "%)";
    return z.w + " × " + z.h + " px";
  }

  var api = { draw: draw, COLORS: COLORS, hexToRgb: hexToRgb, zoneMeasure: zoneMeasure };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.SZRender = api;
})(typeof window !== "undefined" ? window : this);
