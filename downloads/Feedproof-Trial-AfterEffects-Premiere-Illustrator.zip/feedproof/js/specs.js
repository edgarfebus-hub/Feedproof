/*
 * Feedproof — Meta, TikTok, YouTube & LinkedIn safe zones
 * © 2026 Edgar Febus. All rights reserved.
 * https://edgarfebus.com
 */
/*
 * Feedproof — platform spec data
 * --------------------------------------------------------------
 * All margins are FRACTIONS of the frame (0–1), so every spec scales
 * to any delivery size. Edit this file when Meta, TikTok, YouTube or LinkedIn change their
 * guidance; the panel, overlays and host scripts all read from here.
 *
 * kind:
 *   "ui"       – official platform guidance: UI is drawn over these areas
 *   "comfort"  – no platform UI overlaps; title-safe padding only
 *   "estimate" – platform publishes template files but no pixel values;
 *                verify against the official template before relying on it
 *
 * maxSide: optional — the platform rejects files with a side longer than this
 *
 * extras: additional blocked rectangles (x1,y1 → x2,y2, fractions).
 *         They are clipped to the safe area automatically.
 */
(function (root) {
  var CHECKED = "Oct 2026";

  var SRC = {
    metaUnified: {
      title: "Meta Ads Guide — Reels/Stories safe zone (unified Mar 2026)",
      url: "https://www.facebook.com/business/ads-guide/update/image/instagram-story"
    },
    metaStories: {
      title: "Meta Ads Guide — Stories (legacy 20% bottom)",
      url: "https://www.facebook.com/business/ads-guide/update/image/instagram-story"
    },
    metaFeed: {
      title: "Meta Ads Guide — Feed (no UI over media)",
      url: "https://www.facebook.com/business/ads-guide/update"
    },
    tiktokInFeed: {
      title: "TikTok Auction In-Feed Ads — In-Feed Standard template (720×1280)",
      url: "https://ads.tiktok.com/help/article/tiktok-auction-in-feed-ads"
    },
    tiktokTopView: {
      title: "TikTok TopView ad specifications",
      url: "https://ads.tiktok.com/help/"
    },
    tiktokCard: {
      title: "TikTok Download Card add-on — square safe zone (640×640)",
      url: "https://ads.tiktok.com/help/article/tiktok-interactive-add-on-download-card-ad-specifications"
    },
    ytUniversal: {
      title: "Google Ads Help — About video ad specs (universal safe zones)",
      url: "https://support.google.com/google-ads/answer/13547298"
    },
    ytShorts: {
      title: "Google — YouTube Shorts ads (red zones: top 10%, bottom 25%, right 10%)",
      url: "https://business.google.com/us/ad-solutions/youtube-ads/shorts-ads/"
    },
    ytDemandGen: {
      title: "Google Ads Help — Demand Gen asset specs (4:5 accepted, no safe zone published)",
      url: "https://support.google.com/google-ads/answer/13704860"
    },
    liVideo: {
      title: "LinkedIn Video Ads specs (sizes only — LinkedIn publishes no safe zone)",
      url: "https://business.linkedin.com/advertise/ads/sponsored-content/video-ads/specs"
    }
  };

  // Built-in spec data. A newer set can arrive from the online feed (see main.js).
  var BUILTIN = [
    // ───────────────────────────── META ─────────────────────────────
    {
      id: "meta-916-unified",
      platform: "meta",
      ratio: "9:16",
      name: "Reels + Stories (unified)",
      kind: "ui",
      margins: { top: 0.14, bottom: 0.35, left: 0.06, right: 0.06 },
      labels: {
        top: "Profile · name · Sponsored",
        bottom: "Caption · CTA · likes/comments · audio",
        left: "Side margin",
        right: "Side margin"
      },
      extras: [],
      sizes: [
        { w: 1080, h: 1920, label: "1080 × 1920" },
        { w: 1440, h: 2560, label: "1440 × 2560 (Meta recommended)" }
      ],
      note: "One zone for Facebook + Instagram Reels and Stories since March 2026. Built on Reels, the tightest placement.",
      source: SRC.metaUnified
    },
    {
      id: "meta-916-stories",
      platform: "meta",
      ratio: "9:16",
      name: "Stories only (20% bottom)",
      kind: "ui",
      margins: { top: 0.14, bottom: 0.20, left: 0.06, right: 0.06 },
      labels: {
        top: "Profile · name · close",
        bottom: "CTA · reply bar",
        left: "Side margin",
        right: "Side margin"
      },
      extras: [],
      sizes: [
        { w: 1080, h: 1920, label: "1080 × 1920" },
        { w: 1440, h: 2560, label: "1440 × 2560 (Meta recommended)" }
      ],
      note: "Only safe if the ad will never run in Reels. Anything in the 20–35% band is covered in Reels.",
      source: SRC.metaStories
    },
    {
      id: "meta-916-disclaimer",
      platform: "meta",
      ratio: "9:16",
      name: "Reels with disclaimer (40% bottom)",
      kind: "ui",
      margins: { top: 0.14, bottom: 0.40, left: 0.06, right: 0.06 },
      labels: {
        top: "Profile · name · Sponsored",
        bottom: "Disclaimer · caption · CTA",
        left: "Side margin",
        right: "Side margin"
      },
      extras: [],
      sizes: [
        { w: 1080, h: 1920, label: "1080 × 1920" },
        { w: 1440, h: 2560, label: "1440 × 2560 (Meta recommended)" }
      ],
      note: "Meta's guidance for Reels ads that carry a disclaimer: keep the bottom 40% clear. Useful for pharma/regulated work.",
      source: SRC.metaUnified
    },
    {
      id: "meta-45-feed",
      platform: "meta",
      ratio: "4:5",
      name: "Feed (Facebook + Instagram)",
      kind: "comfort",
      margins: { top: 0.05, bottom: 0.05, left: 0.05, right: 0.05 },
      labels: { top: "Title-safe 90%", bottom: "Title-safe 90%", left: "", right: "" },
      extras: [],
      sizes: [
        { w: 1080, h: 1350, label: "1080 × 1350" },
        { w: 1440, h: 1800, label: "1440 × 1800 (Meta recommended)" }
      ],
      note: "Meta draws no UI over Feed media — the margin is title-safe padding, not a platform requirement.",
      source: SRC.metaFeed
    },
    {
      id: "meta-11-feed",
      platform: "meta",
      ratio: "1:1",
      name: "Feed · Carousel · Marketplace",
      kind: "comfort",
      margins: { top: 0.05, bottom: 0.05, left: 0.05, right: 0.05 },
      labels: { top: "Title-safe 90%", bottom: "Title-safe 90%", left: "", right: "" },
      extras: [],
      sizes: [
        { w: 1080, h: 1080, label: "1080 × 1080" },
        { w: 1440, h: 1440, label: "1440 × 1440 (Meta recommended)" }
      ],
      note: "No UI over the media. Margin is title-safe padding only.",
      source: SRC.metaFeed
    },
    {
      id: "meta-169-instream",
      platform: "meta",
      ratio: "16:9",
      name: "In-stream video",
      kind: "comfort",
      margins: { top: 0.05, bottom: 0.05, left: 0.05, right: 0.05 },
      labels: { top: "Title-safe 90%", bottom: "Title-safe 90%", left: "", right: "" },
      extras: [],
      sizes: [
        { w: 1920, h: 1080, label: "1920 × 1080" },
        { w: 1280, h: 720, label: "1280 × 720 (minimum)" }
      ],
      note: "No UI over the media. Margin is title-safe padding only.",
      source: SRC.metaFeed
    },

    // ──────────────────────────── TIKTOK ────────────────────────────
    {
      id: "tiktok-916-infeed",
      platform: "tiktok",
      ratio: "9:16",
      name: "In-Feed / Spark (standard)",
      kind: "ui",
      // TikTok template on 720×1280: 160 top, 440 bottom, 80 sides,
      // action rail 120 px wide (x 520–640) from y 560 down.
      margins: { top: 160 / 1280, bottom: 440 / 1280, left: 80 / 720, right: 80 / 720 },
      labels: {
        top: "Following / For You · search",
        bottom: "Name · caption · Sponsored · CTA",
        left: "Side margin",
        right: "Side margin"
      },
      extras: [
        { label: "Action rail — profile · like · comment · share", x1: 520 / 720, y1: 560 / 1280, x2: 640 / 720, y2: 1 }
      ],
      sizes: [
        { w: 1080, h: 1920, label: "1080 × 1920 (TikTok recommended)" },
        { w: 1440, h: 2560, label: "1440 × 2560 (same as Meta)" },
        { w: 720, h: 1280, label: "720 × 1280 (template native)" },
        { w: 2160, h: 3840, label: "2160 × 3840 (4K master)" }
      ],
      note: "Verified pixel-for-pixel against TikTok's In-Feed Standard template (Feed.png, Apr 2025). Longer captions shrink the zone; use the anchor template if the ad carries an anchor.",
      source: SRC.tiktokInFeed
    },
    {
      id: "tiktok-916-topview",
      platform: "tiktok",
      ratio: "9:16",
      name: "TopView — first 3 seconds",
      kind: "ui",
      margins: { top: 160 / 1280, bottom: 160 / 1280, left: 80 / 720, right: 80 / 720 },
      labels: { top: "Open-screen UI", bottom: "Open-screen UI", left: "Side margin", right: "Side margin" },
      extras: [],
      sizes: [
        { w: 1080, h: 1920, label: "1080 × 1920 (TikTok recommended)" },
        { w: 1440, h: 2560, label: "1440 × 2560 (same as Meta)" },
        { w: 720, h: 1280, label: "720 × 1280 (template native)" }
      ],
      note: "Open-screen phase only. After 3 s TopView switches to the In-Feed layout — design end frames to In-Feed.",
      source: SRC.tiktokTopView
    },
    {
      id: "tiktok-11-infeed",
      platform: "tiktok",
      ratio: "1:1",
      name: "In-Feed square",
      kind: "estimate",
      margins: { top: 60 / 640, bottom: 130 / 640, left: 60 / 640, right: 140 / 640 },
      labels: { top: "Top margin", bottom: "Caption · CTA", left: "Side margin", right: "Action rail" },
      extras: [],
      sizes: [
        { w: 1080, h: 1080, label: "1080 × 1080" },
        { w: 640, h: 640, label: "640 × 640 (minimum)" }
      ],
      note: "TikTok ships square safe zones only as template files. These values come from its published square Download Card zone (60/130/60/140 px on 640×640). The In-Feed Standard zip ships only a vertical template, so this stays an estimate.",
      source: SRC.tiktokCard
    },
    {
      id: "tiktok-169-infeed",
      platform: "tiktok",
      ratio: "16:9",
      name: "In-Feed horizontal",
      kind: "estimate",
      margins: { top: 0.10, bottom: 0.20, left: 0.08, right: 0.15 },
      labels: { top: "Top margin", bottom: "Caption · CTA", left: "Side margin", right: "Action rail" },
      extras: [],
      sizes: [
        { w: 1920, h: 1080, label: "1920 × 1080" },
        { w: 960, h: 540, label: "960 × 540 (minimum)" }
      ],
      note: "TikTok publishes no pixel values for 16:9 — this is a conservative placeholder. The In-Feed Standard zip ships only a vertical template, so check a platform preview before final delivery.",
      source: SRC.tiktokInFeed
    },

    // ─────────────────────────── YOUTUBE ────────────────────────────
    {
      id: "yt-916-universal",
      platform: "youtube",
      ratio: "9:16",
      name: "Shorts + vertical ads (universal)",
      kind: "ui",
      // Google universal vertical safe zone on 1080×1920: 288 top, 672 bottom, 48 left, 192 right
      margins: { top: 288 / 1920, bottom: 672 / 1920, left: 48 / 1080, right: 192 / 1080 },
      labels: {
        top: "Channel · Sponsored · search",
        bottom: "Title · CTA · ad info",
        left: "Side margin",
        right: "Like · comment · share"
      },
      extras: [],
      sizes: [
        { w: 1080, h: 1920, label: "1080 × 1920 (Google recommended)" },
        { w: 1440, h: 2560, label: "1440 × 2560 (same as Meta)" },
        { w: 2160, h: 3840, label: "2160 × 3840 (4K master)" },
        { w: 720, h: 1280, label: "720 × 1280 (minimum)" }
      ],
      note: "Google's universal vertical safe zone (288/672/48/192 px on 1080×1920) — one zone for Shorts ads and vertical in-stream / Demand Gen on every screen.",
      source: SRC.ytUniversal
    },
    {
      id: "yt-916-shorts-min",
      platform: "youtube",
      ratio: "9:16",
      name: "Shorts ads — minimum (10/25/10%)",
      kind: "ui",
      margins: { top: 0.10, bottom: 0.25, left: 0, right: 0.10 },
      labels: {
        top: "Channel name",
        bottom: "Caption · CTA",
        left: "",
        right: "Engagement buttons"
      },
      extras: [],
      sizes: [
        { w: 1080, h: 1920, label: "1080 × 1920 (Google recommended)" },
        { w: 1440, h: 2560, label: "1440 × 2560 (same as Meta)" },
        { w: 720, h: 1280, label: "720 × 1280 (minimum)" }
      ],
      note: "Google's lighter Shorts-only guidance. Only safe if the ad runs in Shorts alone — the universal zone is stricter and covers every vertical placement.",
      source: SRC.ytShorts
    },
    {
      id: "yt-45-feed",
      platform: "youtube",
      ratio: "4:5",
      name: "Demand Gen vertical 4:5",
      kind: "estimate",
      // Universal vertical zone mapped onto a 4:5 frame centred in a 9:16 player, + 5% top padding
      margins: { top: 0.05, bottom: 387 / 1350, left: 48 / 1080, right: 192 / 1080 },
      labels: { top: "Title-safe padding", bottom: "Title · CTA · ad info", left: "Side margin", right: "Like · comment · share" },
      extras: [],
      sizes: [
        { w: 1080, h: 1350, label: "1080 × 1350 (Google recommended)" },
        { w: 1440, h: 1800, label: "1440 × 1800 (same as Meta)" }
      ],
      note: "Google accepts 4:5 but publishes no 4:5 safe zone. Estimate: the universal vertical zone applied to a 4:5 frame shown centred in the vertical player.",
      source: SRC.ytDemandGen
    },
    {
      id: "yt-11-square",
      platform: "youtube",
      ratio: "1:1",
      name: "Square ads",
      kind: "estimate",
      // Universal vertical zone mapped onto a square centred in a 9:16 player, + 5% top padding
      margins: { top: 0.05, bottom: 252 / 1080, left: 48 / 1080, right: 192 / 1080 },
      labels: { top: "Title-safe padding", bottom: "Title · CTA · ad info", left: "Side margin", right: "Like · comment · share" },
      extras: [],
      sizes: [
        { w: 1080, h: 1080, label: "1080 × 1080 (Google recommended)" },
        { w: 1440, h: 1440, label: "1440 × 1440 (same as Meta)" },
        { w: 480, h: 480, label: "480 × 480 (minimum)" }
      ],
      note: "Google publishes the square zone only as an overlay image. Estimate until measured against it: the universal vertical zone applied to a square shown in the vertical player.",
      source: SRC.ytUniversal
    },
    {
      id: "yt-169-instream",
      platform: "youtube",
      ratio: "16:9",
      name: "In-stream + horizontal ads (universal)",
      kind: "ui",
      // Google universal horizontal safe zone on 1920×1080: 38 top (centre), 387 bottom, 58 left, 162 right,
      // with notches in the top corners — 496 × 183 top-left, 479 × 133 top-right.
      margins: { top: 38 / 1080, bottom: 387 / 1080, left: 58 / 1920, right: 162 / 1920 },
      labels: { top: "Top edge", bottom: "Ad badge · CTA · Skip · progress bar", left: "Side margin", right: "Side margin" },
      extras: [
        { label: "Top-left notch — title · channel", x1: 0, y1: 0, x2: 496 / 1920, y2: 183 / 1080 },
        { label: "Top-right notch — player icons", x1: (1920 - 479) / 1920, y1: 0, x2: 1, y2: 133 / 1080 }
      ],
      sizes: [
        { w: 1920, h: 1080, label: "1920 × 1080 (Google recommended)" },
        { w: 3840, h: 2160, label: "3840 × 2160 (4K master)" },
        { w: 1280, h: 720, label: "1280 × 720 (minimum)" }
      ],
      note: "Google's universal horizontal safe zone (1920×1080): 38 px top, 387 bottom, 58 left, 162 right, plus top-corner notches of 496 × 183 (left) and 479 × 133 (right). Same zone on phone, TV, desktop and tablet.",
      source: SRC.ytUniversal
    },
    // ─────────────────────────── LINKEDIN ───────────────────────────
    // LinkedIn publishes sizes only. In the feed its UI sits around the video,
    // not on it; only the full-screen vertical viewer draws over the media.
    {
      id: "li-916-vertical",
      platform: "linkedin",
      ratio: "9:16",
      name: "Vertical video (full-screen viewer)",
      kind: "estimate",
      margins: { top: 0.10, bottom: 0.18, left: 0.06, right: 0.06 },
      labels: { top: "Close · sound · menu", bottom: "Name · caption · CTA · reactions", left: "Side margin", right: "Side margin" },
      extras: [],
      maxSide: 1920,
      sizes: [
        { w: 1080, h: 1920, label: "1080 × 1920 (LinkedIn max)" },
        { w: 720, h: 1280, label: "720 × 1280" }
      ],
      note: "LinkedIn publishes no safe zone. Estimate from a third-party measurement of the full-screen vertical viewer (10% top, 18% bottom, 6% sides). LinkedIn rejects any side over 1920 px.",
      source: SRC.liVideo
    },
    {
      id: "li-45-feed",
      platform: "linkedin",
      ratio: "4:5",
      name: "Feed video",
      kind: "comfort",
      margins: { top: 0.05, bottom: 0.05, left: 0.05, right: 0.05 },
      labels: { top: "Title-safe 90%", bottom: "Title-safe 90%", left: "", right: "" },
      extras: [],
      maxSide: 1920,
      sizes: [
        { w: 1080, h: 1350, label: "1080 × 1350 (LinkedIn max)" },
        { w: 720, h: 900, label: "720 × 900" }
      ],
      note: "No UI over the media in the feed — the margin is title-safe padding. LinkedIn rejects any side over 1920 px.",
      source: SRC.liVideo
    },
    {
      id: "li-11-feed",
      platform: "linkedin",
      ratio: "1:1",
      name: "Feed video",
      kind: "comfort",
      margins: { top: 0.05, bottom: 0.05, left: 0.05, right: 0.05 },
      labels: { top: "Title-safe 90%", bottom: "Title-safe 90%", left: "", right: "" },
      extras: [],
      maxSide: 1920,
      sizes: [
        { w: 1080, h: 1080, label: "1080 × 1080" },
        { w: 1920, h: 1920, label: "1920 × 1920 (LinkedIn max)" }
      ],
      note: "No UI over the media in the feed — the margin is title-safe padding. LinkedIn rejects any side over 1920 px.",
      source: SRC.liVideo
    },
    {
      id: "li-169-feed",
      platform: "linkedin",
      ratio: "16:9",
      name: "Feed video",
      kind: "comfort",
      margins: { top: 0.05, bottom: 0.05, left: 0.05, right: 0.05 },
      labels: { top: "Title-safe 90%", bottom: "Title-safe 90%", left: "", right: "" },
      extras: [],
      maxSide: 1920,
      sizes: [
        { w: 1920, h: 1080, label: "1920 × 1080 (LinkedIn max)" },
        { w: 1280, h: 720, label: "1280 × 720" }
      ],
      note: "No UI over the media in the feed — the margin is title-safe padding. LinkedIn rejects any side over 1920 px.",
      source: SRC.liVideo
    }
  ];

  // ── Combined: strictest edge of any two or all three platforms ──
  var PNAME = { meta: "Meta", tiktok: "TikTok", youtube: "YouTube", linkedin: "LinkedIn" };
  var PLETTER = { meta: "m", tiktok: "t", youtube: "y", linkedin: "l" };

  function union(parts, ratio) {
    var sides = ["top", "bottom", "left", "right"];
    var RANK = { ui: 0, comfort: 1, estimate: 2 };          // on a tie, the more certain spec sets the edge
    var m = {}, labels = {}, setters = [];
    sides.forEach(function (side) {
      var best = parts[0];
      parts.forEach(function (p) {
        var d = p.margins[side] - best.margins[side];
        if (d > 1e-9 || (Math.abs(d) <= 1e-9 && RANK[p.kind] < RANK[best.kind])) best = p;
      });
      m[side] = best.margins[side];
      labels[side] = best.labels[side];
      if (setters.indexOf(best) < 0) setters.push(best);
    });
    parts.forEach(function (p) { if ((p.extras || []).length && setters.indexOf(p) < 0) setters.push(p); });
    var seen = {}, sizes = [], extras = [], maxSide = null;
    parts.forEach(function (p) { if (p.maxSide && (maxSide === null || p.maxSide < maxSide)) maxSide = p.maxSide; });
    parts.forEach(function (p) {
      p.sizes.forEach(function (s) {
        var k = s.w + "x" + s.h;
        if (maxSide && Math.max(s.w, s.h) > maxSide) return;     // a size one of the platforms rejects
        if (!seen[k]) { seen[k] = 1; sizes.push({ w: s.w, h: s.h, label: s.w + " × " + s.h }); }
      });
      extras = extras.concat(p.extras || []);
    });
    // Only the specs that actually set an edge (or add a blocked area) decide how certain the master is
    var kinds = setters.map(function (p) { return p.kind; });
    var kind = kinds.indexOf("estimate") >= 0 ? "estimate" : kinds.indexOf("ui") >= 0 ? "ui" : "comfort";
    var names = parts.map(function (p) { return PNAME[p.platform]; });
    return {
      id: comboId(ratio, parts.map(function (p) { return p.platform; })),
      platform: "combo",
      platforms: parts.map(function (p) { return p.platform; }),
      ratio: ratio,
      name: names.join(" + "),
      kind: kind,
      margins: m,
      labels: labels,
      extras: extras,
      sizes: sizes,
      maxSide: maxSide,
      note: "Strictest edge of " + parts.map(function (p) { return p.name + " (" + PNAME[p.platform] + ")"; }).join(", ") +
        ". One master that clears " + (parts.length === 2 ? "both UIs." : "all " + parts.length + " UIs.") +
        (maxSide ? " Sizes capped at " + maxSide + " px for LinkedIn." : ""),
      source: null,
      sources: parts.map(function (p) { return p.source; }),
      parents: parts.map(function (p) { return p.id; })
    };
  }

  var SPECS_VERSION = "2026-10-21";   // date of the built-in spec data (YYYY-MM-DD)
  var RATIOS = ["9:16", "4:5", "1:1", "16:9"];
  var PLATFORM_IDS = ["meta", "tiktok", "youtube", "linkedin"];
  // The placement each platform contributes to Combined masters
  var PRIMARY = {
    "9:16": { meta: "meta-916-unified", tiktok: "tiktok-916-infeed", youtube: "yt-916-universal", linkedin: "li-916-vertical" },
    "4:5":  { meta: "meta-45-feed", youtube: "yt-45-feed", linkedin: "li-45-feed" },
    "1:1":  { meta: "meta-11-feed", tiktok: "tiktok-11-infeed", youtube: "yt-11-square", linkedin: "li-11-feed" },
    "16:9": { meta: "meta-169-instream", tiktok: "tiktok-169-infeed", youtube: "yt-169-instream", linkedin: "li-169-feed" }
  };
  // Every mix of two or more platforms, largest first (platform order kept inside each mix)
  var COMBOS = (function () {
    var out = [], n = PLATFORM_IDS.length;
    for (var mask = 1; mask < (1 << n); mask++) {
      var set = [];
      for (var b = 0; b < n; b++) if (mask & (1 << b)) set.push(PLATFORM_IDS[b]);
      if (set.length >= 2) out.push(set);
    }
    return out.sort(function (a, b) { return b.length - a.length; });
  })();
  function comboId(ratio, platforms) {
    var letters = "";
    for (var i = 0; i < PLATFORM_IDS.length; i++) if (platforms.indexOf(PLATFORM_IDS[i]) >= 0) letters += PLETTER[PLATFORM_IDS[i]];
    return "combo-" + ratio.replace(":", "") + "-" + letters;
  }

  var SPECS = [];                         // active list (mutated in place by load)
  var ACTIVE = { version: SPECS_VERSION, source: "built-in", checked: CHECKED };

  function findIn(list, id) {
    for (var i = 0; i < list.length; i++) if (list[i].id === id) return list[i];
    return null;
  }
  function byId(id) { return findIn(SPECS, id); }

  function isNum(v, lo, hi) { return typeof v === "number" && isFinite(v) && v >= lo && v <= hi; }
  function isStr(v, max) { return typeof v === "string" && v.length <= max; }

  // Strict check on spec data — anything malformed from the feed is rejected.
  function validate(list) {
    if (!Array.isArray(list) || !list.length || list.length > 60) return false;
    var seen = {}, known = 0;
    for (var i = 0; i < list.length; i++) {
      var s = list[i];
      if (!s || typeof s !== "object") return false;
      if (!isStr(s.id, 60) || !/^[a-z0-9-]+$/.test(s.id) || seen[s.id]) return false;
      seen[s.id] = 1;
      if (PLATFORM_IDS.indexOf(s.platform) < 0) continue;   // a platform added after this version: skipped, not fatal
      known++;
      if (RATIOS.indexOf(s.ratio) < 0) return false;
      if (["ui", "comfort", "estimate"].indexOf(s.kind) < 0) return false;
      if (!isStr(s.name, 80) || !isStr(s.note || "", 600)) return false;
      var m = s.margins;
      if (!m || !isNum(m.top, 0, 0.6) || !isNum(m.bottom, 0, 0.6) || !isNum(m.left, 0, 0.45) || !isNum(m.right, 0, 0.45)) return false;
      if (m.top + m.bottom >= 0.9 || m.left + m.right >= 0.9) return false;
      if (!s.labels || typeof s.labels !== "object") return false;
      var sides = ["top", "bottom", "left", "right"];
      for (var k = 0; k < 4; k++) if (!isStr(s.labels[sides[k]] || "", 80)) return false;
      if (!Array.isArray(s.sizes) || !s.sizes.length || s.sizes.length > 8) return false;
      for (var j = 0; j < s.sizes.length; j++) {
        var z = s.sizes[j];
        if (!z || !isNum(z.w, 16, 16000) || !isNum(z.h, 16, 16000) || z.w % 1 || z.h % 1 || !isStr(z.label, 60)) return false;
      }
      var ex = s.extras || [];
      if (!Array.isArray(ex) || ex.length > 6) return false;
      for (var e = 0; e < ex.length; e++) {
        var x = ex[e];
        if (!x || !isStr(x.label, 80) || !isNum(x.x1, 0, 1) || !isNum(x.y1, 0, 1) || !isNum(x.x2, 0, 1) || !isNum(x.y2, 0, 1) || x.x2 <= x.x1 || x.y2 <= x.y1) return false;
      }
      if (s.source != null) {
        if (!isStr(s.source.title, 160) || !isStr(s.source.url, 400) || !/^https:\/\//.test(s.source.url)) return false;
      }
      if (s.maxSide != null && (!isNum(s.maxSide, 16, 16000) || s.maxSide % 1)) return false;
    }
    return known > 0;
  }

  function compile(base) {
    var out = base.slice();
    RATIOS.forEach(function (r) {
      var prim = PRIMARY[r] || {};
      COMBOS.forEach(function (combo) {
        var parts = [];
        for (var i = 0; i < combo.length; i++) {
          var sp = prim[combo[i]] && findIn(base, prim[combo[i]]);
          if (!sp) return;              // a platform without this ratio → skip the combo
          parts.push(sp);
        }
        out.push(union(parts, r));
      });
    });
    return out;
  }

  // Replace the active spec list. meta = { version, source, checked }
  function load(base, meta) {
    if (!validate(base)) return false;
    var compiled = compile(base.filter(function (s) { return PLATFORM_IDS.indexOf(s.platform) >= 0; }));
    SPECS.length = 0;
    compiled.forEach(function (s) { SPECS.push(s); });
    ACTIVE = meta;
    return true;
  }

  load(BUILTIN, { version: SPECS_VERSION, source: "built-in", checked: CHECKED });

  var api = {
    SPECS: SPECS,
    BUILTIN: BUILTIN,
    SPECS_VERSION: SPECS_VERSION,
    byId: byId,
    load: load,
    validate: validate,
    active: function () { return ACTIVE; },
    RATIOS: RATIOS,
    PLATFORMS: [
      { id: "meta", label: "Meta" },
      { id: "tiktok", label: "TikTok" },
      { id: "youtube", label: "YouTube" },
      { id: "linkedin", label: "LinkedIn" },
      { id: "combo", label: "Combined" }
    ],
    PLATFORM_NAMES: PNAME,
    PLATFORM_IDS: PLATFORM_IDS,
    comboId: comboId,
    // Combined master for these platforms at this ratio (only those that offer the ratio count)
    combo: function (ratio, platforms) {
      var avail = [];
      for (var i = 0; i < PLATFORM_IDS.length; i++) {
        var p = PLATFORM_IDS[i];
        if (platforms.indexOf(p) >= 0 && PRIMARY[ratio] && PRIMARY[ratio][p] && byId(PRIMARY[ratio][p])) avail.push(p);
      }
      return avail.length >= 2 ? byId(comboId(ratio, avail)) : null;
    },
    hasRatio: function (platform, ratio) { return !!(PRIMARY[ratio] && PRIMARY[ratio][platform] && byId(PRIMARY[ratio][platform])); },
    forPlatformRatio: function (platform, ratio) {
      return SPECS.filter(function (s) { return s.platform === platform && s.ratio === ratio; });
    }
  };

  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.SZSpecs = api;
})(typeof window !== "undefined" ? window : this);
