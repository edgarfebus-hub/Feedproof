/*
 * Feedproof - platform UI preview
 * © 2026 Edgar Febus. All rights reserved.
 *
 * Draws an approximate copy of each app's on-screen interface (buttons,
 * captions, account row, call-to-action) over the frame, so a layout can be
 * judged the way it will look in the feed. Shapes are drawn from scratch to
 * match the layout of the real apps; no platform logos or artwork are used.
 * Layouts follow each app's 2026 ad UI and line up with the safe-zone specs.
 */
(function (root) {
  "use strict";

  var FONT = "-apple-system, BlinkMacSystemFont, 'SF Pro Text', 'Helvetica Neue', 'Segoe UI', Roboto, Arial, sans-serif";

  // 24x24 outline/solid glyphs, drawn for Feedproof (no third-party icon sets)
  var ICONS = {
    heart: "M12 20.5S3 15.2 3 9.2C3 6.3 5.2 4 8 4c1.7 0 3.1.8 4 2.1C12.9 4.8 14.3 4 16 4c2.8 0 5 2.3 5 5.2 0 6-9 11.3-9 11.3z",
    comment: "M12 3.5c5 0 9 3.6 9 8s-4 8-9 8c-1.3 0-2.6-.2-3.7-.7L3.5 20.5l1.4-4.2C3.7 15 3 13.3 3 11.5c0-4.4 4-8 9-8z",
    send: "M21 3 10.2 13.8M21 3l-6.8 18-4-7.2L3 9.8z",
    repost: "M17 3l3.5 3.5L17 10M3.5 12V9.5a3 3 0 0 1 3-3h14M7 21l-3.5-3.5L7 14M20.5 12v2.5a3 3 0 0 1-3 3h-14",
    bookmark: "M6.5 3.5h11v17L12 16.4l-5.5 4.1z",
    shareArrow: "M13.5 4.5 21 11.5l-7.5 7v-4C8 14.5 5 16 3 20c.5-6 3.6-10.6 10.5-11.5z",
    shareCurve: "M14 4.5l6.5 6.5-6.5 6.5M20.5 11H11a7.5 7.5 0 0 0-7.5 7.5v1",
    thumbUp: "M7.5 20.5h-3a1 1 0 0 1-1-1v-8a1 1 0 0 1 1-1h3zM7.5 10.5l3.8-7c1.6 0 2.9 1.3 2.9 2.9V9h5a2 2 0 0 1 2 2.4l-1.3 7.3a2 2 0 0 1-2 1.8H7.5",
    remix: "M4 12a8 8 0 0 1 13.8-5.5L20 8.5M20 3.5v5h-5M20 12a8 8 0 0 1-13.8 5.5L4 15.5M4 20.5v-5h5",
    back: "M20 12H4.5M10.5 5.5 4 12l6.5 6.5",
    search: "M10.5 17.5a7 7 0 1 1 0-14 7 7 0 0 1 0 14zM15.6 15.6 21 21",
    camera: "M3 8.5h4l2-3h6l2 3h4v11H3zM12 16.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7z",
    speaker: "M4 9.5h3.5L13 5v14l-5.5-4.5H4zM16.5 8.8a4.5 4.5 0 0 1 0 6.4M19 6.3a8 8 0 0 1 0 11.4",
    mute: "M4 9.5h3.5L13 5v14l-5.5-4.5H4zM16.5 9.5l5 5M21.5 9.5l-5 5",
    music: "M9 18V5.5l11-2v12.5M9 18a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0zM20 16a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0z",
    close: "M5.5 5.5l13 13M18.5 5.5l-13 13",
    plus: "M12 5v14M5 12h14",
    shareUp: "M12 15V3.5M7.5 8 12 3.5 16.5 8M5 12.5V20h14v-7.5",
    chevRight: "M9.5 5.5 16 12l-6.5 6.5",
    chevUp: "M5.5 15 12 8.5l6.5 6.5",
    chevDown: "M6 9.5 12 15.5l6-6",
    play: "M7 4.5v15l12.5-7.5z",
    skipNext: "M5 5v14l10-7zM18 5v14",
    fullscreen: "M3.5 9V3.5H9M15 3.5h5.5V9M20.5 15v5.5H15M9 20.5H3.5V15",
    info: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM12 11v6M12 7.6v.4",
    home: "M3.5 10.8 12 3.5l8.5 7.3V20.5H15V14.5H9v6H3.5z",
    friends: "M9 11a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7zM2.5 20a6.5 6.5 0 0 1 13 0M16 4.3a3.5 3.5 0 0 1 0 6.4M18 13.5a6.5 6.5 0 0 1 3.5 6.5",
    inbox: "M4 4.5h16v11H13l-4 4v-4H4z",
    profile: "M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM4.5 20.5a7.5 7.5 0 0 1 15 0",
    tv: "M3.5 7.5h17v12h-17zM8.5 3l3.5 4.5L15.5 3",
    cc: "M3.5 5.5h17v13h-17zM10.5 10a2.2 2.2 0 1 0 0 4M17 10a2.2 2.2 0 1 0 0 4"
  };
  var PATHS = {};
  function path(name) {
    if (!PATHS[name]) PATHS[name] = (typeof Path2D !== "undefined") ? new Path2D(ICONS[name]) : null;
    return PATHS[name];
  }

  // ── drawing kit, all in frame pixels ────────────────────────────────
  function kit(ctx, u) {
    function shadow(on) {
      ctx.shadowColor = on ? "rgba(0,0,0,0.45)" : "transparent";
      ctx.shadowBlur = on ? 6 * u * (ctx.getTransform ? ctx.getTransform().a : 1) : 0;
      ctx.shadowOffsetY = on ? 1 * u : 0;
    }
    var k = {
      u: u,
      icon: function (name, cx, cy, size, o) {
        o = o || {};
        var p = path(name);
        if (!p) return;
        ctx.save();
        shadow(o.shadow !== false);
        ctx.translate(cx - size / 2, cy - size / 2);
        ctx.scale(size / 24, size / 24);
        ctx.lineCap = "round"; ctx.lineJoin = "round";
        if (o.fill) { ctx.fillStyle = o.color || "#fff"; ctx.fill(p); }
        else { ctx.strokeStyle = o.color || "#fff"; ctx.lineWidth = o.weight || 2; ctx.stroke(p); }
        ctx.restore();
      },
      text: function (str, x, y, size, o) {
        o = o || {};
        ctx.save();
        shadow(o.shadow !== false);
        ctx.font = (o.weight || 400) + " " + size + "px " + FONT;
        ctx.fillStyle = o.color || "#fff";
        ctx.textAlign = o.align || "left";
        ctx.textBaseline = "middle";
        var s = String(str);
        if (o.maxW) {
          while (s.length > 4 && ctx.measureText(s).width > o.maxW) s = s.slice(0, -2);
          if (s !== String(str)) s = s.replace(/\s*\S?$/, "") + "\u2026";
        }
        ctx.fillText(s, x, y);
        var w = ctx.measureText(s).width;
        ctx.restore();
        return w;
      },
      measure: function (str, size, weight) {
        ctx.save();
        ctx.font = (weight || 400) + " " + size + "px " + FONT;
        var w = ctx.measureText(String(str)).width;
        ctx.restore();
        return w;
      },
      rect: function (x, y, w, h, r, fill, stroke, lw) {
        ctx.save();
        ctx.beginPath();
        r = Math.min(r, w / 2, h / 2);
        ctx.moveTo(x + r, y);
        ctx.arcTo(x + w, y, x + w, y + h, r);
        ctx.arcTo(x + w, y + h, x, y + h, r);
        ctx.arcTo(x, y + h, x, y, r);
        ctx.arcTo(x, y, x + w, y, r);
        ctx.closePath();
        if (fill) { ctx.fillStyle = fill; ctx.fill(); }
        if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = lw || 2 * u; ctx.stroke(); }
        ctx.restore();
      },
      circle: function (cx, cy, r, fill, stroke, lw) {
        ctx.save();
        ctx.beginPath();
        ctx.arc(cx, cy, r, 0, Math.PI * 2);
        if (fill) { ctx.fillStyle = fill; ctx.fill(); }
        if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = lw || 2 * u; ctx.stroke(); }
        ctx.restore();
      },
      // generic profile picture: soft disc with a person silhouette
      avatar: function (cx, cy, r, ring) {
        k.circle(cx, cy, r, "#c9ced6", ring ? "#fff" : null, ring ? Math.max(2 * u, r * 0.08) : 0);
        ctx.save();
        ctx.beginPath(); ctx.arc(cx, cy, r * 0.92, 0, Math.PI * 2); ctx.clip();
        ctx.fillStyle = "#8c939e";
        ctx.beginPath(); ctx.arc(cx, cy - r * 0.18, r * 0.36, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.ellipse(cx, cy + r * 0.78, r * 0.68, r * 0.52, 0, 0, Math.PI * 2); ctx.fill();
        ctx.restore();
      },
      dots: function (cx, cy, size, vertical, color) {
        ctx.save();
        shadow(true);
        ctx.fillStyle = color || "#fff";
        var g = size * 0.32, r = size * 0.085;
        for (var i = -1; i <= 1; i++) {
          ctx.beginPath();
          ctx.arc(cx + (vertical ? 0 : i * g), cy + (vertical ? i * g : 0), r, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
      },
      // paint everything outside a W x H rounded rectangle (rounded-corner mask)
      corners: function (W, H, r, color) {
        ctx.save();
        ctx.fillStyle = color;
        ctx.beginPath();
        ctx.rect(0, 0, W, H);
        ctx.moveTo(r, 0); ctx.arcTo(W, 0, W, H, r); ctx.arcTo(W, H, 0, H, r); ctx.arcTo(0, H, 0, 0, r); ctx.arcTo(0, 0, W, 0, r); ctx.closePath();
        ctx.fill("evenodd");
        ctx.restore();
      },
      ctx: ctx
    };
    return k;
  }

  // ── same kit, writing SVG instead of painting a canvas ─────────────
  // Used where there's no canvas (Photoshop / InDesign plugins) or where the
  // app should get editable vectors (Figma). Text widths are estimated.
  function xml(v) { return String(v).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  function n(v) { return Math.round(v * 100) / 100; }
  function paint(c) {                     // -> [colour, opacity] without rgba() (not every importer reads it)
    if (!c || c === "transparent" || c === "none") return ["none", 1];
    var m = /^rgba?\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*(?:,\s*([\d.]+)\s*)?\)$/.exec(c);
    if (!m) return [c, 1];
    var hx = function (v) { var h = Math.round(+v).toString(16); return h.length < 2 ? "0" + h : h; };
    return ["#" + hx(m[1]) + hx(m[2]) + hx(m[3]), m[4] == null ? 1 : +m[4]];
  }
  function fillAttr(c) { var p = paint(c); return ' fill="' + p[0] + '"' + (p[1] < 1 ? ' fill-opacity="' + n(p[1]) + '"' : ""); }
  function strokeAttr(c, w) { var p = paint(c); return ' stroke="' + p[0] + '"' + (p[1] < 1 ? ' stroke-opacity="' + n(p[1]) + '"' : "") + ' stroke-width="' + n(w) + '"'; }
  // rough Helvetica/Inter advance widths, in em
  function charW(ch, bold) {
    var w;
    if (" ".indexOf(ch) >= 0) w = 0.28;
    else if ("il.,:;'|!·".indexOf(ch) >= 0) w = 0.26;
    else if ("fjrt()[]".indexOf(ch) >= 0) w = 0.34;
    else if ("mwMW@".indexOf(ch) >= 0) w = 0.84;
    else if (/[A-Z]/.test(ch)) w = 0.66;
    else if (/[0-9]/.test(ch)) w = 0.56;
    else w = 0.53;
    return bold ? w * 1.06 : w;
  }
  function textW(str, size, weight) {
    var t = 0, s = String(str), bold = (weight || 400) >= 600;
    for (var i = 0; i < s.length; i++) t += charW(s.charAt(i), bold);
    return t * size;
  }

  function svgKit(u, font, noText) {
    // Shadows are drawn as a soft dark copy under the shape: Photoshop and InDesign
    // drop any SVG element that uses a filter, so no filters are used.
    var out = [], texts = [], ids = 0, SH = "\u0001";
    var sh = function (o) { return (o && o.shadow === false) ? "" : SH; };
    var shadowCopy = function (el) {
      return '<g transform="translate(0 ' + n(1.5 * u) + ')" opacity="0.4">' +
        el.replace(SH, "").replace(/ (fill|stroke)="(?!none)[^"]*"/g, ' $1="#000000"').replace(/ (fill|stroke)-opacity="[^"]*"/g, "") + "</g>";
    };
    var push = function (el) {
      if (el.indexOf(SH) >= 0) { out.push(shadowCopy(el)); el = el.replace(SH, ""); }
      out.push(el);
    };
    var k = {
      u: u,
      icon: function (name, cx, cy, size, o) {
        o = o || {};
        if (!ICONS[name]) return;
        var t = ' transform="translate(' + n(cx - size / 2) + " " + n(cy - size / 2) + ") scale(" + n(size / 24 * 1000) / 1000 + ')"';
        push('<path d="' + ICONS[name] + '"' + t + sh(o) +
          (o.fill ? fillAttr(o.color || "#fff") : ' fill="none"' + strokeAttr(o.color || "#fff", o.weight || 2) + ' stroke-linecap="round" stroke-linejoin="round"') + "/>");
      },
      text: function (str, x, y, size, o) {
        o = o || {};
        var weight = o.weight || 400, s = String(str);
        if (o.maxW) {
          while (s.length > 4 && textW(s, size, weight) > o.maxW) s = s.slice(0, -2);
          if (s !== String(str)) s = s.replace(/\s*\S?$/, "") + "\u2026";
        }
        var anchor = o.align === "center" ? "middle" : (o.align === "right" ? "end" : "start");
        texts.push({ s: s, x: x, y: y, size: size, weight: weight, align: o.align || "left", color: paint(o.color || "#fff"), shadow: o.shadow !== false });
        if (noText) return textW(s, size, weight);
        push('<text x="' + n(x) + '" y="' + n(y + size * 0.36) + '" font-family="' + font + '" font-size="' + n(size) +
          '" font-weight="' + weight + '" text-anchor="' + anchor + '"' + fillAttr(o.color || "#fff") + sh(o) + ">" + xml(s) + "</text>");
        return textW(s, size, weight);
      },
      measure: function (str, size, weight) { return textW(str, size, weight); },
      rect: function (x, y, w, h, r, fill, stroke, lw) {
        r = Math.max(0, Math.min(r, w / 2, h / 2));
        push('<rect x="' + n(x) + '" y="' + n(y) + '" width="' + n(w) + '" height="' + n(h) + '"' + (r ? ' rx="' + n(r) + '"' : "") +
          (fill ? fillAttr(fill) : ' fill="none"') + (stroke ? strokeAttr(stroke, lw || 2 * u) : "") + "/>");
      },
      circle: function (cx, cy, r, fill, stroke, lw) {
        push('<circle cx="' + n(cx) + '" cy="' + n(cy) + '" r="' + n(r) + '"' +
          (fill ? fillAttr(fill) : ' fill="none"') + (stroke ? strokeAttr(stroke, lw || 2 * u) : "") + "/>");
      },
      avatar: function (cx, cy, r, ring) {
        k.circle(cx, cy, r, "#c9ced6", ring ? "#fff" : null, ring ? Math.max(2 * u, r * 0.08) : 0);
        var id = "fpav" + (++ids);
        push('<clipPath id="' + id + '"><circle cx="' + n(cx) + '" cy="' + n(cy) + '" r="' + n(r * 0.92) + '"/></clipPath>' +
          '<g clip-path="url(#' + id + ')" fill="#8c939e"><circle cx="' + n(cx) + '" cy="' + n(cy - r * 0.18) + '" r="' + n(r * 0.36) + '"/>' +
          '<ellipse cx="' + n(cx) + '" cy="' + n(cy + r * 0.78) + '" rx="' + n(r * 0.68) + '" ry="' + n(r * 0.52) + '"/></g>');
      },
      dots: function (cx, cy, size, vertical, color) {
        var g = size * 0.32, r = size * 0.085, s = "<g" + SH + fillAttr(color || "#fff") + ">";
        for (var i = -1; i <= 1; i++) s += '<circle cx="' + n(cx + (vertical ? 0 : i * g)) + '" cy="' + n(cy + (vertical ? i * g : 0)) + '" r="' + n(r) + '"/>';
        push(s + "</g>");
      },
      corners: function (W, H, r, color) {
        push('<path fill-rule="evenodd"' + fillAttr(color) + ' d="M0 0H' + n(W) + "V" + n(H) + "H0Z" +
          "M" + n(r) + " 0H" + n(W - r) + "A" + n(r) + " " + n(r) + " 0 0 1 " + n(W) + " " + n(r) + "V" + n(H - r) +
          "A" + n(r) + " " + n(r) + " 0 0 1 " + n(W - r) + " " + n(H) + "H" + n(r) + "A" + n(r) + " " + n(r) + " 0 0 1 0 " + n(H - r) +
          "V" + n(r) + "A" + n(r) + " " + n(r) + " 0 0 1 " + n(r) + ' 0Z"/>');
      },
      ctx: null,
      _out: out,
      _texts: texts
    };
    return k;
  }

  // ── layouts ─────────────────────────────────────────────────────────
  // Each gets the kit, frame size and the spec's margins in pixels.
  var L = {};

  // Instagram / Facebook Reels ad (unified Reels + Stories zone: 14 / 35 / 6)
  L.metaReels = function (k, W, H, m, extra) {
    var u = k.u, b = H;
    k.text("Reels", 44 * u, 118 * u, 54 * u, { weight: 700 });
    k.icon("chevDown", (44 + k.measure("Reels", 54 * u, 700) / u + 26) * u, 122 * u, 34 * u, { weight: 2.6 });
    k.icon("camera", W - 62 * u, 118 * u, 58 * u, { weight: 1.9 });

    var rx = W - 66 * u, ic = 60 * u, step = 128 * u, y0 = b - 640 * u;
    var rail = [["heart", "12.4K"], ["comment", "318"], ["repost", "86"], ["send", "1,024"]];
    rail.forEach(function (it, i) {
      var y = y0 + i * step;
      k.icon(it[0], rx, y, ic, { weight: 1.9 });
      k.text(it[1], rx, y + 50 * u, 26 * u, { weight: 600, align: "center" });
    });
    k.dots(rx, y0 + 4 * step - 18 * u, 46 * u, false);
    k.rect(rx - 26 * u, b - 118 * u, 52 * u, 52 * u, 10 * u, "#d7dbe1", "#fff", 3 * u);
    k.icon("music", rx, b - 92 * u, 28 * u, { color: "#5b616b", shadow: false, weight: 2.4 });

    var lx = 40 * u, colW = rx - 60 * u - lx;
    var top = b - (extra ? 560 : 470) * u;
    if (extra) {
      k.rect(lx, top - 20 * u, colW, 96 * u, 10 * u, "rgba(0,0,0,0.45)");
      k.text("Important safety information and disclaimers", lx + 22 * u, top + 8 * u, 26 * u, { weight: 600, maxW: colW - 44 * u });
      k.text("appear here and can expand over the video.", lx + 22 * u, top + 46 * u, 26 * u, { maxW: colW - 44 * u });
      top += 110 * u;
    }
    k.avatar(lx + 34 * u, top + 36 * u, 34 * u, true);
    var nx = lx + 84 * u;
    var nw = k.text("yourbrand", nx, top + 20 * u, 32 * u, { weight: 700 });
    k.text("Sponsored", nx, top + 58 * u, 26 * u, { weight: 400 });
    k.rect(nx + nw + 22 * u, top - 4 * u, 124 * u, 50 * u, 12 * u, null, "#fff", 2.2 * u);
    k.text("Follow", nx + nw + 84 * u, top + 21 * u, 27 * u, { weight: 600, align: "center" });
    k.text("Your caption appears here, with the first line visible\u2026 more", lx, top + 128 * u, 30 * u, { maxW: colW });
    k.icon("music", lx + 14 * u, top + 186 * u, 26 * u, { weight: 2.2 });
    k.text("yourbrand \u00b7 Original audio", lx + 40 * u, top + 186 * u, 27 * u, { maxW: colW - 40 * u });
    var cy = top + 236 * u;
    k.rect(lx, cy, colW, 82 * u, 12 * u, "rgba(255,255,255,0.22)");
    k.text("Learn more", lx + 28 * u, cy + 41 * u, 30 * u, { weight: 600 });
    k.icon("chevRight", lx + colW - 34 * u, cy + 41 * u, 34 * u, { weight: 2.6 });
  };
  L.metaDisclaimer = function (k, W, H, m) { L.metaReels(k, W, H, m, true); };

  // Instagram / Facebook Stories ad
  L.metaStories = function (k, W, H, m) {
    var u = k.u;
    var gx = 20 * u, gap = 8 * u, n = 3, segW = (W - gx * 2 - gap * (n - 1)) / n;
    for (var i = 0; i < n; i++) k.rect(gx + i * (segW + gap), 30 * u, segW, 6 * u, 3 * u, i === 0 ? "#fff" : "rgba(255,255,255,0.4)");
    k.avatar(76 * u, 110 * u, 34 * u, false);
    var nw = k.text("yourbrand", 126 * u, 96 * u, 31 * u, { weight: 700 });
    k.text("Sponsored", 126 * u, 132 * u, 26 * u);
    k.dots(W - 150 * u, 110 * u, 48 * u, false);
    k.icon("close", W - 62 * u, 110 * u, 46 * u, { weight: 2.4 });
    var by = H - 230 * u;
    k.icon("chevUp", W / 2, by, 46 * u, { weight: 3 });
    var pw = 330 * u;
    k.rect(W / 2 - pw / 2, by + 40 * u, pw, 80 * u, 40 * u, "#fff");
    k.icon("send", W / 2 - 108 * u, by + 80 * u, 30 * u, { color: "#1b1d21", shadow: false, weight: 2.2 });
    k.text("Learn more", W / 2 + 16 * u, by + 80 * u, 30 * u, { weight: 600, color: "#1b1d21", align: "center", shadow: false });
  };

  // Instagram / Facebook feed (4:5, 1:1): header, caption and CTA sit
  // outside the media - only the sound button sits on the video
  L.metaFeed = function (k, W, H, m) {
    var u = k.u;
    k.circle(W - 56 * u, H - 56 * u, 30 * u, "rgba(20,20,20,0.6)");
    k.icon("mute", W - 56 * u, H - 56 * u, 30 * u, { shadow: false, weight: 2.2 });
    k.circle(56 * u, H - 56 * u, 30 * u, "rgba(20,20,20,0.6)");
    k.icon("profile", 56 * u, H - 56 * u, 28 * u, { shadow: false, weight: 2.2 });
  };
  // Facebook in-stream (16:9)
  L.metaInstream = function (k, W, H, m) {
    var u = k.u;
    k.rect(32 * u, H - 104 * u, 196 * u, 54 * u, 10 * u, "rgba(20,20,20,0.6)");
    k.text("Ad \u00b7 0:15", 54 * u, H - 77 * u, 28 * u, { weight: 600, shadow: false });
    k.circle(W - 70 * u, H - 77 * u, 34 * u, "rgba(20,20,20,0.6)");
    k.icon("mute", W - 70 * u, H - 77 * u, 34 * u, { shadow: false, weight: 2.2 });
    k.rect(0, H - 8 * u, W, 8 * u, 0, "rgba(255,255,255,0.35)");
    k.rect(0, H - 8 * u, W * 0.3, 8 * u, 0, "#fff");
  };

  // TikTok In-Feed ad (official template: 160 top / 440 bottom / 120 rail of 720x1280)
  L.tiktokFeed = function (k, W, H, m, topview, rtl) {
    var u = k.u, b = H;
    if (!topview) {
      k.icon("tv", 60 * u, 112 * u, 50 * u, { weight: 2 });
      var tabs = [["Explore", 0.62], ["Following", 0.62], ["For You", 1]], tw = 0, sz = 34 * u, gap = 44 * u;
      tabs.forEach(function (t) { tw += k.measure(t[0], sz, 700) + gap; });
      var tx = W / 2 - (tw - gap) / 2;
      tabs.forEach(function (t, i) {
        var w = k.text(t[0], tx, 112 * u, sz, { weight: 700, color: "rgba(255,255,255," + t[1] + ")" });
        if (i === 2) k.rect(tx + w / 2 - 28 * u, 146 * u, 56 * u, 6 * u, 3 * u, "#fff");
        tx += w + gap;
      });
      k.icon("search", W - 62 * u, 112 * u, 52 * u, { weight: 2.4 });
    } else {
      k.rect(40 * u, 70 * u, 156 * u, 46 * u, 8 * u, "rgba(0,0,0,0.4)");
      k.text("Sponsored", 118 * u, 93 * u, 26 * u, { weight: 600, align: "center", shadow: false });
    }

    var navH = topview ? 0 : 96 * u, base = b - navH;
    // right rail, centred on the template's 120-px rail
    var rx = rtl ? W * (80 + 60) / 720 : W - (W * (80 + 60) / 720);
    if (!topview) {
      k.avatar(rx, base - 885 * u, 50 * u, true);
      k.circle(rx, base - 835 * u, 19 * u, "#fe2c55");
      k.icon("plus", rx, base - 835 * u, 22 * u, { shadow: false, weight: 3.4, color: "#fff" });
      var rail = [["heart", "48.2K"], ["commentDots", "1,203"], ["bookmark", "2,567"], ["shareArrow", "3,456"]];
      rail.forEach(function (it, i) {
        var y = base - 730 * u + i * 148 * u;
        if (it[0] === "commentDots") {
          k.icon("comment", rx, y, 70 * u, { fill: true });
          [-1, 0, 1].forEach(function (d) { k.circle(rx + d * 14 * u, y, 4.5 * u, "#2a2a2a"); });
        } else k.icon(it[0], rx, y, it[0] === "bookmark" ? 64 * u : 72 * u, { fill: true });
        k.text(it[1], rx, y + 56 * u, 26 * u, { weight: 700, align: "center" });
      });
      k.circle(rx, base - 110 * u, 44 * u, "#2b2b2b", "#555", 10 * u);
      k.avatar(rx, base - 110 * u, 22 * u, false);
    }
    // bottom-left copy block (kept left of the rail)
    var lx = rtl ? rx + 90 * u : 40 * u, colW = (topview ? W - 80 * u : rtl ? W - 40 * u - lx : rx - 90 * u - lx);
    var t = base - (topview ? 300 : 420) * u;
    if (!topview) {
      k.text("@yourbrand", lx, t, 34 * u, { weight: 700 });
      k.rect(lx, t + 32 * u, 142 * u, 40 * u, 6 * u, "rgba(255,255,255,0.25)");
      k.text("Sponsored", lx + 71 * u, t + 52 * u, 24 * u, { weight: 600, align: "center", shadow: false });
      k.text("Your caption with #hashtags appears here\u2026 more", lx, t + 112 * u, 30 * u, { maxW: colW });
      k.icon("music", lx + 14 * u, t + 166 * u, 28 * u, { weight: 2.2 });
      k.text("Promoted Music", lx + 42 * u, t + 166 * u, 28 * u, { maxW: colW - 42 * u });
    }
    var cy = base - (topview ? 200 : 210) * u;
    k.rect(lx, cy, colW, 84 * u, 8 * u, "rgba(255,255,255,0.28)");
    k.text("Learn more", lx + 26 * u, cy + 42 * u, 30 * u, { weight: 700 });
    k.icon("chevRight", lx + colW - 34 * u, cy + 42 * u, 32 * u, { weight: 2.8 });
    if (navH) {
      k.rect(0, b - navH, W, navH, 0, "rgba(0,0,0,0.92)");
      var nav = [["home", "Home", true], ["friends", "Friends"], [null, ""], ["inbox", "Inbox"], ["profile", "Profile"]];
      nav.forEach(function (n, i) {
        var x = W * (i + 0.5) / 5, y = b - navH / 2;
        if (!n[0]) {
          k.rect(x - 46 * u, y - 28 * u, 92 * u, 56 * u, 14 * u, "#fff");
          k.text("+", x, y - 2 * u, 46 * u, { weight: 700, color: "#000", align: "center", shadow: false });
          return;
        }
        k.icon(n[0], x, y - 14 * u, 40 * u, { fill: !!n[2], weight: 2, shadow: false, color: n[2] ? "#fff" : "rgba(255,255,255,0.75)" });
        k.text(n[1], x, y + 26 * u, 20 * u, { weight: 600, align: "center", shadow: false, color: n[2] ? "#fff" : "rgba(255,255,255,0.75)" });
      });
    }
  };
  L.tiktokTopview = function (k, W, H, m) { L.tiktokFeed(k, W, H, m, true); };
  L.tiktokRtl = function (k, W, H, m) { L.tiktokFeed(k, W, H, m, false, true); };
  // TikTok 1:1 / 16:9 in a 9:16 feed - rail and copy over the video's right / bottom
  L.tiktokCompact = function (k, W, H, m) {
    var u = k.u, rx = W - m.right / 2;
    var y0 = m.top + (H - m.top - m.bottom) * 0.25, y1 = H - m.bottom * 0.55;
    var rail = ["heart", "comment", "bookmark", "shareArrow"], step = (y1 - y0) / (rail.length - 1);
    rail.forEach(function (n, i) {
      var y = y0 + i * step;
      k.icon(n, rx, y, 58 * u, { fill: true });
      if (n === "comment") [-1, 0, 1].forEach(function (d) { k.circle(rx + d * 11 * u, y, 3.6 * u, "#2a2a2a"); });
    });
    var lx = Math.max(m.left, 30 * u), colW = W - m.right - lx - 20 * u, t = H - m.bottom + 34 * u;
    k.text("@yourbrand \u00b7 Sponsored", lx, t, 30 * u, { weight: 700, maxW: colW });
    k.text("Your caption with #hashtags\u2026 more", lx, t + 46 * u, 27 * u, { maxW: colW });
    k.rect(lx, t + 82 * u, Math.min(colW, 620 * u), 70 * u, 8 * u, "rgba(255,255,255,0.28)");
    k.text("Learn more", lx + 22 * u, t + 117 * u, 27 * u, { weight: 700 });
  };

  // YouTube Shorts ad (universal vertical zone: 288 / 672 / 48 / 192 of 1080x1920)
  L.ytShorts = function (k, W, H, m, compact) {
    var u = k.u, b = H;
    if (!compact) {
      k.icon("back", 52 * u, 118 * u, 50 * u, { weight: 2.4 });
      k.text("Shorts", 106 * u, 118 * u, 40 * u, { weight: 700 });
      k.icon("speaker", W - 236 * u, 118 * u, 48 * u, { weight: 2.2 });
      k.icon("search", W - 146 * u, 118 * u, 48 * u, { weight: 2.4 });
      k.dots(W - 56 * u, 118 * u, 50 * u, true);
    }
    var rx = W - Math.max(m.right / 2, 58 * u);
    var rail = [["heart", "8.8K"], ["comment", "132"], ["bookmark", "Save"], ["shareCurve", "Share"], ["remix", "Remix"]];
    var step = 142 * u, y0 = b - 820 * u;
    if (compact) { step = Math.min(step, (H - m.top - 220 * u) / rail.length); y0 = b - 160 * u - step * (rail.length - 0.4); }
    rail.forEach(function (it, i) {
      var y = y0 + i * step;
      k.icon(it[0], rx, y, 58 * u, { weight: 2 });
      k.text(it[1], rx, y + 56 * u, 26 * u, { weight: 600, align: "center" });
    });
    k.rect(rx - 34 * u, b - 128 * u, 68 * u, 68 * u, 12 * u, "#d7dbe1", "#fff", 3 * u);
    k.avatar(rx, b - 94 * u, 22 * u, false);

    var lx = 36 * u, colW = rx - 70 * u - lx;
    var cy = b - 290 * u;
    k.rect(lx, cy - 64 * u, 150 * u, 40 * u, 6 * u, "rgba(0,0,0,0.45)");
    k.text("Sponsored", lx + 75 * u, cy - 44 * u, 23 * u, { weight: 600, align: "center", shadow: false });
    k.rect(lx, cy, colW, 74 * u, 37 * u, "rgba(255,255,255,0.92)");
    k.text("Learn more", lx + colW / 2, cy + 37 * u, 28 * u, { weight: 600, align: "center", color: "#0f0f0f", shadow: false });
    var ry = b - 150 * u;
    k.avatar(lx + 30 * u, ry, 30 * u, false);
    var nw = k.text("@yourbrand", lx + 72 * u, ry, 30 * u, { weight: 600 });
    k.rect(lx + 72 * u + nw + 20 * u, ry - 28 * u, 150 * u, 56 * u, 28 * u, "rgba(255,255,255,0.18)");
    k.text("Subscribe", lx + 72 * u + nw + 95 * u, ry, 26 * u, { weight: 600, align: "center", shadow: false });
    k.text("Your Short's title appears here", lx, b - 74 * u, 30 * u, { maxW: colW });
  };
  L.ytCompact = function (k, W, H, m) { L.ytShorts(k, W, H, m, true); };

  // YouTube in-stream skippable ad (16:9 player)
  L.ytInstream = function (k, W, H, m) {
    var u = k.u;
    k.avatar(66 * u, 66 * u, 36 * u, false);
    k.text("Your ad headline", 120 * u, 52 * u, 30 * u, { weight: 600 });
    k.text("Sponsored \u00b7 yourbrand.com", 120 * u, 88 * u, 24 * u, { color: "rgba(255,255,255,0.85)" });
    k.icon("info", W - 210 * u, 60 * u, 46 * u, { weight: 2 });
    k.icon("shareCurve", W - 130 * u, 60 * u, 46 * u, { weight: 2.2 });
    k.dots(W - 54 * u, 60 * u, 46 * u, true);

    var cy = H - 290 * u;
    k.rect(36 * u, cy, 520 * u, 104 * u, 10 * u, "rgba(20,20,20,0.75)");
    k.circle(92 * u, cy + 52 * u, 30 * u, "#d7dbe1");
    k.text("yourbrand.com", 140 * u, cy + 36 * u, 26 * u, { weight: 600, shadow: false });
    k.text("Sponsored", 140 * u, cy + 70 * u, 22 * u, { color: "rgba(255,255,255,0.7)", shadow: false });
    k.rect(370 * u, cy + 24 * u, 164 * u, 56 * u, 28 * u, "#3ea6ff");
    k.text("Visit site", 452 * u, cy + 52 * u, 24 * u, { weight: 600, align: "center", color: "#0f0f0f", shadow: false });

    k.rect(W - 296 * u, H - 270 * u, 260 * u, 82 * u, 4 * u, "rgba(20,20,20,0.75)", "rgba(255,255,255,0.4)", 1.5 * u);
    k.text("Skip", W - 196 * u, H - 229 * u, 32 * u, { weight: 500, align: "center", shadow: false });
    k.icon("skipNext", W - 112 * u, H - 229 * u, 36 * u, { fill: true, shadow: false });

    var py = H - 100 * u;
    k.icon("play", 58 * u, py, 44 * u, { fill: true });
    k.icon("skipNext", 132 * u, py, 38 * u, { fill: true });
    k.icon("speaker", 206 * u, py, 42 * u, { weight: 2.2 });
    k.text("0:05 / 0:15", 254 * u, py, 26 * u);
    k.icon("cc", W - 210 * u, py, 42 * u, { weight: 2 });
    k.dots(W - 134 * u, py, 40 * u, false);
    k.icon("fullscreen", W - 58 * u, py, 40 * u, { weight: 2.4 });
    k.rect(0, H - 46 * u, W, 6 * u, 0, "rgba(255,255,255,0.35)");
    k.rect(0, H - 46 * u, W * 0.33, 6 * u, 0, "#ffcc00");
  };

  // LinkedIn vertical video feed (estimate)
  L.liVertical = function (k, W, H, m) {
    var u = k.u;
    k.icon("back", 54 * u, 100 * u, 48 * u, { weight: 2.4 });
    k.dots(W - 58 * u, 100 * u, 48 * u, false);
    var lx = 40 * u, t = H - 300 * u;
    k.avatar(lx + 34 * u, t, 34 * u, false);
    var nw = k.text("Your Company", lx + 84 * u, t - 14 * u, 30 * u, { weight: 700 });
    k.text("Promoted", lx + 84 * u, t + 22 * u, 24 * u, { color: "rgba(255,255,255,0.85)" });
    k.text("+ Follow", lx + 84 * u + nw + 28 * u, t - 14 * u, 28 * u, { weight: 700 });
    k.text("Your post text appears here\u2026 see more", lx, t + 76 * u, 28 * u, { maxW: W - 80 * u });
    var acts = [["thumbUp", "Like"], ["comment", "Comment"], ["repost", "Repost"], ["send", "Send"]];
    acts.forEach(function (a, i) {
      var x = W * (i + 0.5) / 4, y = H - 96 * u;
      k.icon(a[0], x, y, 44 * u, { weight: 2 });
      k.text(a[1], x, y + 42 * u, 22 * u, { weight: 600, align: "center" });
    });
  };
  // LinkedIn feed video player (4:5, 1:1, 16:9): only the player controls sit on the media
  L.liFeed = function (k, W, H, m) {
    var u = k.u, y = H - 58 * u;
    k.rect(0, H - 110 * u, W, 110 * u, 0, "rgba(0,0,0,0.25)");
    k.icon("play", 50 * u, y, 40 * u, { fill: true });
    k.icon("speaker", 118 * u, y, 40 * u, { weight: 2.2 });
    k.text("0:15", 160 * u, y, 26 * u, { weight: 600 });
    k.icon("cc", W - 118 * u, y, 40 * u, { weight: 2 });
    k.icon("fullscreen", W - 50 * u, y, 36 * u, { weight: 2.4 });
    k.rect(0, H - 10 * u, W, 6 * u, 0, "rgba(255,255,255,0.4)");
    k.rect(0, H - 10 * u, W * 0.3, 6 * u, 0, "#fff");
  };

  // Pinterest full-screen video Pin (official zone: 270 / 790 / 65 / 195 of 1080x1920)
  L.pinVideo = function (k, W, H, m) {
    var u = k.u, b = H;
    k.icon("back", 54 * u, 118 * u, 50 * u, { weight: 2.4 });
    k.dots(W - 60 * u, 118 * u, 50 * u, false);
    var rx = W - 98 * u, rail = [["heart", "2.1K"], ["comment", "48"], ["shareUp", ""]];
    rail.forEach(function (it, i) {
      var y = b - 760 * u + i * 150 * u;
      k.icon(it[0], rx, y, 58 * u, { weight: 2 });
      if (it[1]) k.text(it[1], rx, y + 54 * u, 26 * u, { weight: 600, align: "center" });
    });
    k.dots(rx, b - 310 * u, 50 * u, false);
    var lx = 40 * u, colW = W - 230 * u - lx, t = b - 470 * u;
    k.avatar(lx + 32 * u, t, 32 * u, false);
    k.text("Promoted by", lx + 80 * u, t - 16 * u, 24 * u, { color: "rgba(255,255,255,0.85)" });
    k.text("Your Brand", lx + 80 * u, t + 18 * u, 30 * u, { weight: 700 });
    k.text("Your Pin title appears here", lx, t + 84 * u, 34 * u, { weight: 700, maxW: colW });
    k.text("A short description of the idea\u2026 more", lx, t + 132 * u, 28 * u, { maxW: colW });
    var by = b - 240 * u, gap = 20 * u, bw = (W - lx * 2 - gap) / 2;
    k.rect(lx, by, bw, 84 * u, 42 * u, "rgba(255,255,255,0.92)");
    k.text("Visit site", lx + bw / 2, by + 42 * u, 30 * u, { weight: 700, align: "center", color: "#111", shadow: false });
    k.rect(lx + bw + gap, by, bw, 84 * u, 42 * u, "#e60023");
    k.text("Save", lx + bw + gap + bw / 2, by + 42 * u, 30 * u, { weight: 700, align: "center", shadow: false });
    k.rect(lx, b - 110 * u, W - lx * 2, 6 * u, 3 * u, "rgba(255,255,255,0.35)");
    k.rect(lx, b - 110 * u, (W - lx * 2) * 0.3, 6 * u, 3 * u, "#fff");
  };
  // Pinterest feed Pin (2:3, 1:1, max width 16:9): rounded corners + sound button;
  // the title, Promoted label and buttons sit below the Pin
  L.pinFeed = function (k, W, H, m) {
    var u = k.u, r = Math.round(Math.min(W, H) * (W > H ? 0.04 : 0.068));
    k.corners(W, H, r, "#ffffff");
    var s = W > H ? 52 * u : 0.04 * W;
    k.circle(W - r - s, H - r - s, s, "rgba(20,20,20,0.6)");
    k.icon("mute", W - r - s, H - r - s, s, { shadow: false, weight: 2.2 });
  };

  var BY_SPEC = {
    "meta-916-unified": "metaReels", "meta-916-stories": "metaStories", "meta-916-disclaimer": "metaDisclaimer",
    "meta-45-feed": "metaFeed", "meta-11-feed": "metaFeed", "meta-169-instream": "metaInstream",
    "tiktok-916-infeed": "tiktokFeed", "tiktok-916-topview": "tiktokTopview", "tiktok-916-rtl": "tiktokRtl",
    "tiktok-11-infeed": "tiktokCompact", "tiktok-169-infeed": "tiktokCompact",
    "yt-916-universal": "ytShorts", "yt-916-shorts-min": "ytShorts", "yt-45-feed": "ytCompact", "yt-11-square": "ytCompact",
    "yt-169-instream": "ytInstream",
    "li-916-vertical": "liVertical", "li-45-feed": "liFeed", "li-11-feed": "liFeed", "li-169-feed": "liFeed",
    "pin-916-video": "pinVideo", "pin-23-standard": "pinFeed", "pin-45-standard": "pinFeed", "pin-11-standard": "pinFeed", "pin-169-maxwidth": "pinFeed"
  };
  var FALLBACK = {
    meta: { "9:16": "metaReels", "4:5": "metaFeed", "1:1": "metaFeed", "16:9": "metaInstream" },
    tiktok: { "9:16": "tiktokFeed", "4:5": "tiktokCompact", "1:1": "tiktokCompact", "16:9": "tiktokCompact" },
    youtube: { "9:16": "ytShorts", "4:5": "ytCompact", "1:1": "ytCompact", "16:9": "ytInstream" },
    linkedin: { "9:16": "liVertical", "4:5": "liFeed", "1:1": "liFeed", "16:9": "liFeed" },
    pinterest: { "9:16": "pinVideo", "2:3": "pinFeed", "4:5": "pinFeed", "1:1": "pinFeed", "16:9": "pinFeed" }
  };
  // Notes the panel shows under the toggle
  var NOTES = {
    metaFeed: "In the feed, the account row, caption and button sit above and below the media. Only the sound and tag buttons cover it.",
    metaInstream: "The headline and Learn more button sit below the player.",
    liFeed: "The post text and buttons sit above and below the player. Only the player controls cover it.",
    tiktokCompact: "This size plays inside the 9:16 feed. The buttons and caption cover its right and bottom edges.",
    pinFeed: "In the feed, the title, Promoted label and Save button sit below the Pin. The white corners show how Pinterest rounds it.",
    ytCompact: "Approximate. Google doesn't publish a UI layout for this size."
  };

  function layoutFor(spec) {
    if (!spec) return null;
    return BY_SPEC[spec.id] || (FALLBACK[spec.platform] && FALLBACK[spec.platform][spec.ratio]) || null;
  }

  /**
   * Draw the UI preview for `spec` on ctx, in frame pixels (W x H).
   * The caller applies any preview scaling to ctx first.
   */
  function draw(ctx, spec, W, H) {
    var key = layoutFor(spec);
    if (!key || !L[key]) return false;
    var ref = spec.ratio === "16:9" ? 1920 : 1080;
    var u = W / ref;
    var mm = spec.margins;
    var m = { top: mm.top * H, bottom: mm.bottom * H, left: mm.left * W, right: mm.right * W };
    ctx.save();
    L[key](kit(ctx, u), W, H, m);
    ctx.restore();
    return true;
  }

  /**
   * Same drawing as draw(), returned as an SVG document string (W x H px).
   * o.font: font-family list for the text (default Helvetica/Arial).
   */
  function svgParts(spec, W, H, o) {
    o = o || {};
    var key = layoutFor(spec);
    if (!key || !L[key]) return null;
    var ref = spec.ratio === "16:9" ? 1920 : 1080, u = W / ref, mm = spec.margins;
    var m = { top: mm.top * H, bottom: mm.bottom * H, left: mm.left * W, right: mm.right * W };
    var k = svgKit(u, xml(o.font || "Helvetica Neue, Helvetica, Arial, sans-serif"), !!o.noText);
    L[key](k, W, H, m);
    // near-invisible corner dots: the placed graphic always spans the full frame,
    // so apps that size it by its visible content still line it up 1:1
    var a = '<rect x="0" y="0" width="1" height="1" fill="#000000" fill-opacity="0.01"/>' +
      '<rect x="' + (W - 1) + '" y="' + (H - 1) + '" width="1" height="1" fill="#000000" fill-opacity="0.01"/>';
    var doc = '<?xml version="1.0" encoding="UTF-8"?>\n<svg xmlns="http://www.w3.org/2000/svg" width="' + W + '" height="' + H +
      '" viewBox="0 0 ' + W + " " + H + '">' + a + k._out.join("") + "</svg>";
    return { svg: doc, texts: k._texts, u: u };
  }
  /**
   * Same drawing as draw(), returned as an SVG document string (W x H px).
   * o.font: font-family list for the text (default Helvetica/Arial).
   */
  function svg(spec, W, H, o) { var p = svgParts(spec, W, H, o); return p ? p.svg : ""; }

  var api = { draw: draw, svg: svg, svgParts: svgParts, layoutFor: layoutFor, note: function (spec) { return NOTES[layoutFor(spec)] || ""; }, LAYOUTS: L };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.SZUiMock = api;
})(typeof window !== "undefined" ? window : this);
