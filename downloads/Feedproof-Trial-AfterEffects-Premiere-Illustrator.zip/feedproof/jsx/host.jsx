/*
 * Feedproof — Meta, TikTok, YouTube & LinkedIn safe zones
 * © 2026 Edgar Febus. All rights reserved.
 * https://edgarfebus.com
 */
/*
 * Feedproof — ExtendScript host layer
 * One file, four hosts. The panel computes all geometry in pixels and
 * sends a job object; this file only builds things in the host app.
 *
 *   job = {
 *     action: "create" | "apply" | "size" | "toggle",
 *     items:  [{ name, title, w, h, png, geo: { zones, guidesX, guidesY, safe, crops } }],
 *     opts:   { mode, outline, labels, opacity, fps, duration, aiOneDoc, colors, folder }
 *   }
 *
 * Returns "OK|message" or "ERR|message" (or "NONE|reason" for size).
 * ES3 only — no JSON, no Array.forEach, no indexOf.
 */

(function () {

var SZ = {};

SZ.OVERLAY_TAG = "SAFE ZONES";
SZ.PR_CLIP_NAME = "SAFE ZONE OVERLAY - disable before export";

SZ.ok = function sz_ok(m) { return "OK|" + m; };
SZ.err = function sz_err(m) { return "ERR|" + m; };

SZ.host = function sz_host() {
    try { return BridgeTalk.appName; } catch (e) { return "unknown"; }
};

SZ.VERSION = "1.4.1";

// Which app are we in? Decided by objects that exist in only one host's
// scripting model — this cannot be fooled by names or other extensions.
//   CompItem            → After Effects only
//   ProjectItemType     → Premiere Pro only
//   LayerKind           → Photoshop only
//   DocumentColorSpace  → Illustrator only (Photoshop has no such enum)
SZ.HOST_IDS = { AEFT: "aftereffects", PPRO: "premierepro", PHXS: "photoshop", PHSP: "photoshop", ILST: "illustrator" };

SZ.detect = function sz_detect(job) {
    if (typeof CompItem !== "undefined") return "aftereffects";
    if (typeof ProjectItemType !== "undefined") return "premierepro";
    if (typeof LayerKind !== "undefined" && typeof NewDocumentMode !== "undefined") return "photoshop";
    if (typeof DocumentColorSpace !== "undefined" && typeof PathItem !== "undefined") return "illustrator";
    if (job && job.host && SZ.HOST_IDS[job.host]) return SZ.HOST_IDS[job.host];
    return SZ.host();
};

SZ.pick = function sz_pick(h) {
    var table = { aftereffects: SZ.ae, photoshop: SZ.ps, illustrator: SZ.ai, premierepro: SZ.pr };
    if (table.hasOwnProperty(h)) return table[h];
    return null;
};

SZ.diag = function sz_diag(job, h) {
    return " [script v" + SZ.VERSION + ", detected " + h + ", panel " + (job && job.host) + "]";
};

SZ.trail = [];
SZ.mark = function sz_mark(name) {
    SZ.trail.push(name);
    if (SZ.trail.length > 14) SZ.trail.shift();
};

SZ.run = function sz_run(job) {
    var h = "?";
    SZ.trail = [];
    try {
        h = SZ.detect(job);
        if (job.action === "ping") {
            var mods = [SZ.ae, SZ.ps, SZ.ai, SZ.pr], acts = ["create", "apply", "size", "toggle"], a, x, y;
            for (a = 0; a < acts.length; a++)
                for (x = 0; x < mods.length; x++)
                    for (y = x + 1; y < mods.length; y++)
                        if (mods[x][acts[a]] === mods[y][acts[a]]) return "ERR|collision|" + acts[a];
            var picked = SZ.pick(h);
            var pickedName = picked === SZ.ae ? "aftereffects" : "";
            if (picked === SZ.ps) pickedName = "photoshop";
            if (picked === SZ.ai) pickedName = "illustrator";
            if (picked === SZ.pr) pickedName = "premierepro";
            if (pickedName !== h) return "ERR|dispatch|" + h + " -> " + pickedName;
            return "OK|" + SZ.VERSION + "|" + h;
        }
        var mod = SZ.pick(h);
        if (!mod) return SZ.err("Unsupported host: " + h + SZ.diag(job, h));
        if (!mod[job.action]) return SZ.err("Action not available in this app: " + job.action + SZ.diag(job, h));
        var res = mod[job.action](job);
        if (String(res).indexOf("ERR|") === 0 || String(res).indexOf("NONE|") === 0) res += SZ.diag(job, h);
        return res;
    } catch (e) {
        var src = "";
        try {
            if (e.source && e.line) src = String(e.source).split(/\r\n|\r|\n/)[e.line - 1];
            src = String(src).replace(/^\s+|\s+$/g, "").slice(0, 90);
        } catch (e2) {}
        var file = "";
        try { file = String(e.fileName || "").replace(/^.*[\/\\]/, ""); } catch (e3) {}
        return SZ.err(e.toString() + " (line " + e.line + (file ? " of " + file : "") + ")" +
            (src ? " CODE: " + src : "") +
            " TRAIL: " + SZ.trail.join(" > ") + SZ.diag(job, h));
    }
};

SZ.fontSize = function sz_fontSize(item) {
    return Math.max(14, Math.round(Math.min(item.w, item.h) * 0.026));
};

SZ.zoneColor = function sz_zoneColor(o, kind) {
    var c = o.colors[kind] || o.colors.ui;
    return [c[0], c[1], c[2]];
};

/* =====================================================================
 *  AFTER EFFECTS
 * ===================================================================== */
SZ.ae = {};

SZ.ae.size = function sz_ae_size() {
    var c = app.project.activeItem;
    if (c && c instanceof CompItem) return "OK|" + c.width + "|" + c.height + "|" + c.name;
    return "NONE|Open or select a composition first.";
};

SZ.ae.folder = function sz_ae_folder(name) {
    if (!name) return null;
    for (var i = 1; i <= app.project.numItems; i++) {
        var it = app.project.item(i);
        if (it instanceof FolderItem && it.name === name) return it;
    }
    return app.project.items.addFolder(name);
};

SZ.ae.create = function sz_ae_create(job) {
    var o = job.opts, last = null, notes = [];
    app.beginUndoGroup("Feedproof: create comps");
    try {
        var folder = SZ.ae.folder(o.folder);
        for (var i = 0; i < job.items.length; i++) {
            var it = job.items[i];
            var comp = app.project.items.addComp(it.name, it.w, it.h, 1, o.duration, o.fps);
            if (folder) comp.parentFolder = folder;
            var n = SZ.ae.overlay(comp, it, o);
            if (n) notes.push(n);
            last = comp;
        }
    } finally {
        app.endUndoGroup();
    }
    if (last) last.openInViewer();
    return SZ.ok("Created " + job.items.length + " comp" + (job.items.length > 1 ? "s" : "") + (notes.length ? ". " + notes[0] : ""));
};

SZ.ae.apply = function sz_ae_apply(job) {
    var comp = app.project.activeItem;
    if (!(comp && comp instanceof CompItem)) return SZ.err("Open or select a composition first.");
    app.beginUndoGroup("Feedproof: add overlay");
    var n;
    try { n = SZ.ae.overlay(comp, job.items[0], job.opts); } finally { app.endUndoGroup(); }
    return SZ.ok("Added " + job.items[0].title + " to \"" + comp.name + "\"" + (n ? ". " + n : ""));
};

SZ.ae.toggle = function sz_ae_toggle() {
    var comp = app.project.activeItem;
    if (!(comp && comp instanceof CompItem)) return SZ.err("Open a composition first.");
    var count = 0, state = null;
    for (var i = 1; i <= comp.numLayers; i++) {
        var L = comp.layer(i);
        if (L.name.indexOf(SZ.OVERLAY_TAG) === 0 || L.comment === SZ.OVERLAY_TAG) {
            if (state === null) state = !L.enabled;
            var wasLocked = L.locked;
            L.locked = false;
            L.enabled = state;
            L.locked = wasLocked;
            count++;
        }
    }
    if (!count) return SZ.err("No Safe Zones overlay in this comp.");
    return SZ.ok((state ? "Showing " : "Hiding ") + count + " overlay layer" + (count > 1 ? "s" : ""));
};

SZ.ae.rect = function sz_ae_rect(layer, name, r, fill, stroke) {
    var contents = layer.property("ADBE Root Vectors Group");
    var grp = contents.addProperty("ADBE Vector Group");
    grp.name = name;
    var idx = grp.propertyIndex;
    var vecs = function sz_inner_164() { return contents.property(idx).property("ADBE Vectors Group"); };

    var shape = vecs().addProperty("ADBE Vector Shape - Rect");
    shape.property("ADBE Vector Rect Size").setValue([r.w, r.h]);
    shape.property("ADBE Vector Rect Position").setValue([r.x + r.w / 2, r.y + r.h / 2]);

    if (fill) {
        var f = vecs().addProperty("ADBE Vector Graphic - Fill");
        f.property("ADBE Vector Fill Color").setValue(fill.color);
        f.property("ADBE Vector Fill Opacity").setValue(fill.opacity);
    }
    if (stroke) {
        var s = vecs().addProperty("ADBE Vector Graphic - Stroke");
        s.property("ADBE Vector Stroke Color").setValue(stroke.color);
        s.property("ADBE Vector Stroke Width").setValue(stroke.width);
        if (stroke.dash) {
            try {
                var d = s.property("ADBE Vector Stroke Dashes");
                d.addProperty("ADBE Vector Stroke Dash 1").setValue(stroke.dash[0]);
                s = vecs().property(vecs().numProperties); // re-acquire after add
                s.property("ADBE Vector Stroke Dashes").addProperty("ADBE Vector Stroke Gap 1").setValue(stroke.dash[1]);
            } catch (e) { /* dashes are cosmetic */ }
        }
    }
};

SZ.ae.overlay = function sz_ae_overlay(comp, it, o) {
    var g = it.geo, note = "";
    var i;

    // Ruler guides (AE 16.1+)
    if (o.mode !== "mask") {
        try {
            for (i = 0; i < g.guidesX.length; i++) comp.addGuide(1, g.guidesX[i]);
            for (i = 0; i < g.guidesY.length; i++) comp.addGuide(0, g.guidesY[i]);
        } catch (e) {
            note = "Ruler guides need After Effects 2020 (16.1) or later";
        }
    }

    var needShape = (o.mode !== "guides") || o.outline || (g.crops && g.crops.length);
    var shapeLayer = null;
    if (needShape) {
        shapeLayer = comp.layers.addShape();
        shapeLayer.name = SZ.OVERLAY_TAG + " - " + it.title;
        shapeLayer.comment = SZ.OVERLAY_TAG;
        var tr = shapeLayer.property("ADBE Transform Group");
        tr.property("ADBE Anchor Point").setValue([0, 0]);
        tr.property("ADBE Position").setValue([0, 0]);

        if (o.mode !== "guides") {
            for (i = 0; i < g.zones.length; i++) {
                var z = g.zones[i];
                SZ.ae.rect(shapeLayer, z.label || z.id, z, {
                    color: SZ.zoneColor(o, z.kind),
                    opacity: (z.kind === "comfort") ? Math.round(o.opacity * 0.7) : o.opacity
                }, null);
            }
        }
        if (o.outline) {
            var w = Math.max(2, Math.round(Math.min(it.w, it.h) / 360));
            SZ.ae.rect(shapeLayer, "Safe area", {
                x: g.safe.x + w / 2, y: g.safe.y + w / 2, w: g.safe.w - w, h: g.safe.h - w
            }, null, { color: o.colors.safe, width: w });
        }
        for (i = 0; i < g.crops.length; i++) {
            var c = g.crops[i];
            SZ.ae.rect(shapeLayer, c.label, { x: c.x + 1, y: c.y + 1, w: c.w - 2, h: c.h - 2 }, null,
                { color: c.color || o.colors.crop, width: 2, dash: [24, 14] });
        }
        shapeLayer.guideLayer = true;   // visible while working, never renders
        shapeLayer.label = 1;           // red label colour
    }

    // Text labels (also guide layers, parented to the overlay)
    if (o.labels && o.mode !== "guides") {
        var fs = SZ.fontSize(it);
        for (i = 0; i < g.zones.length; i++) {
            var zz = g.zones[i];
            if (!zz.label || zz.h < fs * 1.6 || zz.w < fs * 8) continue;
            var t = comp.layers.addText(zz.label);
            var tp = t.property("ADBE Text Properties").property("ADBE Text Document");
            var doc = tp.value;
            doc.fontSize = fs;
            doc.applyFill = true;
            doc.fillColor = [1, 1, 1];
            doc.applyStroke = false;
            doc.justification = ParagraphJustification.LEFT_JUSTIFY;
            tp.setValue(doc);
            t.property("ADBE Transform Group").property("ADBE Position").setValue([zz.x + fs * 0.6, zz.y + fs * 1.5]);
            t.name = SZ.OVERLAY_TAG + " label - " + zz.label;
            t.comment = SZ.OVERLAY_TAG;
            t.guideLayer = true;
            t.label = 1;
            if (shapeLayer) t.parent = shapeLayer;
            t.locked = true;
        }
    }
    if (shapeLayer) {
        shapeLayer.moveToBeginning();
        shapeLayer.locked = true;
    }
    return note;
};

/* =====================================================================
 *  PHOTOSHOP
 * ===================================================================== */
SZ.ps = {};

SZ.ps.withPixels = function sz_ps_withPixels(fn) {
    var ru = app.preferences.rulerUnits, tu = app.preferences.typeUnits;
    app.preferences.rulerUnits = Units.PIXELS;
    app.preferences.typeUnits = TypeUnits.PIXELS;
    try { return fn(); }
    finally {
        app.preferences.rulerUnits = ru;
        app.preferences.typeUnits = tu;
    }
};

SZ.ps.color = function sz_ps_color(c) {
    var s = new SolidColor();
    s.rgb.red = Math.round(c[0] * 255);
    s.rgb.green = Math.round(c[1] * 255);
    s.rgb.blue = Math.round(c[2] * 255);
    return s;
};

SZ.ps.pts = function sz_ps_pts(r) {
    return [[r.x, r.y], [r.x + r.w, r.y], [r.x + r.w, r.y + r.h], [r.x, r.y + r.h]];
};

SZ.ps.size = function sz_ps_size() {
    if (!app.documents.length) return "NONE|Open a document first.";
    return SZ.ps.withPixels(function sz_inner_299() {
        var d = app.activeDocument;
        return "OK|" + Math.round(d.width.as("px")) + "|" + Math.round(d.height.as("px")) + "|" + d.name;
    });
};

SZ.ps.create = function sz_ps_create(job) {
    return SZ.ps.withPixels(function sz_inner_306() {
        for (var i = 0; i < job.items.length; i++) {
            var it = job.items[i];
            var doc = app.documents.add(it.w, it.h, 72, it.name, NewDocumentMode.RGB, DocumentFill.WHITE);
            SZ.ps.overlay(doc, it, job.opts, true);
        }
        return SZ.ok("Created " + job.items.length + " document" + (job.items.length > 1 ? "s" : ""));
    });
};

SZ.ps.apply = function sz_ps_apply(job) {
    if (!app.documents.length) return SZ.err("Open a document first.");
    return SZ.ps.withPixels(function sz_inner_318() {
        var doc = app.activeDocument;
        SZ.ps.overlay(doc, job.items[0], job.opts);
        return SZ.ok("Added " + job.items[0].title + " to " + doc.name);
    });
};

SZ.ps.toggle = function sz_ps_toggle() {
    if (!app.documents.length) return SZ.err("Open a document first.");
    var doc = app.activeDocument, count = 0, state = null;
    for (var i = 0; i < doc.layerSets.length; i++) {
        var s = doc.layerSets[i];
        if (s.name.indexOf(SZ.OVERLAY_TAG) === 0) {
            if (state === null) state = !s.visible;
            s.visible = state;
            count++;
        }
    }
    if (!count) return SZ.err("No Safe Zones group in this document.");
    return SZ.ok((state ? "Showing" : "Hiding") + " overlay");
};

SZ.ps.overlay = function sz_ps_overlay(doc, it, o, isNew) {
    var g = it.geo, i;
    app.activeDocument = doc;

    if (o.mode !== "mask") {
        try {
            for (i = 0; i < g.guidesX.length; i++) doc.guides.add(Direction.VERTICAL, UnitValue(g.guidesX[i], "px"));
            for (i = 0; i < g.guidesY.length; i++) doc.guides.add(Direction.HORIZONTAL, UnitValue(g.guidesY[i], "px"));
        } catch (e) { /* guides API needs PS CC 2014+ */ }
    }

    var needGroup = (o.mode !== "guides") || o.outline || g.crops.length;
    if (!needGroup) return;

    var set = doc.layerSets.add();
    set.name = SZ.OVERLAY_TAG + " - " + it.title + " (hide before export)";

    if (o.mode !== "guides" && g.zones.length) {
        var kind = g.zones[0].kind;
        var L = set.artLayers.add();
        L.name = "Unsafe areas";
        doc.activeLayer = L;
        doc.selection.deselect();
        for (i = 0; i < g.zones.length; i++) doc.selection.select(SZ.ps.pts(g.zones[i]), SelectionType.EXTEND);
        doc.selection.fill(SZ.ps.color(SZ.zoneColor(o, kind)));
        doc.selection.deselect();
        L.opacity = (kind === "comfort") ? Math.round(o.opacity * 0.7) : o.opacity;
    }

    if (o.outline) {
        var S = set.artLayers.add();
        S.name = "Safe area";
        doc.activeLayer = S;
        doc.selection.select(SZ.ps.pts(g.safe));
        doc.selection.stroke(SZ.ps.color(o.colors.safe), Math.max(2, Math.round(Math.min(it.w, it.h) / 360)), StrokeLocation.INSIDE);
        doc.selection.deselect();
    }

    for (i = 0; i < g.crops.length; i++) {
        var C = set.artLayers.add();
        C.name = g.crops[i].label;
        doc.activeLayer = C;
        doc.selection.select(SZ.ps.pts(g.crops[i]));
        doc.selection.stroke(SZ.ps.color(g.crops[i].color || o.colors.crop), 2, StrokeLocation.INSIDE);
        doc.selection.deselect();
    }

    if (o.labels && o.mode !== "guides") {
        var fs = SZ.fontSize(it);
        for (i = 0; i < g.zones.length; i++) {
            var z = g.zones[i];
            if (!z.label || z.h < fs * 1.6 || z.w < fs * 8) continue;
            var T = set.artLayers.add();
            T.kind = LayerKind.TEXT;
            T.name = z.label;
            var ti = T.textItem;
            ti.contents = z.label;
            ti.size = fs;
            var white = new SolidColor();
            white.rgb.red = white.rgb.green = white.rgb.blue = 255;
            ti.color = white;
            ti.position = [z.x + fs * 0.6, z.y + fs * 1.5];
        }
    }

    try {
        if (doc.layers[0] !== set) set.move(doc.layers[0], ElementPlacement.PLACEBEFORE);
    } catch (e2) {}
    set.allLocked = true;

    // New docs: leave the user on a clean working layer under the overlay
    if (!isNew) return;
    try {
        var work = doc.artLayers.add();
        work.name = "Layer 1";
        work.move(set, ElementPlacement.PLACEAFTER);
        doc.activeLayer = work;
    } catch (e3) {}
};

/* =====================================================================
 *  ILLUSTRATOR
 * ===================================================================== */
SZ.ai = {};

SZ.ai.rgb = function sz_ai_rgb(c) {
    var r = new RGBColor();
    r.red = Math.round(c[0] * 255);
    r.green = Math.round(c[1] * 255);
    r.blue = Math.round(c[2] * 255);
    return r;
};

SZ.ai.size = function sz_ai_size() {
    if (!app.documents.length) return "NONE|Open a document first.";
    var doc = app.activeDocument;
    var ab = doc.artboards[doc.artboards.getActiveArtboardIndex()];
    var r = ab.artboardRect;
    return "OK|" + Math.round(Math.abs(r[2] - r[0])) + "|" + Math.round(Math.abs(r[1] - r[3])) + "|" + ab.name;
};

SZ.ai.layer = function sz_ai_layer(doc, name) {
    for (var i = 0; i < doc.layers.length; i++) if (doc.layers[i].name === name) return doc.layers[i];
    var L = doc.layers.add();
    L.name = name;
    return L;
};

SZ.ai.create = function sz_ai_create(job) {
    var o = job.opts, prevCS = app.coordinateSystem;
    try {
        if (o.aiOneDoc && job.items.length > 1) {
            var first = job.items[0];
            var doc = app.documents.add(DocumentColorSpace.RGB, first.w, first.h);
            doc.artboards[0].name = first.name;
            app.coordinateSystem = CoordinateSystem.DOCUMENTCOORDINATESYSTEM;
            var base = doc.artboards[0].artboardRect;
            var yDown = base[3] < base[1];
            var gap = 120, right = base[2];
            for (var i = 1; i < job.items.length; i++) {
                var it = job.items[i];
                var L = right + gap, T = base[1];
                var B = yDown ? T - it.h : T + it.h;
                var ab = doc.artboards.add([L, T, L + it.w, B]);
                ab.name = it.name;
                right = L + it.w;
            }
            for (var k = 0; k < job.items.length; k++) SZ.ai.overlay(doc, k, job.items[k], o);
            SZ.ai.finish(doc);
            return SZ.ok("Created 1 document with " + job.items.length + " artboards");
        }
        for (var j = 0; j < job.items.length; j++) {
            var it2 = job.items[j];
            var d = app.documents.add(DocumentColorSpace.RGB, it2.w, it2.h);
            d.artboards[0].name = it2.name;
            SZ.ai.overlay(d, 0, it2, o);
            SZ.ai.finish(d);
        }
        return SZ.ok("Created " + job.items.length + " document" + (job.items.length > 1 ? "s" : ""));
    } finally {
        app.coordinateSystem = prevCS;
    }
};

SZ.ai.apply = function sz_ai_apply(job) {
    if (!app.documents.length) return SZ.err("Open a document first.");
    var prevCS = app.coordinateSystem;
    try {
        var doc = app.activeDocument;
        var idx = doc.artboards.getActiveArtboardIndex();
        SZ.ai.overlay(doc, idx, job.items[0], job.opts);
        SZ.ai.finish(doc);
        return SZ.ok("Added " + job.items[0].title + " to artboard \"" + doc.artboards[idx].name + "\"");
    } finally {
        app.coordinateSystem = prevCS;
    }
};

SZ.ai.toggle = function sz_ai_toggle() {
    if (!app.documents.length) return SZ.err("Open a document first.");
    var doc = app.activeDocument;
    for (var i = 0; i < doc.layers.length; i++) {
        if (doc.layers[i].name.indexOf(SZ.OVERLAY_TAG) === 0) {
            doc.layers[i].visible = !doc.layers[i].visible;
            return SZ.ok((doc.layers[i].visible ? "Showing" : "Hiding") + " overlay");
        }
    }
    return SZ.err("No Safe Zones layer in this document.");
};

SZ.ai.finish = function sz_ai_finish(doc) {
    // Keep an "Artwork" layer active under the locked, non-printing overlay
    var art = null;
    for (var i = 0; i < doc.layers.length; i++) {
        if (doc.layers[i].name.indexOf(SZ.OVERLAY_TAG) !== 0) { art = doc.layers[i]; break; }
    }
    if (!art) { art = doc.layers.add(); }
    if (art.name === "Layer 1") art.name = "Artwork";
    var ov = SZ.ai.layer(doc, SZ.OVERLAY_TAG + " (non-printing)");
    ov.zOrder(ZOrderMethod.BRINGTOFRONT);
    ov.printable = false;
    ov.locked = true;
    doc.activeLayer = art;
};

SZ.ai.overlay = function sz_ai_overlay(doc, abIndex, it, o) {
    var g = it.geo, i;
    doc.artboards.setActiveArtboardIndex(abIndex);
    app.coordinateSystem = CoordinateSystem.ARTBOARDCOORDINATESYSTEM;

    var layer = SZ.ai.layer(doc, SZ.OVERLAY_TAG + " (non-printing)");
    layer.locked = false;
    layer.visible = true;
    var grp = layer.groupItems.add();
    grp.name = it.title + "  " + it.w + "x" + it.h;

    var noColor = new NoColor();

    if (o.mode !== "guides") {
        for (i = 0; i < g.zones.length; i++) {
            var z = g.zones[i];
            var r = grp.pathItems.rectangle(-z.y, z.x, z.w, z.h);
            r.name = z.label || z.id;
            r.filled = true;
            r.fillColor = SZ.ai.rgb(SZ.zoneColor(o, z.kind));
            r.stroked = false;
            r.opacity = (z.kind === "comfort") ? Math.round(o.opacity * 0.7) : o.opacity;
        }
    }

    if (o.outline) {
        var sw = Math.max(2, Math.round(Math.min(it.w, it.h) / 360));
        var s = grp.pathItems.rectangle(-(g.safe.y + sw / 2), g.safe.x + sw / 2, g.safe.w - sw, g.safe.h - sw);
        s.name = "Safe area";
        s.filled = false;
        s.fillColor = noColor;
        s.stroked = true;
        s.strokeColor = SZ.ai.rgb(o.colors.safe);
        s.strokeWidth = sw;
    }

    for (i = 0; i < g.crops.length; i++) {
        var c = g.crops[i];
        var cr = grp.pathItems.rectangle(-(c.y + 1), c.x + 1, c.w - 2, c.h - 2);
        cr.name = c.label;
        cr.filled = false;
        cr.stroked = true;
        cr.strokeColor = SZ.ai.rgb(c.color || o.colors.crop);
        cr.strokeWidth = 2;
        cr.strokeDashes = [24, 14];
    }

    if (o.labels && o.mode !== "guides") {
        var fs = SZ.fontSize(it);
        for (i = 0; i < g.zones.length; i++) {
            var zz = g.zones[i];
            if (!zz.label || zz.h < fs * 1.6 || zz.w < fs * 8) continue;
            var tf = grp.textFrames.add();
            tf.contents = zz.label;
            tf.textRange.characterAttributes.size = fs;
            tf.textRange.characterAttributes.fillColor = SZ.ai.rgb([1, 1, 1]);
            tf.position = [zz.x + fs * 0.6, -(zz.y + fs * 0.5)];
            tf.name = "label - " + zz.label;
        }
    }

    // Guides: paths converted to guides, on the overlay layer.
    // Anchor coordinates can differ from the artboard system, so measure
    // where the artboard's top-left lands with a temporary rectangle.
    if (o.mode !== "mask") {
        var probe = layer.pathItems.rectangle(0, 0, 10, 10);
        var ox = 1e9, oy = -1e9, pp = probe.pathPoints;
        for (i = 0; i < pp.length; i++) {
            if (pp[i].anchor[0] < ox) ox = pp[i].anchor[0];
            if (pp[i].anchor[1] > oy) oy = pp[i].anchor[1];
        }
        probe.remove();
        var ext = 40;
        for (i = 0; i < g.guidesX.length; i++) {
            var vx = layer.pathItems.add();
            vx.setEntirePath([[ox + g.guidesX[i], oy + ext], [ox + g.guidesX[i], oy - (it.h + ext)]]);
            vx.guides = true;
        }
        for (i = 0; i < g.guidesY.length; i++) {
            var hy = layer.pathItems.add();
            hy.setEntirePath([[ox - ext, oy - g.guidesY[i]], [ox + it.w + ext, oy - g.guidesY[i]]]);
            hy.guides = true;
        }
    }
};

/* =====================================================================
 *  PREMIERE PRO
 *  No guide-layer concept in Premiere scripting, so the overlay is a
 *  transparent PNG (rendered by the panel) placed on the top video track.
 * ===================================================================== */
SZ.pr = {};
SZ.pr.TICKS = 254016000000;

SZ.pr.size = function sz_pr_size() {
    var seq = app.project.activeSequence;
    if (!seq) return "NONE|Open a sequence first.";
    return "OK|" + seq.frameSizeHorizontal + "|" + seq.frameSizeVertical + "|" + seq.name;
};

SZ.pr.bin = function sz_pr_bin(name) {
    var root = app.project.rootItem;
    for (var i = 0; i < root.children.numItems; i++) {
        var c = root.children[i];
        if (c.type === ProjectItemType.BIN && c.name === name) return c;
    }
    return root.createBin(name);
};

SZ.pr.norm = function sz_pr_norm(p) { return String(p).replace(/\\/g, "/").toLowerCase(); };

SZ.pr.importPng = function sz_pr_importPng(path, bin) {
    var want = SZ.pr.norm(path);
    var find = function sz_inner_638() {
        for (var i = 0; i < bin.children.numItems; i++) {
            var c = bin.children[i];
            try { if (SZ.pr.norm(c.getMediaPath()) === want) return c; } catch (e) {}
        }
        return null;
    };
    var existing = find();
    if (existing) return existing;
    app.project.importFiles([path], true, bin, false);
    return find();
};

SZ.pr.time = function sz_pr_time(seconds) {
    var t = new Time();
    t.seconds = seconds;
    return t;
};

SZ.pr.frameTime = function sz_pr_frameTime(fps) {
    var t = new Time();
    t.ticks = String(Math.round(SZ.pr.TICKS / fps));
    return t;
};

SZ.pr.placeOnTop = function sz_pr_placeOnTop(seq, pi, durSeconds) {
    var vt = seq.videoTracks, idx = -1, i;
    for (i = vt.numTracks - 1; i >= 0; i--) {
        if (vt[i].clips.numItems === 0) { idx = i; break; }
    }
    if (idx < 0 || idx < vt.numTracks - 1) {
        // need an empty track at the very top — add one through QE
        try {
            app.enableQE();
            qe.project.getActiveSequence().addTracks(1, vt.numTracks, 0);
            vt = seq.videoTracks;
            idx = vt.numTracks - 1;
        } catch (e) {
            if (idx < 0) return "No empty video track. Add a track at the top and try again.";
        }
    }
    var track = vt[idx];
    track.overwriteClip(pi, 0);
    var clip = track.clips[track.clips.numItems - 1];
    try { clip.name = SZ.PR_CLIP_NAME; } catch (e1) {}
    try { clip.end = SZ.pr.time(durSeconds); } catch (e2) {}
    try { track.setLocked(1); } catch (e3) {}
    return "";
};

SZ.pr.create = function sz_pr_create(job) {
    var o = job.opts, bin = SZ.pr.bin(o.folder || "Safe Zones"), warn = "";
    for (var i = 0; i < job.items.length; i++) {
        var it = job.items[i];
        var pi = SZ.pr.importPng(it.png, bin);
        if (!pi) return SZ.err("Could not import overlay: " + it.png);
        try { pi.setOutPoint(o.duration, 4); } catch (e0) {}

        var seq = app.project.createNewSequenceFromClips(it.name, [pi], bin);
        if (!seq) return SZ.err("Premiere could not create the sequence.");
        app.project.openSequence(seq.sequenceID);

        var st = seq.getSettings();
        st.videoFrameWidth = it.w;
        st.videoFrameHeight = it.h;
        try { st.videoFrameRate = SZ.pr.frameTime(o.fps); } catch (e1) { warn = "Set the frame rate in Sequence Settings."; }
        seq.setSettings(st);

        // createNewSequenceFromClips drops the PNG on V1 — move it to the top track
        try {
            var first = seq.videoTracks[0].clips[0];
            if (first) first.remove(false, false);
        } catch (e2) {}
        // give the editor working tracks under the overlay
        try {
            var n = seq.videoTracks.numTracks;
            if (n < 3) {
                app.enableQE();
                qe.project.getActiveSequence().addTracks(3 - n, n, 0);
            }
        } catch (e3) {}
        var msg = SZ.pr.placeOnTop(seq, pi, o.duration);
        if (msg) warn = msg;
    }
    return SZ.ok("Created " + job.items.length + " sequence" + (job.items.length > 1 ? "s" : "") + (warn ? ". " + warn : ""));
};

SZ.pr.apply = function sz_pr_apply(job) {
    var seq = app.project.activeSequence;
    if (!seq) return SZ.err("Open a sequence first.");
    var it = job.items[0];
    var bin = SZ.pr.bin(job.opts.folder || "Safe Zones");
    var pi = SZ.pr.importPng(it.png, bin);
    if (!pi) return SZ.err("Could not import overlay: " + it.png);
    var dur = Math.max(1, parseFloat(seq.end) / SZ.pr.TICKS);
    var msg = SZ.pr.placeOnTop(seq, pi, dur);
    return msg ? SZ.err(msg) : SZ.ok("Added " + it.title + " overlay to \"" + seq.name + "\"");
};

SZ.pr.toggle = function sz_pr_toggle() {
    var seq = app.project.activeSequence;
    if (!seq) return SZ.err("Open a sequence first.");
    var count = 0, state = null;
    for (var t = 0; t < seq.videoTracks.numTracks; t++) {
        var tr = seq.videoTracks[t];
        for (var c = 0; c < tr.clips.numItems; c++) {
            var clip = tr.clips[c];
            if (clip.name === SZ.PR_CLIP_NAME) {
                if (state === null) state = !clip.disabled;
                clip.disabled = state;
                count++;
            }
        }
    }
    if (!count) return SZ.err("No Safe Zones overlay in this sequence.");
    return SZ.ok((state ? "Disabled " : "Enabled ") + count + " overlay clip" + (count > 1 ? "s" : "") + (state ? " — ready to export" : ""));
};

// Record every module call in SZ.trail (diagnostics).
(function sz_instrument() {
    var names = ["ae", "ps", "ai", "pr"];
    var wrap = function sz_wrap(fn, label) {
        return function sz_traced() { SZ.mark(label); return fn.apply(this, arguments); };
    };
    for (var m = 0; m < names.length; m++) {
        var mod = SZ[names[m]];
        for (var k in mod) {
            if (mod.hasOwnProperty(k) && typeof mod[k] === "function") mod[k] = wrap(mod[k], names[m] + "." + k);
        }
    }
})();

// Publish under a name no other extension uses. Everything above is
// sealed in this closure, so another script redefining "SZ" cannot break it.
$.global.FeedproofFX = SZ;

})();
