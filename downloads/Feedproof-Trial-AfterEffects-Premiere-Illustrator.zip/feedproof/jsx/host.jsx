/*
 * Feedproof — Meta, TikTok, YouTube & LinkedIn safe zones
 * © 2026 Edgar Febus. All rights reserved.
 * https://edgarfebus.com
 */
/*
 * Feedproof — ExtendScript host layer
 * One file, four hosts. The panel computes all geometry in pixels and
 * sends a job object; this file only builds things in the host app.
 *
 *   job = {
 *     action: "create" | "apply" | "size" | "toggle" | "layers" | "fixlayout",
 *     items:  [{ name, title, w, h, png, geo: { zones, guidesX, guidesY, safe, crops } }],
 *     opts:   { mode, outline, labels, opacity, fps, duration, aiOneDoc, colors, folder }
 *   }
 *
 * Returns "OK|message" or "ERR|message" (or "NONE|reason" for size).
 * ES3 only — no JSON, no Array.forEach, no indexOf.
 */

(function () {

var SZ = {};

SZ.OVERLAY_TAG = "SAFE ZONES";
SZ.PR_CLIP_NAME = "SAFE ZONE OVERLAY - disable before export";
SZ.PR_UI_CLIP_NAME = "SAFE ZONE UI PREVIEW - disable before export";

SZ.ok = function sz_ok(m) { return "OK|" + m; };
SZ.err = function sz_err(m) { return "ERR|" + m; };

SZ.host = function sz_host() {
    try { return BridgeTalk.appName; } catch (e) { return "unknown"; }
};

SZ.VERSION = "2.1.0";

// Which app are we in? Decided by objects that exist in only one host's
// scripting model — this cannot be fooled by names or other extensions.
//   CompItem            → After Effects only
//   ProjectItemType     → Premiere Pro only
//   LayerKind           → Photoshop only
//   DocumentColorSpace  → Illustrator only (Photoshop has no such enum)
SZ.HOST_IDS = { AEFT: "aftereffects", PPRO: "premierepro", PHXS: "photoshop", PHSP: "photoshop", ILST: "illustrator" };

SZ.detect = function sz_detect(job) {
    if (typeof CompItem !== "undefined") return "aftereffects";
    if (typeof ProjectItemType !== "undefined") return "premierepro";
    if (typeof LayerKind !== "undefined" && typeof NewDocumentMode !== "undefined") return "photoshop";
    if (typeof DocumentColorSpace !== "undefined" && typeof PathItem !== "undefined") return "illustrator";
    if (job && job.host && SZ.HOST_IDS[job.host]) return SZ.HOST_IDS[job.host];
    return SZ.host();
};

SZ.pick = function sz_pick(h) {
    var table = { aftereffects: SZ.ae, photoshop: SZ.ps, illustrator: SZ.ai, premierepro: SZ.pr };
    if (table.hasOwnProperty(h)) return table[h];
    return null;
};

SZ.diag = function sz_diag(job, h) {
    return " [script v" + SZ.VERSION + ", detected " + h + ", panel " + (job && job.host) + "]";
};

SZ.trail = [];
SZ.mark = function sz_mark(name) {
    SZ.trail.push(name);
    if (SZ.trail.length > 14) SZ.trail.shift();
};

SZ.run = function sz_run(job) {
    var h = "?";
    SZ.trail = [];
    try {
        h = SZ.detect(job);
        if (job.action === "ping") {
            var mods = [SZ.ae, SZ.ps, SZ.ai, SZ.pr], acts = ["create", "apply", "size", "toggle"], a, x, y;
            for (a = 0; a < acts.length; a++)
                for (x = 0; x < mods.length; x++)
                    for (y = x + 1; y < mods.length; y++)
                        if (mods[x][acts[a]] === mods[y][acts[a]]) return "ERR|collision|" + acts[a];
            var picked = SZ.pick(h);
            var pickedName = picked === SZ.ae ? "aftereffects" : "";
            if (picked === SZ.ps) pickedName = "photoshop";
            if (picked === SZ.ai) pickedName = "illustrator";
            if (picked === SZ.pr) pickedName = "premierepro";
            if (pickedName !== h) return "ERR|dispatch|" + h + " -> " + pickedName;
            return "OK|" + SZ.VERSION + "|" + h;
        }
        var mod = SZ.pick(h);
        if (!mod) return SZ.err("Unsupported host: " + h + SZ.diag(job, h));
        if (!mod[job.action]) return SZ.err("Action not available in this app: " + job.action + SZ.diag(job, h));
        var res = mod[job.action](job);
        if (String(res).indexOf("ERR|") === 0 || String(res).indexOf("NONE|") === 0) res += SZ.diag(job, h);
        return res;
    } catch (e) {
        var src = "";
        try {
            if (e.source && e.line) src = String(e.source).split(/\r\n|\r|\n/)[e.line - 1];
            src = String(src).replace(/^\s+|\s+$/g, "").slice(0, 90);
        } catch (e2) {}
        var file = "";
        try { file = String(e.fileName || "").replace(/^.*[\/\\]/, ""); } catch (e3) {}
        return SZ.err(e.toString() + " (line " + e.line + (file ? " of " + file : "") + ")" +
            (src ? " CODE: " + src : "") +
            " TRAIL: " + SZ.trail.join(" > ") + SZ.diag(job, h));
    }
};

SZ.fontSize = function sz_fontSize(item) {
    return Math.max(14, Math.round(Math.min(item.w, item.h) * 0.026));
};

SZ.zoneColor = function sz_zoneColor(o, kind) {
    var c = o.colors[kind] || o.colors.ui;
    return [c[0], c[1], c[2]];
};

/* =====================================================================
 *  AFTER EFFECTS
 * ===================================================================== */
SZ.ae = {};

SZ.ae.size = function sz_ae_size() {
    var c = app.project.activeItem;
    if (c && c instanceof CompItem) return "OK|" + c.width + "|" + c.height + "|" + c.name;
    return "NONE|Open or select a composition first.";
};

SZ.ae.folder = function sz_ae_folder(name) {
    if (!name) return null;
    for (var i = 1; i <= app.project.numItems; i++) {
        var it = app.project.item(i);
        if (it instanceof FolderItem && it.name === name) return it;
    }
    return app.project.items.addFolder(name);
};

SZ.ae.create = function sz_ae_create(job) {
    var o = job.opts, last = null, notes = [];
    app.beginUndoGroup("Feedproof: create comps");
    try {
        var folder = SZ.ae.folder(o.folder);
        for (var i = 0; i < job.items.length; i++) {
            var it = job.items[i];
            var comp = app.project.items.addComp(it.name, it.w, it.h, 1, o.duration, o.fps);
            if (folder) comp.parentFolder = folder;
            var n = SZ.ae.overlay(comp, it, o);
            if (n) notes.push(n);
            if (it.uiPng) { n = SZ.ae.uiLayer(comp, it, folder); if (n) notes.push(n); }
            last = comp;
        }
    } finally {
        app.endUndoGroup();
    }
    if (last) last.openInViewer();
    return SZ.ok("Created " + job.items.length + " comp" + (job.items.length > 1 ? "s" : "") + (notes.length ? ". " + notes[0] : ""));
};

SZ.ae.apply = function sz_ae_apply(job) {
    var comp = app.project.activeItem;
    if (!(comp && comp instanceof CompItem)) return SZ.err("Open or select a composition first.");
    app.beginUndoGroup("Feedproof: add overlay");
    var n;
    try {
        n = SZ.ae.overlay(comp, job.items[0], job.opts);
        if (job.items[0].uiPng) n = SZ.ae.uiLayer(comp, job.items[0], SZ.ae.folder(job.opts.folder)) || n;
    } finally { app.endUndoGroup(); }
    return SZ.ok("Added " + job.items[0].title + " to \"" + comp.name + "\"" + (n ? ". " + n : ""));
};

SZ.ae.toggle = function sz_ae_toggle() {
    var comp = app.project.activeItem;
    if (!(comp && comp instanceof CompItem)) return SZ.err("Open a composition first.");
    var count = 0, state = null;
    for (var i = 1; i <= comp.numLayers; i++) {
        var L = comp.layer(i);
        if (L.name.indexOf(SZ.OVERLAY_TAG) === 0 || L.comment === SZ.OVERLAY_TAG) {
            if (state === null) state = !L.enabled;
            var wasLocked = L.locked;
            L.locked = false;
            L.enabled = state;
            L.locked = wasLocked;
            count++;
        }
    }
    if (!count) return SZ.err("No Safe Zones overlay in this comp.");
    return SZ.ok((state ? "Showing " : "Hiding ") + count + " overlay layer" + (count > 1 ? "s" : ""));
};

SZ.ae.rect = function sz_ae_rect(layer, name, r, fill, stroke) {
    var contents = layer.property("ADBE Root Vectors Group");
    var grp = contents.addProperty("ADBE Vector Group");
    grp.name = name;
    var idx = grp.propertyIndex;
    var vecs = function sz_inner_164() { return contents.property(idx).property("ADBE Vectors Group"); };

    var shape = vecs().addProperty("ADBE Vector Shape - Rect");
    shape.property("ADBE Vector Rect Size").setValue([r.w, r.h]);
    shape.property("ADBE Vector Rect Position").setValue([r.x + r.w / 2, r.y + r.h / 2]);

    if (fill) {
        var f = vecs().addProperty("ADBE Vector Graphic - Fill");
        f.property("ADBE Vector Fill Color").setValue(fill.color);
        f.property("ADBE Vector Fill Opacity").setValue(fill.opacity);
    }
    if (stroke) {
        var s = vecs().addProperty("ADBE Vector Graphic - Stroke");
        s.property("ADBE Vector Stroke Color").setValue(stroke.color);
        s.property("ADBE Vector Stroke Width").setValue(stroke.width);
        if (stroke.dash) {
            try {
                var d = s.property("ADBE Vector Stroke Dashes");
                d.addProperty("ADBE Vector Stroke Dash 1").setValue(stroke.dash[0]);
                s = vecs().property(vecs().numProperties); // re-acquire after add
                s.property("ADBE Vector Stroke Dashes").addProperty("ADBE Vector Stroke Gap 1").setValue(stroke.dash[1]);
            } catch (e) { /* dashes are cosmetic */ }
        }
    }
};

SZ.ae.overlay = function sz_ae_overlay(comp, it, o) {
    var g = it.geo, note = "";
    var i;

    // Ruler guides (AE 16.1+)
    if (o.mode !== "mask") {
        try {
            for (i = 0; i < g.guidesX.length; i++) comp.addGuide(1, g.guidesX[i]);
            for (i = 0; i < g.guidesY.length; i++) comp.addGuide(0, g.guidesY[i]);
        } catch (e) {
            note = "Ruler guides need After Effects 2020 (16.1) or later";
        }
    }

    var needShape = (o.mode !== "guides") || o.outline || (g.crops && g.crops.length);
    var shapeLayer = null;
    if (needShape) {
        shapeLayer = comp.layers.addShape();
        shapeLayer.name = SZ.OVERLAY_TAG + " - " + it.title;
        shapeLayer.comment = SZ.OVERLAY_TAG;
        var tr = shapeLayer.property("ADBE Transform Group");
        tr.property("ADBE Anchor Point").setValue([0, 0]);
        tr.property("ADBE Position").setValue([0, 0]);

        if (o.mode !== "guides") {
            for (i = 0; i < g.zones.length; i++) {
                var z = g.zones[i];
                SZ.ae.rect(shapeLayer, z.label || z.id, z, {
                    color: SZ.zoneColor(o, z.kind),
                    opacity: (z.kind === "comfort") ? Math.round(o.opacity * 0.7) : o.opacity
                }, null);
            }
        }
        if (o.outline) {
            var w = Math.max(2, Math.round(Math.min(it.w, it.h) / 360));
            SZ.ae.rect(shapeLayer, "Safe area", {
                x: g.safe.x + w / 2, y: g.safe.y + w / 2, w: g.safe.w - w, h: g.safe.h - w
            }, null, { color: o.colors.safe, width: w });
        }
        for (i = 0; i < g.crops.length; i++) {
            var c = g.crops[i];
            SZ.ae.rect(shapeLayer, c.label, { x: c.x + 1, y: c.y + 1, w: c.w - 2, h: c.h - 2 }, null,
                { color: c.color || o.colors.crop, width: 2, dash: [24, 14] });
        }
        shapeLayer.guideLayer = true;   // visible while working, never renders
        shapeLayer.label = 1;           // red label colour
    }

    // Text labels (also guide layers, parented to the overlay)
    if (o.labels && o.mode !== "guides") {
        var fs = SZ.fontSize(it);
        for (i = 0; i < g.zones.length; i++) {
            var zz = g.zones[i];
            if (!zz.label || zz.h < fs * 1.6 || zz.w < fs * 8) continue;
            var t = comp.layers.addText(zz.label);
            var tp = t.property("ADBE Text Properties").property("ADBE Text Document");
            var doc = tp.value;
            doc.fontSize = fs;
            doc.applyFill = true;
            doc.fillColor = [1, 1, 1];
            doc.applyStroke = false;
            doc.justification = ParagraphJustification.LEFT_JUSTIFY;
            tp.setValue(doc);
            t.property("ADBE Transform Group").property("ADBE Position").setValue([zz.x + fs * 0.6, zz.y + fs * 1.5]);
            t.name = SZ.OVERLAY_TAG + " label - " + zz.label;
            t.comment = SZ.OVERLAY_TAG;
            t.guideLayer = true;
            t.label = 1;
            if (shapeLayer) t.parent = shapeLayer;
            t.locked = true;
        }
    }
    if (shapeLayer) {
        shapeLayer.moveToBeginning();
        shapeLayer.locked = true;
    }
    return note;
};

// Platform UI preview: a transparent PNG rendered by the panel, added as a
// locked guide layer on top (visible while working, never renders).
SZ.ae.footage = function sz_ae_footage(path, folder) {
    var f = new File(path), want = f.fsName;
    for (var i = 1; i <= app.project.numItems; i++) {
        var it = app.project.item(i);
        try {
            if (it instanceof FootageItem && it.mainSource && it.mainSource.file && it.mainSource.file.fsName === want) {
                it.mainSource.reload();
                return it;
            }
        } catch (e) {}
    }
    var item = app.project.importFile(new ImportOptions(f));
    try { item.mainSource.alphaMode = AlphaMode.STRAIGHT; } catch (e1) {}
    if (folder) item.parentFolder = folder;
    return item;
};

SZ.ae.uiLayer = function sz_ae_uiLayer(comp, it, folder) {
    var item;
    try { item = SZ.ae.footage(it.uiPng, folder); } catch (e) { return "Could not import the UI preview: " + e.toString(); }
    var L = comp.layers.add(item);
    try { L.outPoint = comp.duration; } catch (e2) {}
    L.name = SZ.OVERLAY_TAG + " UI - " + (it.uiTitle || "Platform UI");
    L.comment = SZ.OVERLAY_TAG;
    L.guideLayer = true;
    L.label = 8;                 // blue label, apart from the red zone layers
    L.moveToBeginning();
    L.locked = true;
    return "";
};

/* =====================================================================
 *  PHOTOSHOP
 * ===================================================================== */
SZ.ps = {};

SZ.ps.withPixels = function sz_ps_withPixels(fn) {
    var ru = app.preferences.rulerUnits, tu = app.preferences.typeUnits;
    app.preferences.rulerUnits = Units.PIXELS;
    app.preferences.typeUnits = TypeUnits.PIXELS;
    try { return fn(); }
    finally {
        app.preferences.rulerUnits = ru;
        app.preferences.typeUnits = tu;
    }
};

SZ.ps.color = function sz_ps_color(c) {
    var s = new SolidColor();
    s.rgb.red = Math.round(c[0] * 255);
    s.rgb.green = Math.round(c[1] * 255);
    s.rgb.blue = Math.round(c[2] * 255);
    return s;
};

SZ.ps.pts = function sz_ps_pts(r) {
    return [[r.x, r.y], [r.x + r.w, r.y], [r.x + r.w, r.y + r.h], [r.x, r.y + r.h]];
};

SZ.ps.size = function sz_ps_size() {
    if (!app.documents.length) return "NONE|Open a document first.";
    return SZ.ps.withPixels(function sz_inner_299() {
        var d = app.activeDocument;
        return "OK|" + Math.round(d.width.as("px")) + "|" + Math.round(d.height.as("px")) + "|" + d.name;
    });
};

SZ.ps.create = function sz_ps_create(job) {
    return SZ.ps.withPixels(function sz_inner_306() {
        for (var i = 0; i < job.items.length; i++) {
            var it = job.items[i];
            var doc = app.documents.add(it.w, it.h, 72, it.name, NewDocumentMode.RGB, DocumentFill.WHITE);
            SZ.ps.overlay(doc, it, job.opts, true);
        }
        return SZ.ok("Created " + job.items.length + " document" + (job.items.length > 1 ? "s" : ""));
    });
};

SZ.ps.apply = function sz_ps_apply(job) {
    if (!app.documents.length) return SZ.err("Open a document first.");
    return SZ.ps.withPixels(function sz_inner_318() {
        var doc = app.activeDocument;
        SZ.ps.overlay(doc, job.items[0], job.opts);
        return SZ.ok("Added " + job.items[0].title + " to " + doc.name);
    });
};

SZ.ps.toggle = function sz_ps_toggle() {
    if (!app.documents.length) return SZ.err("Open a document first.");
    var doc = app.activeDocument, count = 0, state = null;
    for (var i = 0; i < doc.layerSets.length; i++) {
        var s = doc.layerSets[i];
        if (s.name.indexOf(SZ.OVERLAY_TAG) === 0) {
            if (state === null) state = !s.visible;
            s.visible = state;
            count++;
        }
    }
    if (!count) return SZ.err("No Safe Zones group in this document.");
    return SZ.ok((state ? "Showing" : "Hiding") + " overlay");
};

SZ.ps.overlay = function sz_ps_overlay(doc, it, o, isNew) {
    var g = it.geo, i;
    app.activeDocument = doc;

    if (o.mode !== "mask") {
        try {
            for (i = 0; i < g.guidesX.length; i++) doc.guides.add(Direction.VERTICAL, UnitValue(g.guidesX[i], "px"));
            for (i = 0; i < g.guidesY.length; i++) doc.guides.add(Direction.HORIZONTAL, UnitValue(g.guidesY[i], "px"));
        } catch (e) { /* guides API needs PS CC 2014+ */ }
    }

    var needGroup = (o.mode !== "guides") || o.outline || g.crops.length;
    if (!needGroup) return;

    var set = doc.layerSets.add();
    set.name = SZ.OVERLAY_TAG + " - " + it.title + " (hide before export)";

    if (o.mode !== "guides" && g.zones.length) {
        var kind = g.zones[0].kind;
        var L = set.artLayers.add();
        L.name = "Unsafe areas";
        doc.activeLayer = L;
        doc.selection.deselect();
        for (i = 0; i < g.zones.length; i++) doc.selection.select(SZ.ps.pts(g.zones[i]), SelectionType.EXTEND);
        doc.selection.fill(SZ.ps.color(SZ.zoneColor(o, kind)));
        doc.selection.deselect();
        L.opacity = (kind === "comfort") ? Math.round(o.opacity * 0.7) : o.opacity;
    }

    if (o.outline) {
        var S = set.artLayers.add();
        S.name = "Safe area";
        doc.activeLayer = S;
        doc.selection.select(SZ.ps.pts(g.safe));
        doc.selection.stroke(SZ.ps.color(o.colors.safe), Math.max(2, Math.round(Math.min(it.w, it.h) / 360)), StrokeLocation.INSIDE);
        doc.selection.deselect();
    }

    for (i = 0; i < g.crops.length; i++) {
        var C = set.artLayers.add();
        C.name = g.crops[i].label;
        doc.activeLayer = C;
        doc.selection.select(SZ.ps.pts(g.crops[i]));
        doc.selection.stroke(SZ.ps.color(g.crops[i].color || o.colors.crop), 2, StrokeLocation.INSIDE);
        doc.selection.deselect();
    }

    if (o.labels && o.mode !== "guides") {
        var fs = SZ.fontSize(it);
        for (i = 0; i < g.zones.length; i++) {
            var z = g.zones[i];
            if (!z.label || z.h < fs * 1.6 || z.w < fs * 8) continue;
            var T = set.artLayers.add();
            T.kind = LayerKind.TEXT;
            T.name = z.label;
            var ti = T.textItem;
            ti.contents = z.label;
            ti.size = fs;
            var white = new SolidColor();
            white.rgb.red = white.rgb.green = white.rgb.blue = 255;
            ti.color = white;
            ti.position = [z.x + fs * 0.6, z.y + fs * 1.5];
        }
    }

    try {
        if (doc.layers[0] !== set) set.move(doc.layers[0], ElementPlacement.PLACEBEFORE);
    } catch (e2) {}
    set.allLocked = true;

    // New docs: leave the user on a clean working layer under the overlay
    if (!isNew) return;
    try {
        var work = doc.artLayers.add();
        work.name = "Layer 1";
        work.move(set, ElementPlacement.PLACEAFTER);
        doc.activeLayer = work;
    } catch (e3) {}
};

/* =====================================================================
 *  ILLUSTRATOR
 * ===================================================================== */
SZ.ai = {};

SZ.ai.rgb = function sz_ai_rgb(c) {
    var r = new RGBColor();
    r.red = Math.round(c[0] * 255);
    r.green = Math.round(c[1] * 255);
    r.blue = Math.round(c[2] * 255);
    return r;
};

SZ.ai.size = function sz_ai_size() {
    if (!app.documents.length) return "NONE|Open a document first.";
    var doc = app.activeDocument;
    var ab = doc.artboards[doc.artboards.getActiveArtboardIndex()];
    var r = ab.artboardRect;
    return "OK|" + Math.round(Math.abs(r[2] - r[0])) + "|" + Math.round(Math.abs(r[1] - r[3])) + "|" + ab.name;
};

SZ.ai.layer = function sz_ai_layer(doc, name) {
    for (var i = 0; i < doc.layers.length; i++) if (doc.layers[i].name === name) return doc.layers[i];
    var L = doc.layers.add();
    L.name = name;
    return L;
};

SZ.ai.create = function sz_ai_create(job) {
    var o = job.opts, prevCS = app.coordinateSystem;
    try {
        if (o.aiOneDoc && job.items.length > 1) {
            var first = job.items[0];
            var doc = app.documents.add(DocumentColorSpace.RGB, first.w, first.h);
            doc.artboards[0].name = first.name;
            app.coordinateSystem = CoordinateSystem.DOCUMENTCOORDINATESYSTEM;
            var base = doc.artboards[0].artboardRect;
            var yDown = base[3] < base[1];
            var gap = 120, right = base[2];
            for (var i = 1; i < job.items.length; i++) {
                var it = job.items[i];
                var L = right + gap, T = base[1];
                var B = yDown ? T - it.h : T + it.h;
                var ab = doc.artboards.add([L, T, L + it.w, B]);
                ab.name = it.name;
                right = L + it.w;
            }
            for (var k = 0; k < job.items.length; k++) SZ.ai.overlay(doc, k, job.items[k], o);
            SZ.ai.finish(doc);
            return SZ.ok("Created 1 document with " + job.items.length + " artboards");
        }
        for (var j = 0; j < job.items.length; j++) {
            var it2 = job.items[j];
            var d = app.documents.add(DocumentColorSpace.RGB, it2.w, it2.h);
            d.artboards[0].name = it2.name;
            SZ.ai.overlay(d, 0, it2, o);
            SZ.ai.finish(d);
        }
        return SZ.ok("Created " + job.items.length + " document" + (job.items.length > 1 ? "s" : ""));
    } finally {
        app.coordinateSystem = prevCS;
    }
};

SZ.ai.apply = function sz_ai_apply(job) {
    if (!app.documents.length) return SZ.err("Open a document first.");
    var prevCS = app.coordinateSystem;
    try {
        var doc = app.activeDocument;
        var idx = doc.artboards.getActiveArtboardIndex();
        SZ.ai.overlay(doc, idx, job.items[0], job.opts);
        SZ.ai.finish(doc);
        return SZ.ok("Added " + job.items[0].title + " to artboard \"" + doc.artboards[idx].name + "\"");
    } finally {
        app.coordinateSystem = prevCS;
    }
};

SZ.ai.toggle = function sz_ai_toggle() {
    if (!app.documents.length) return SZ.err("Open a document first.");
    var doc = app.activeDocument;
    for (var i = 0; i < doc.layers.length; i++) {
        if (doc.layers[i].name.indexOf(SZ.OVERLAY_TAG) === 0) {
            doc.layers[i].visible = !doc.layers[i].visible;
            return SZ.ok((doc.layers[i].visible ? "Showing" : "Hiding") + " overlay");
        }
    }
    return SZ.err("No Safe Zones layer in this document.");
};

SZ.ai.finish = function sz_ai_finish(doc) {
    // Keep an "Artwork" layer active under the locked, non-printing overlay
    var art = null;
    for (var i = 0; i < doc.layers.length; i++) {
        if (doc.layers[i].name.indexOf(SZ.OVERLAY_TAG) !== 0) { art = doc.layers[i]; break; }
    }
    if (!art) { art = doc.layers.add(); }
    if (art.name === "Layer 1") art.name = "Artwork";
    var ov = SZ.ai.layer(doc, SZ.OVERLAY_TAG + " (non-printing)");
    ov.zOrder(ZOrderMethod.BRINGTOFRONT);
    ov.printable = false;
    ov.locked = true;
    doc.activeLayer = art;
};

SZ.ai.overlay = function sz_ai_overlay(doc, abIndex, it, o) {
    var g = it.geo, i;
    doc.artboards.setActiveArtboardIndex(abIndex);
    app.coordinateSystem = CoordinateSystem.ARTBOARDCOORDINATESYSTEM;

    var layer = SZ.ai.layer(doc, SZ.OVERLAY_TAG + " (non-printing)");
    layer.locked = false;
    layer.visible = true;
    var grp = layer.groupItems.add();
    grp.name = it.title + "  " + it.w + "x" + it.h;

    var noColor = new NoColor();

    if (o.mode !== "guides") {
        for (i = 0; i < g.zones.length; i++) {
            var z = g.zones[i];
            var r = grp.pathItems.rectangle(-z.y, z.x, z.w, z.h);
            r.name = z.label || z.id;
            r.filled = true;
            r.fillColor = SZ.ai.rgb(SZ.zoneColor(o, z.kind));
            r.stroked = false;
            r.opacity = (z.kind === "comfort") ? Math.round(o.opacity * 0.7) : o.opacity;
        }
    }

    if (o.outline) {
        var sw = Math.max(2, Math.round(Math.min(it.w, it.h) / 360));
        var s = grp.pathItems.rectangle(-(g.safe.y + sw / 2), g.safe.x + sw / 2, g.safe.w - sw, g.safe.h - sw);
        s.name = "Safe area";
        s.filled = false;
        s.fillColor = noColor;
        s.stroked = true;
        s.strokeColor = SZ.ai.rgb(o.colors.safe);
        s.strokeWidth = sw;
    }

    for (i = 0; i < g.crops.length; i++) {
        var c = g.crops[i];
        var cr = grp.pathItems.rectangle(-(c.y + 1), c.x + 1, c.w - 2, c.h - 2);
        cr.name = c.label;
        cr.filled = false;
        cr.stroked = true;
        cr.strokeColor = SZ.ai.rgb(c.color || o.colors.crop);
        cr.strokeWidth = 2;
        cr.strokeDashes = [24, 14];
    }

    if (o.labels && o.mode !== "guides") {
        var fs = SZ.fontSize(it);
        for (i = 0; i < g.zones.length; i++) {
            var zz = g.zones[i];
            if (!zz.label || zz.h < fs * 1.6 || zz.w < fs * 8) continue;
            var tf = grp.textFrames.add();
            tf.contents = zz.label;
            tf.textRange.characterAttributes.size = fs;
            tf.textRange.characterAttributes.fillColor = SZ.ai.rgb([1, 1, 1]);
            tf.position = [zz.x + fs * 0.6, -(zz.y + fs * 0.5)];
            tf.name = "label - " + zz.label;
        }
    }

    // Guides: paths converted to guides, on the overlay layer.
    // Anchor coordinates can differ from the artboard system, so measure
    // where the artboard's top-left lands with a temporary rectangle.
    if (o.mode !== "mask") {
        var probe = layer.pathItems.rectangle(0, 0, 10, 10);
        var ox = 1e9, oy = -1e9, pp = probe.pathPoints;
        for (i = 0; i < pp.length; i++) {
            if (pp[i].anchor[0] < ox) ox = pp[i].anchor[0];
            if (pp[i].anchor[1] > oy) oy = pp[i].anchor[1];
        }
        probe.remove();
        var ext = 40;
        for (i = 0; i < g.guidesX.length; i++) {
            var vx = layer.pathItems.add();
            vx.setEntirePath([[ox + g.guidesX[i], oy + ext], [ox + g.guidesX[i], oy - (it.h + ext)]]);
            vx.guides = true;
        }
        for (i = 0; i < g.guidesY.length; i++) {
            var hy = layer.pathItems.add();
            hy.setEntirePath([[ox - ext, oy - g.guidesY[i]], [ox + it.w + ext, oy - g.guidesY[i]]]);
            hy.guides = true;
        }
    }
};

/* =====================================================================
 *  PREMIERE PRO
 *  No guide-layer concept in Premiere scripting, so the overlay is a
 *  transparent PNG (rendered by the panel) placed on the top video track.
 * ===================================================================== */
SZ.pr = {};
SZ.pr.TICKS = 254016000000;

SZ.pr.size = function sz_pr_size() {
    var seq = app.project.activeSequence;
    if (!seq) return "NONE|Open a sequence first.";
    return "OK|" + seq.frameSizeHorizontal + "|" + seq.frameSizeVertical + "|" + seq.name;
};

SZ.pr.bin = function sz_pr_bin(name) {
    var root = app.project.rootItem;
    for (var i = 0; i < root.children.numItems; i++) {
        var c = root.children[i];
        if (c.type === ProjectItemType.BIN && c.name === name) return c;
    }
    return root.createBin(name);
};

SZ.pr.norm = function sz_pr_norm(p) { return String(p).replace(/\\/g, "/").toLowerCase(); };

SZ.pr.importPng = function sz_pr_importPng(path, bin) {
    var want = SZ.pr.norm(path);
    var find = function sz_inner_638() {
        for (var i = 0; i < bin.children.numItems; i++) {
            var c = bin.children[i];
            try { if (SZ.pr.norm(c.getMediaPath()) === want) return c; } catch (e) {}
        }
        return null;
    };
    var existing = find();
    if (existing) return existing;
    app.project.importFiles([path], true, bin, false);
    return find();
};

SZ.pr.time = function sz_pr_time(seconds) {
    var t = new Time();
    t.seconds = seconds;
    return t;
};

SZ.pr.frameTime = function sz_pr_frameTime(fps) {
    var t = new Time();
    t.ticks = String(Math.round(SZ.pr.TICKS / fps));
    return t;
};

SZ.pr.placeOnTop = function sz_pr_placeOnTop(seq, pi, durSeconds, clipName) {
    var vt = seq.videoTracks, idx = -1, i;
    for (i = vt.numTracks - 1; i >= 0; i--) {
        if (vt[i].clips.numItems === 0) { idx = i; break; }
    }
    if (idx < 0 || idx < vt.numTracks - 1) {
        // need an empty track at the very top — add one through QE
        try {
            app.enableQE();
            qe.project.getActiveSequence().addTracks(1, vt.numTracks, 0);
            vt = seq.videoTracks;
            idx = vt.numTracks - 1;
        } catch (e) {
            if (idx < 0) return "No empty video track. Add a track at the top and try again.";
        }
    }
    var track = vt[idx];
    track.overwriteClip(pi, 0);
    var clip = track.clips[track.clips.numItems - 1];
    try { clip.name = clipName || SZ.PR_CLIP_NAME; } catch (e1) {}
    var lenMsg = SZ.pr.setLength(seq, clip, durSeconds);
    try { track.setLocked(1); } catch (e3) {}
    return lenMsg;
};

// Length in ticks, snapped to whole frames of the sequence's own timebase.
SZ.pr.lengthTicks = function sz_pr_lengthTicks(seq, seconds) {
    var tb = 0;
    try { tb = parseFloat(seq.timebase); } catch (e) {}
    var raw = seconds * SZ.pr.TICKS;
    if (!(tb > 0)) return Math.round(raw);
    return Math.max(1, Math.round(raw / tb)) * tb;
};

SZ.pr.ticksTime = function sz_pr_ticksTime(ticks) {
    var t = new Time();
    t.ticks = String(Math.round(ticks));
    return t;
};

// Make the clip exactly `seconds` long. Premiere sizes a dropped still from its
// "Still image default duration" preference, and the timeline end doesn't always
// take on the first try, so set it, read it back and fall back to the out point.
SZ.pr.setLength = function sz_pr_setLength(seq, clip, seconds) {
    if (!clip) return "";
    var want = SZ.pr.lengthTicks(seq, seconds), tb = 0;
    try { tb = parseFloat(seq.timebase) || 0; } catch (e0) {}
    var tol = tb ? tb / 2 : SZ.pr.TICKS / 120;
    var startT = 0;
    try { startT = parseFloat(clip.start.ticks); } catch (e1) {}
    var ok = function () {
        try { return Math.abs(parseFloat(clip.end.ticks) - startT - want) <= tol; } catch (e) { return false; }
    };
    var secOf = function (tk) { return Math.round(parseFloat(tk) / SZ.pr.TICKS * 1000) / 1000; };
    var d = ["tb " + (tb ? Math.round(SZ.pr.TICKS / tb * 1000) / 1000 + "fps" : "?")];
    try { d.push("start " + secOf(clip.start.ticks)); } catch (eD) {}
    try { d.push("end " + secOf(clip.end.ticks)); } catch (eD2) {}
    try { d.push("dur " + secOf(clip.duration.ticks)); } catch (eD3) {}
    for (var attempt = 0; attempt < 2 && !ok(); attempt++) {
        try { clip.end = SZ.pr.ticksTime(startT + want); } catch (e2) {}
    }
    if (!ok()) {
        try {
            var inT = parseFloat(clip.inPoint.ticks) || 0;
            clip.outPoint = SZ.pr.ticksTime(inT + want);
        } catch (e3) {}
        if (!ok()) { try { clip.end = SZ.pr.ticksTime(startT + want); } catch (e4) {} }
    }
    try { d.push("->end " + secOf(clip.end.ticks)); } catch (eD4) {}
    try { d.push("->dur " + secOf(clip.duration.ticks)); } catch (eD5) {}
    try { d.push("seqEnd " + secOf(seq.end)); } catch (eD6) {}
    SZ.pr.lastLen = d.join(" ");
    if (ok()) return "";
    var got = 0;
    try { got = (parseFloat(clip.end.ticks) - startT) / SZ.pr.TICKS; } catch (e5) {}
    return "Premiere set the overlay to " + (Math.round(got * 100) / 100) + " s instead of " + seconds + " s. Trim it to length on the timeline.";
};

// The still's own out point (what a drag from the bin would use). Best effort only:
// placeOnTop/setLength fix the clip on the timeline either way.
SZ.pr.setItemOut = function sz_pr_setItemOut(pi, seconds, fps) {
    var tk = seconds * SZ.pr.TICKS;
    if (fps > 0) { var fr = SZ.pr.TICKS / fps; tk = Math.max(1, Math.round(tk / fr)) * fr; }
    try { pi.setOutPoint(SZ.pr.ticksTime(tk), 4); return; } catch (e) {}
    try { pi.setOutPoint(seconds, 4); } catch (e2) {}
};

SZ.pr.create = function sz_pr_create(job) {
    var o = job.opts, bin = SZ.pr.bin(o.folder || "Safe Zones"), warn = "";
    for (var i = 0; i < job.items.length; i++) {
        var it = job.items[i];
        var pi = SZ.pr.importPng(it.png, bin);
        if (!pi) return SZ.err("Could not import overlay: " + it.png);

        // A sequence made from a still takes its frame rate from the still's
        // interpretation (24 fps by default), so interpret the PNG at the chosen rate first.
        try {
            var fi = pi.getFootageInterpretation();
            fi.frameRate = o.fps;
            pi.setFootageInterpretation(fi);
        } catch (eF) {}
        // Out point after the interpretation: Premiere keeps the frame count when the
        // rate changes, so an out point set first ends up at the wrong time.
        SZ.pr.setItemOut(pi, o.duration, o.fps);
        var seq = app.project.createNewSequenceFromClips(it.name, [pi], bin);
        if (!seq) return SZ.err("Premiere could not create the sequence.");
        app.project.openSequence(seq.sequenceID);

        var st = seq.getSettings();
        st.videoFrameWidth = it.w;
        st.videoFrameHeight = it.h;
        try { st.videoFrameRate = SZ.pr.frameTime(o.fps); } catch (e1) { warn = "Set the frame rate in Sequence Settings."; }
        seq.setSettings(st);
        // read it back: Premiere doesn't always accept a new frame rate on a sequence
        try {
            var gotT = parseFloat(seq.getSettings().videoFrameRate.ticks);
            if (gotT > 0 && Math.abs(gotT - SZ.pr.TICKS / o.fps) > 2) {
                warn = "Premiere kept the sequence at " + (Math.round(SZ.pr.TICKS / gotT * 1000) / 1000) +
                    " fps. Change it in Sequence > Sequence Settings.";
            }
        } catch (eR) {}

        // createNewSequenceFromClips drops the PNG on V1 — move it to the top track
        try {
            var first = seq.videoTracks[0].clips[0];
            if (first) first.remove(false, false);
        } catch (e2) {}
        // give the editor working tracks under the overlay
        try {
            var n = seq.videoTracks.numTracks;
            if (n < 3) {
                app.enableQE();
                qe.project.getActiveSequence().addTracks(3 - n, n, 0);
            }
        } catch (e3) {}
        var msg = SZ.pr.placeOnTop(seq, pi, o.duration);
        if (msg && warn.indexOf(msg) < 0) warn = warn ? warn + " " + msg : msg;
        if (it.uiPng) {
            var ui = SZ.pr.importPng(it.uiPng, bin);
            if (!ui) warn = "Could not import the UI preview.";
            else {
                try {
                    var ufi = ui.getFootageInterpretation();
                    ufi.frameRate = o.fps;
                    ui.setFootageInterpretation(ufi);
                } catch (eU) {}
                SZ.pr.setItemOut(ui, o.duration, o.fps);
                msg = SZ.pr.placeOnTop(seq, ui, o.duration, SZ.PR_UI_CLIP_NAME);
                if (msg && warn.indexOf(msg) < 0) warn = warn ? warn + " " + msg : msg;
            }
        }
    }
    return SZ.ok("Created " + job.items.length + " sequence" + (job.items.length > 1 ? "s" : "") + (warn ? ". " + warn : ""));
};

// Interpret a still at the sequence's own frame rate and give it enough media
// to cover `seconds`, so trimming the clip to length can't run out of frames.
SZ.pr.fitItem = function sz_pr_fitItem(pi, seq, seconds) {
    var fps = 0;
    try { fps = SZ.pr.TICKS / parseFloat(seq.timebase); } catch (e) {}
    if (fps > 0) {
        try {
            var fi = pi.getFootageInterpretation();
            fi.frameRate = fps;
            pi.setFootageInterpretation(fi);
        } catch (e2) {}
    }
    SZ.pr.setItemOut(pi, seconds, fps);
};

SZ.pr.apply = function sz_pr_apply(job) {
    var seq = app.project.activeSequence;
    if (!seq) return SZ.err("Open a sequence first.");
    var it = job.items[0];
    var bin = SZ.pr.bin(job.opts.folder || "Safe Zones");
    var pi = SZ.pr.importPng(it.png, bin);
    if (!pi) return SZ.err("Could not import overlay: " + it.png);
    var dur = Math.max(1, parseFloat(seq.end) / SZ.pr.TICKS);
    SZ.pr.fitItem(pi, seq, dur);
    var msg = SZ.pr.placeOnTop(seq, pi, dur);
    if (msg) return SZ.err(msg);
    if (it.uiPng) {
        var ui = SZ.pr.importPng(it.uiPng, bin);
        if (!ui) return SZ.err("Added the overlay, but could not import the UI preview: " + it.uiPng);
        SZ.pr.fitItem(ui, seq, dur);
        msg = SZ.pr.placeOnTop(seq, ui, dur, SZ.PR_UI_CLIP_NAME);
        if (msg) return SZ.err(msg);
        return SZ.ok("Added " + it.title + " overlay and " + (it.uiTitle || "UI") + " preview to \"" + seq.name + "\"");
    }
    return SZ.ok("Added " + it.title + " overlay to \"" + seq.name + "\"");
};

SZ.pr.toggle = function sz_pr_toggle() {
    var seq = app.project.activeSequence;
    if (!seq) return SZ.err("Open a sequence first.");
    var count = 0, state = null;
    for (var t = 0; t < seq.videoTracks.numTracks; t++) {
        var tr = seq.videoTracks[t];
        for (var c = 0; c < tr.clips.numItems; c++) {
            var clip = tr.clips[c];
            if (clip.name === SZ.PR_CLIP_NAME || clip.name === SZ.PR_UI_CLIP_NAME) {
                if (state === null) state = !clip.disabled;
                clip.disabled = state;
                count++;
            }
        }
    }
    if (!count) return SZ.err("No Safe Zones overlay in this sequence.");
    return SZ.ok((state ? "Disabled " : "Enabled ") + count + " overlay clip" + (count > 1 ? "s" : "") + (state ? " — ready to export" : ""));
};

/* =====================================================================
 *  FIX LAYOUT (2.1) — list layers and move them
 *  The panel plans everything (layout.js). These functions only report
 *  each layer's box in frame pixels and apply the moves it sends back.
 * ===================================================================== */

// Tiny JSON writer (ExtendScript has no JSON object)
SZ.json = function sz_json(v) {
    var t = typeof v, i, out;
    if (v === null || v === undefined) return "null";
    if (t === "number") return isFinite(v) ? String(Math.round(v * 100) / 100) : "0";
    if (t === "boolean") return v ? "true" : "false";
    if (t === "string") {
        out = "";
        for (i = 0; i < v.length; i++) {
            var c = v.charAt(i), code = v.charCodeAt(i);
            if (c === "\"" || c === "\\") out += "\\" + c;
            else if (code < 32 || code > 126) { var hx = code.toString(16); while (hx.length < 4) hx = "0" + hx; out += "\\u" + hx; }
            else out += c;
        }
        return "\"" + out + "\"";
    }
    if (v instanceof Array) {
        out = [];
        for (i = 0; i < v.length; i++) out.push(SZ.json(v[i]));
        return "[" + out.join(",") + "]";
    }
    out = [];
    for (var k in v) if (v.hasOwnProperty(k)) out.push(SZ.json(String(k)) + ":" + SZ.json(v[k]));
    return "{" + out.join(",") + "}";
};

SZ.isOwn = function sz_isOwn(name) {
    return String(name).indexOf(SZ.OVERLAY_TAG) === 0 || String(name).indexOf("SAFE ZONE") === 0;
};

/* ---------- After Effects ---------- */

// Layer-space point → comp space, through every parent (2D maths; 3D depth is ignored)
SZ.ae.xf = function sz_ae_xf(L, t) {
    var tr = L.property("ADBE Transform Group");
    var pos;
    var P = tr.property("ADBE Position");
    if (P.dimensionsSeparated) pos = [tr.property("ADBE Position_0").valueAtTime(t, false), tr.property("ADBE Position_1").valueAtTime(t, false)];
    else pos = P.valueAtTime(t, false);
    var a = tr.property("ADBE Anchor Point").valueAtTime(t, false);
    var s = tr.property("ADBE Scale").valueAtTime(t, false);
    var r = tr.property("ADBE Rotate Z").valueAtTime(t, false) * Math.PI / 180;
    return { px: pos[0], py: pos[1], ax: a[0], ay: a[1], sx: s[0] / 100, sy: s[1] / 100, c: Math.cos(r), s: Math.sin(r) };
};
SZ.ae.toComp = function sz_ae_toComp(L, t, x, y) {
    var cur = L, guard = 0;
    while (cur && guard++ < 50) {
        var m = SZ.ae.xf(cur, t);
        var lx = (x - m.ax) * m.sx, ly = (y - m.ay) * m.sy;
        x = m.px + lx * m.c - ly * m.s;
        y = m.py + lx * m.s + ly * m.c;
        cur = cur.parent;
    }
    return [x, y];
};
SZ.ae.box = function sz_ae_box(L, t) {
    var r = L.sourceRectAtTime(t, false);
    if (!r || !(r.width > 0) || !(r.height > 0)) return null;
    var pts = [[r.left, r.top], [r.left + r.width, r.top], [r.left, r.top + r.height], [r.left + r.width, r.top + r.height]];
    var x1 = 1e9, y1 = 1e9, x2 = -1e9, y2 = -1e9;
    for (var i = 0; i < 4; i++) {
        var p = SZ.ae.toComp(L, t, pts[i][0], pts[i][1]);
        if (p[0] < x1) x1 = p[0]; if (p[0] > x2) x2 = p[0];
        if (p[1] < y1) y1 = p[1]; if (p[1] > y2) y2 = p[1];
    }
    return { x: x1, y: y1, w: x2 - x1, h: y2 - y1 };
};
SZ.ae.kind = function sz_ae_kind(L) {
    if (L instanceof TextLayer) return "text";
    if (L instanceof ShapeLayer) return "shape";
    try {
        var src = L.source;
        if (src instanceof CompItem) return "precomp";
        if (src && src.mainSource) {
            if (src.mainSource instanceof SolidSource) return "shape";
            if (src.mainSource.isStill) return "image";
            if (src.hasVideo) return "video";
        }
    } catch (e) {}
    return "other";
};
SZ.ae.usable = function sz_ae_usable(L) {
    if (L instanceof CameraLayer || L instanceof LightLayer) return false;
    if (!(L instanceof AVLayer)) return false;          // Text and Shape layers are AVLayers too
    if (L.guideLayer || L.adjustmentLayer || L.nullLayer) return false;
    if (!L.hasVideo) return false;
    if (SZ.isOwn(L.name) || L.comment === SZ.OVERLAY_TAG) return false;
    return true;
};

SZ.ae.layers = function sz_ae_layers() {
    var c = app.project.activeItem;
    if (!(c && c instanceof CompItem)) return "ERR|Open or select a composition first.";
    var t = c.time, out = [];
    for (var i = 1; i <= c.numLayers; i++) {
        var L = c.layer(i);
        if (!SZ.ae.usable(L)) continue;
        var b = null;
        try { b = SZ.ae.box(L, t); } catch (e) { b = null; }
        if (!b) continue;
        var active = L.enabled && L.activeAtTime(t);
        out.push({ id: String(L.index), name: L.name, kind: SZ.ae.kind(L), x: b.x, y: b.y, w: b.w, h: b.h,
                   z: i - 1, locked: L.locked, hidden: !active });
    }
    return "OK|" + SZ.json({ w: c.width, h: c.height, name: c.name, layers: out });
};

// Adds d to a property's value, or to every keyframe if it is animated
SZ.ae.offset = function sz_ae_offset(prop, d) {
    var k, v;
    if (prop.numKeys > 0) {
        for (k = 1; k <= prop.numKeys; k++) {
            v = prop.keyValue(k);
            if (v instanceof Array) { v[0] += d[0]; v[1] += d[1]; } else v += d[0];
            prop.setValueAtKey(k, v);
        }
    } else {
        v = prop.value;
        if (v instanceof Array) { v[0] += d[0]; v[1] += d[1]; } else v += d[0];
        prop.setValue(v);
    }
};
SZ.ae.mulScale = function sz_ae_mulScale(prop, s) {
    var k, v;
    if (prop.numKeys > 0) {
        for (k = 1; k <= prop.numKeys; k++) {
            v = prop.keyValue(k); v[0] *= s; v[1] *= s;
            prop.setValueAtKey(k, v);
        }
    } else {
        v = prop.value; v[0] *= s; v[1] *= s;
        prop.setValue(v);
    }
};
SZ.ae.hasExpr = function sz_ae_hasExpr(prop) {
    try { return prop.canSetExpression && prop.expressionEnabled && prop.expression !== ""; } catch (e) { return false; }
};

SZ.ae.fixlayout = function sz_ae_fixlayout(job) {
    var c = app.project.activeItem;
    if (!(c && c instanceof CompItem)) return SZ.err("Open or select a composition first.");
    if (c.width !== job.w || c.height !== job.h) return SZ.err("The active comp changed since the scan — scan again.");
    var t = c.time, done = 0, skipped = [], i;
    app.beginUndoGroup("Feedproof: Snap to Safe");
    try {
        for (i = 0; i < job.fixes.length; i++) {
            var f = job.fixes[i];
            var idx = parseInt(f.id, 10);
            if (!(idx >= 1 && idx <= c.numLayers)) { skipped.push(f.name); continue; }
            var L = c.layer(idx);
            if (L.name !== f.name || L.locked) { skipped.push(f.name); continue; }
            var tr = L.property("ADBE Transform Group");
            var P = tr.property("ADBE Position"), Sc = tr.property("ADBE Scale");
            var sep = P.dimensionsSeparated;
            var PX = sep ? tr.property("ADBE Position_0") : null, PY = sep ? tr.property("ADBE Position_1") : null;
            if ((sep ? (SZ.ae.hasExpr(PX) || SZ.ae.hasExpr(PY)) : SZ.ae.hasExpr(P)) || (f.scale < 0.999 && SZ.ae.hasExpr(Sc))) {
                skipped.push(f.name + " (expression)"); continue;
            }
            var b = SZ.ae.box(L, t);
            if (!b) { skipped.push(f.name); continue; }
            var s = f.scale || 1;
            var a = tr.property("ADBE Anchor Point").valueAtTime(t, false);
            var A = SZ.ae.toComp(L, t, a[0], a[1]);                  // anchor in comp space
            var cx = b.x + b.w / 2, cy = b.y + b.h / 2;              // box centre now
            var tx = f.to.x + f.to.w / 2, ty = f.to.y + f.to.h / 2;  // box centre wanted
            // after scaling about the anchor the centre lands here; move the rest of the way
            var dx = tx - (A[0] + s * (cx - A[0])), dy = ty - (A[1] + s * (cy - A[1]));
            // comp-space move → the parent's space (position lives there)
            if (L.parent) {
                var o = SZ.ae.toComp(L.parent, t, 0, 0), ex = SZ.ae.toComp(L.parent, t, 1, 0), ey = SZ.ae.toComp(L.parent, t, 0, 1);
                var m00 = ex[0] - o[0], m10 = ex[1] - o[1], m01 = ey[0] - o[0], m11 = ey[1] - o[1];
                var det = m00 * m11 - m01 * m10;
                if (Math.abs(det) < 1e-9) { skipped.push(f.name); continue; }
                var px = (m11 * dx - m01 * dy) / det, py = (-m10 * dx + m00 * dy) / det;
                dx = px; dy = py;
            }
            if (s < 0.999) SZ.ae.mulScale(Sc, s);
            if (sep) { SZ.ae.offset(PX, [dx]); SZ.ae.offset(PY, [dy]); }
            else SZ.ae.offset(P, [dx, dy]);
            done++;
        }
    } finally {
        app.endUndoGroup();
    }
    var msg = "Fixed " + done + " layer" + (done === 1 ? "" : "s") + " in “" + c.name + "” (one undo step).";
    if (skipped.length) msg += " Skipped: " + skipped.join(", ") + ".";
    return done ? SZ.ok(msg) : SZ.err("Nothing was moved. " + (skipped.length ? "Skipped: " + skipped.join(", ") + " — scan again." : ""));
};

/* ---------- Illustrator ---------- */
// Boxes come from document coordinates (y up) relative to the active artboard.

SZ.ai.kind = function sz_ai_kind(it) {
    var tn = it.typename;
    if (tn === "TextFrame") return "text";
    if (tn === "PlacedItem" || tn === "SymbolItem") return "smart";
    if (tn === "RasterItem") return "image";
    if (tn === "GroupItem") return "group";
    if (tn === "PathItem" || tn === "CompoundPathItem") return "shape";
    return "other";
};
// Clipping groups report their hidden contents in visibleBounds — use the clip path
SZ.ai.bounds = function sz_ai_bounds(it) {
    try {
        if (it.typename === "GroupItem" && it.clipped) {
            for (var i = 0; i < it.pageItems.length; i++) {
                var p = it.pageItems[i];
                if ((p.typename === "PathItem" && p.clipping) ||
                    (p.typename === "CompoundPathItem" && p.pathItems.length && p.pathItems[0].clipping)) return p.geometricBounds;
            }
        }
    } catch (e) {}
    return it.visibleBounds;
};
SZ.ai.frame = function sz_ai_frame(doc) {
    var ab = doc.artboards[doc.artboards.getActiveArtboardIndex()];
    var r = ab.artboardRect;
    return { ab: ab, l: r[0], t: r[1], w: Math.round(Math.abs(r[2] - r[0])), h: Math.round(Math.abs(r[1] - r[3])) };
};
SZ.ai.walk = function sz_ai_walk(doc, fn) {
    var z = 0;
    for (var li = 0; li < doc.layers.length; li++) {
        var lay = doc.layers[li];
        if (SZ.isOwn(lay.name)) continue;
        for (var ii = 0; ii < lay.pageItems.length; ii++) {
            var it = lay.pageItems[ii];
            fn(it, lay, li + ":" + ii, z++);
        }
    }
};

SZ.ai.layers = function sz_ai_layers() {
    if (!app.documents.length) return "ERR|Open a document first.";
    var doc = app.activeDocument, prevCS = app.coordinateSystem, out = [];
    app.coordinateSystem = CoordinateSystem.DOCUMENTCOORDINATESYSTEM;
    try {
        var F = SZ.ai.frame(doc);
        SZ.ai.walk(doc, function (it, lay, id, z) {
            if (it.guides) return;
            var b = SZ.ai.bounds(it);
            var box = { x: b[0] - F.l, y: F.t - b[1], w: b[2] - b[0], h: b[1] - b[3] };
            // only what touches this artboard
            if (box.x > F.w || box.y > F.h || box.x + box.w < 0 || box.y + box.h < 0) return;
            out.push({ id: id, name: it.name || (it.typename === "TextFrame" ? String(it.contents).slice(0, 40) : it.typename.replace(/Item$/, "")),
                       kind: SZ.ai.kind(it), x: box.x, y: box.y, w: box.w, h: box.h, z: z,
                       locked: it.locked || lay.locked, hidden: it.hidden || !lay.visible });
        });
        return "OK|" + SZ.json({ w: F.w, h: F.h, name: F.ab.name, layers: out });
    } finally {
        app.coordinateSystem = prevCS;
    }
};

SZ.ai.fixlayout = function sz_ai_fixlayout(job) {
    if (!app.documents.length) return SZ.err("Open a document first.");
    var doc = app.activeDocument, prevCS = app.coordinateSystem, done = 0, skipped = [];
    app.coordinateSystem = CoordinateSystem.DOCUMENTCOORDINATESYSTEM;
    try {
        var F = SZ.ai.frame(doc);
        if (F.w !== job.w || F.h !== job.h) return SZ.err("The active artboard changed since the scan — scan again.");
        var byId = {};
        SZ.ai.walk(doc, function (it, lay, id) { byId[id] = it; });
        for (var i = 0; i < job.fixes.length; i++) {
            var f = job.fixes[i], it = byId[f.id];
            var nm = it ? (it.name || (it.typename === "TextFrame" ? String(it.contents).slice(0, 40) : it.typename.replace(/Item$/, ""))) : null;
            if (!it || nm !== f.name || it.locked) { skipped.push(f.name); continue; }
            var s = f.scale || 1;
            if (s < 0.999) it.resize(s * 100, s * 100, true, true, true, true, s * 100, Transformation.CENTER);
            var b = SZ.ai.bounds(it);
            var cx = (b[0] + b[2]) / 2 - F.l, cy = F.t - (b[1] + b[3]) / 2;
            var tx = f.to.x + f.to.w / 2, ty = f.to.y + f.to.h / 2;
            it.translate(tx - cx, -(ty - cy));
            done++;
        }
    } finally {
        app.coordinateSystem = prevCS;
    }
    var msg = "Fixed " + done + " item" + (done === 1 ? "" : "s") + " on artboard “" + job.name + "”.";
    if (skipped.length) msg += " Skipped: " + skipped.join(", ") + ".";
    return done ? SZ.ok(msg) : SZ.err("Nothing was moved. " + (skipped.length ? "Skipped: " + skipped.join(", ") + " — scan again." : ""));
};

// Record every module call in SZ.trail (diagnostics).
(function sz_instrument() {
    var names = ["ae", "ps", "ai", "pr"];
    var wrap = function sz_wrap(fn, label) {
        return function sz_traced() { SZ.mark(label); return fn.apply(this, arguments); };
    };
    for (var m = 0; m < names.length; m++) {
        var mod = SZ[names[m]];
        for (var k in mod) {
            if (mod.hasOwnProperty(k) && typeof mod[k] === "function") mod[k] = wrap(mod[k], names[m] + "." + k);
        }
    }
})();

// Publish under a name no other extension uses. Everything above is
// sealed in this closure, so another script redefining "SZ" cannot break it.
$.global.FeedproofFX = SZ;

})();
