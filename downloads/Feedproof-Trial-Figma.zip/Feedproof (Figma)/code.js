/* Generated from feedproof-config/license.json — do not edit by hand.
 * Feedproof © 2026 Edgar Febus. All rights reserved. */
(function (root) { root.FP_LICENSE_CONFIG = {"mode": "trial", "audience": "public", "licensee": "Trial", "slug": "public-trial", "agreementSigned": null, "trialDays": 15, "hardCutoff": "2027-05-03", "reminderDays": 5, "contact": "edgar.febus@gmail.com", "seats": null, "features": {"pngWatermark": true}, "tag": "Trial"}; })(typeof window !== "undefined" ? window : (typeof globalThis !== "undefined" ? globalThis : this));

/*
 * Feedproof — evaluation / license logic (shared by every host)
 * © 2026 Edgar Febus. All rights reserved.
 * https://edgarfebus.com
 *
 * Pure logic, no DOM: the CEP panel (AE, Premiere, Illustrator), the UXP
 * plugins (Photoshop, InDesign), Figma (UI and main thread) and Acrobat all
 * load this same file, so dates, rules and wording are identical everywhere.
 *
 * Trial rules
 *   - 30 days (config.trialDays) from the first launch on this user account.
 *   - Hard cutoff date (config.hardCutoff): the trial ends then no matter what.
 *   - The first-launch date lives OUTSIDE the plugin's install folder, so
 *     uninstalling / reinstalling doesn't reset it. Several stores are kept
 *     (shared file, app storage); the EARLIEST first launch wins.
 *   - Clock tamper: the latest date seen is stored; a clock set back more
 *     than 2 hours behind it ends the trial (sticky). A later server date
 *     (from the spec-feed response) is used when it's ahead of the clock.
 *   - Offline use before expiry is never blocked.
 *
 * config (generated from the single config file — see license-config.js):
 *   { mode: "trial"|"licensed", licensee, slug, agreementSigned (YYYY-MM-DD),
 *     trialDays, hardCutoff (YYYY-MM-DD), reminderDays, contact, seats }
 */
(function (root) {
  "use strict";

  var DAY = 86400000;
  var TOLERANCE = 2 * 3600000;        // clock jitter allowed before "set back" counts
  var MONTHS = ["January", "February", "March", "April", "May", "June", "July",
                "August", "September", "October", "November", "December"];

  function num(v) { return (typeof v === "number" && isFinite(v) && v > 0) ? v : 0; }

  function parseYMD(s) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(s || ""));
    return m ? { y: +m[1], m: +m[2], d: +m[3] } : null;
  }
  // end of that calendar day, local time
  function endOfDay(s) {
    var p = parseYMD(s);
    return p ? new Date(p.y, p.m - 1, p.d, 23, 59, 59, 999).getTime() : 0;
  }
  function formatDate(ms) {
    var d = new Date(ms);
    return MONTHS[d.getMonth()] + " " + d.getDate() + ", " + d.getFullYear();
  }
  function formatYMD(s) {
    var p = parseYMD(s);
    return p ? formatDate(new Date(p.y, p.m - 1, p.d, 12).getTime()) : "[agreement date]";
  }

  function blank() { return { v: 1, firstLaunch: 0, lastSeen: 0, accepted: 0, tampered: false }; }

  // Combine records from several stores: earliest first launch, latest date seen,
  // acceptance from any store, tamper flag from any store.
  function merge(list) {
    var r = blank();
    for (var i = 0; i < (list || []).length; i++) {
      var x = list[i];
      if (!x || typeof x !== "object") continue;
      var f = num(x.firstLaunch);
      if (f && (!r.firstLaunch || f < r.firstLaunch)) r.firstLaunch = f;
      r.lastSeen = Math.max(r.lastSeen, num(x.lastSeen));
      r.accepted = Math.max(r.accepted, num(x.accepted));
      if (x.tampered === true) r.tampered = true;
    }
    return r;
  }

  function parseRecord(text) {
    try { var o = JSON.parse(text); return (o && typeof o === "object") ? o : null; } catch (e) { return null; }
  }

  // opts.clock: optional function returning "now" in ms (tests; defaults to Date.now)
  function create(cfg, opts) {
    cfg = cfg || {};
    var clock = (opts && typeof opts.clock === "function") ? opts.clock : function () { return Date.now(); };
    var trial = cfg.mode !== "licensed";
    var PUBLIC = cfg.audience === "public";
    var NOUN = PUBLIC ? "trial" : "evaluation";
    var rec = blank();
    var serverAhead = 0;               // ms the server clock is ahead of ours (from the feed)
    var loaded = false;

    function now() { return clock() + serverAhead; }

    function expiryOf(r) {
      var byDays = r.firstLaunch + (cfg.trialDays || 30) * DAY;
      var cut = endOfDay(cfg.hardCutoff);
      return { at: cut ? Math.min(byDays, cut) : byDays, byCutoff: !!cut && cut < byDays };
    }

    // Seen a time: record it, catch a clock that went backwards
    function see(t) {
      if (rec.lastSeen && t < rec.lastSeen - TOLERANCE) rec.tampered = true;
      if (t > rec.lastSeen) rec.lastSeen = t;
    }

    function status() {
      var info = {
        mode: trial ? "trial" : "licensed",
        state: "active", reason: "", expiry: 0, expiryText: "", daysLeft: null,
        reminder: false, accepted: !!rec.accepted, byCutoff: false
      };
      if (!trial) return info;
      var t = now();
      var e = expiryOf(rec);
      info.expiry = e.at;
      info.byCutoff = e.byCutoff;
      info.expiryText = formatDate(e.at);
      info.daysLeft = Math.max(0, Math.ceil((e.at - t) / DAY));
      if (rec.tampered) { info.state = "expired"; info.reason = "clock"; }
      else if (t >= e.at) { info.state = "expired"; info.reason = e.byCutoff ? "cutoff" : "time"; }
      else if (!rec.accepted) info.state = "agree";
      info.reminder = info.state === "active" && info.daysLeft <= (cfg.reminderDays || 5);
      return info;
    }

    var api = {
      config: cfg,
      isTrial: trial,
      DAY: DAY,
      // records: array of whatever each store returned (objects or null)
      load: function (records) {
        rec = merge(records);
        var t = now();
        if (trial && !rec.firstLaunch) rec.firstLaunch = t;
        if (trial) see(t);
        loaded = true;
        return status();
      },
      // Re-check during a session (before every action)
      check: function () {
        if (trial && loaded) see(now());
        return status();
      },
      // A trustworthy date from the network (spec-feed HTTP response)
      observeServerTime: function (ms) {
        if (!trial || !num(ms)) return status();
        var ahead = ms - clock();
        if (ahead > TOLERANCE) serverAhead = Math.max(serverAhead, ahead);
        if (ms > rec.lastSeen) rec.lastSeen = ms;
        return status();
      },
      accept: function (at) { rec.accepted = typeof at === "number" ? at : now(); return status(); },
      record: function () { return JSON.parse(JSON.stringify(rec)); },
      status: status,

      // Features a trial can switch off (config.features), e.g. { exportPng: false }
      feature: function (name) {
        if (!trial) return true;
        return !(cfg.features && cfg.features[name] === false);
      },
      expiredTitle: function () { return "Feedproof " + NOUN + " ended"; },
      agreePrompt: function () { return "Read and accept the " + NOUN + " license to continue."; },
      // On/off switches for trial-only behaviour (config.features), e.g. { pngWatermark: true }
      flag: function (name) {
        return trial && !!(cfg.features && cfg.features[name] === true);
      },
      featureMessage: function () {
        return "Not available in the trial version. To unlock it, contact Edgar Febus at " + cfg.contact + ".";
      },

      // ── Wording (identical in every host) ───────────────────────────
      // audience "public" = download trial (no named licensee / signed agreement)
      footer: function () {
        if (trial && PUBLIC) return "\u00a9 2026 Edgar Febus \u00b7 Trial version \u00b7 Not for redistribution";
        if (trial) return "© 2026 Edgar Febus · Evaluation copy licensed to " + cfg.licensee + " · Not for redistribution";
        return "© 2026 Edgar Febus. All rights reserved. · Licensed to " + cfg.licensee +
               (cfg.seats ? " — " + cfg.seats + " seat" + (cfg.seats === 1 ? "" : "s") : "");
      },
      agreement: function () {
        var st = status();
        if (PUBLIC) {
          return {
            title: "Feedproof \u2014 Trial License",
            paragraphs: [
              "\u00a9 2026 Edgar Febus. All rights reserved.",
              "This trial copy of Feedproof is provided for evaluation only. It may not be copied, shared, redistributed or reverse-engineered. All ownership and intellectual property rights remain with Edgar Febus.",
              (st.byCutoff ? "This trial ends on " + st.expiryText + "."
                           : "This trial lasts " + (cfg.trialDays || 15) + " days from your first launch, until " + st.expiryText + ".") +
                (cfg.features && cfg.features.exportPng === false ? " Some features, like Export PNG, are available only in the full version." : "") +
                (cfg.features && cfg.features.pngWatermark === true ? " PNG exports include a trial watermark." : "") +
                " Continued use after the trial requires a purchased license.",
              "Platform names (Meta, TikTok, YouTube, LinkedIn) are trademarks of their respective owners. Safe-zone specifications are provided as guidance; always verify final deliverables against current platform requirements."
            ],
            button: "I agree"
          };
        }
        var ends = st.byCutoff
          ? "This evaluation ends on " + st.expiryText + "."
          : "This evaluation ends " + (cfg.trialDays || 30) + " days after first launch, on " + st.expiryText + ".";
        return {
          title: "Feedproof — Evaluation License",
          paragraphs: [
            "© 2026 Edgar Febus. All rights reserved.",
            "This copy of Feedproof is provided to " + cfg.licensee + " for internal evaluation only, under the evaluation agreement signed " +
              formatYMD(cfg.agreementSigned) + ". It may not be copied, shared, redistributed, reverse-engineered or used outside " +
              cfg.licensee + ". All ownership and intellectual property rights remain with Edgar Febus.",
            ends + " Continued use after that requires a purchased license.",
            "Platform names (Meta, TikTok, YouTube, LinkedIn) are trademarks of their respective owners. Safe-zone specifications are provided as guidance; always verify final deliverables against current platform requirements."
          ],
          button: "I agree"
        };
      },
      expiredMessage: function () {
        var st = status();
        var lead = st.reason === "clock"
          ? "Your Feedproof " + NOUN + " has ended (the computer's date was set back)."
          : "Your Feedproof " + NOUN + " ended on " + st.expiryText + ".";
        return lead + " To keep using Feedproof, contact Edgar Febus at " + cfg.contact + ".";
      },
      reminderMessage: function () {
        var st = status();
        var left = st.daysLeft <= 1 ? "less than a day left" : st.daysLeft + " days left";
        return "Your Feedproof " + NOUN + " ends on " + st.expiryText + " (" + left + "). To keep using Feedproof, contact Edgar Febus at " + cfg.contact + ".";
      },
      storageKey: "feedproof.license." + (cfg.slug || "default"),
      fileName: ".license-" + (cfg.slug || "default") + ".json"
    };
    return api;
  }

  // ── Store helpers ─────────────────────────────────────────────────
  // A store is { name, read() -> Promise<record|null>, write(record) -> Promise }.

  // Shared settings folder outside every plugin's install folder:
  //   macOS   ~/Library/Application Support/Feedproof/
  //   Windows %APPDATA%\Feedproof\
  function sharedDir(home, platform, appData) {
    if (/^win/.test(platform)) return (appData || (home + "\\AppData\\Roaming")) + "\\Feedproof";
    return home + "/Library/Application Support/Feedproof";
  }

  // Node-style fs (CEP panels run Node): synchronous, wrapped in promises
  function nodeFileStore(fs, dir, fileName) {
    var sep = dir.indexOf("\\") >= 0 ? "\\" : "/";
    var file = dir + sep + fileName;
    return {
      name: "file:" + file,
      read: function () {
        try { return Promise.resolve(parseRecord(fs.readFileSync(file, "utf8"))); } catch (e) { return Promise.resolve(null); }
      },
      write: function (r) {
        try {
          if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
          fs.writeFileSync(file, JSON.stringify(r));
        } catch (e) {}
        return Promise.resolve();
      }
    };
  }

  // Any localStorage-like object (CEP / UXP panel storage, Figma clientStorage mirror)
  function keyValueStore(storage, key) {
    return {
      name: "storage:" + key,
      read: function () {
        try { return Promise.resolve(parseRecord(storage.getItem(key))); } catch (e) { return Promise.resolve(null); }
      },
      write: function (r) {
        try { storage.setItem(key, JSON.stringify(r)); } catch (e) {}
        return Promise.resolve();
      }
    };
  }

  // Read every store, merge, save the merged record back to all of them
  function readAll(stores) {
    return Promise.all(stores.map(function (s) {
      return s.read().then(function (r) { return r; }, function () { return null; });
    }));
  }
  function writeAll(stores, r) {
    return Promise.all(stores.map(function (s) {
      return s.write(r).then(null, function () {});
    }));
  }

  var api = {
    create: create, merge: merge, formatDate: formatDate, endOfDay: endOfDay,
    parseRecord: parseRecord, sharedDir: sharedDir,
    nodeFileStore: nodeFileStore, keyValueStore: keyValueStore,
    readAll: readAll, writeAll: writeAll
  };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.FPLicense = api;
})(typeof window !== "undefined" ? window : (typeof globalThis !== "undefined" ? globalThis : this));

/*
 * Feedproof — Meta, TikTok, YouTube & LinkedIn safe zones for Figma
 * © 2026 Edgar Febus. All rights reserved.
 * https://edgarfebus.com
 *
 * Figma main thread. The panel (ui.html — the same panel as the Adobe
 * versions) sends jobs here; this file builds frames, guides and overlays.
 *
 * Overlays are locked frames placed ON TOP of the deliverable frame as a
 * sibling, both inside a Section — so exporting the frame never includes
 * the overlay. Nested frames (inside auto-layout etc.) get the overlay
 * inside instead, named "hide before export".
 */
var TAG = "SAFE ZONES";
var STORE_KEY = "feedproof.store";
var PD_KEY = "sz";

function solid(c, op) {
  return [{ type: "SOLID", color: { r: c[0], g: c[1], b: c[2] }, opacity: op == null ? 1 : op }];
}
function zoneColor(o, kind) { return o.colors[kind] || o.colors.ui; }
function fontSize(it) { return Math.max(14, Math.round(Math.min(it.w, it.h) * 0.026)); }
function px(v) { return Math.max(1, Math.round(v)); }

function needOverlay(it, o) {
  return o.mode !== "guides" || o.outline || (it.geo.crops && it.geo.crops.length > 0);
}

function guidesFor(g, o) {
  if (o.mode === "mask") return [];
  var out = [], i;
  for (i = 0; i < g.guidesX.length; i++) out.push({ axis: "X", offset: g.guidesX[i] });
  for (i = 0; i < g.guidesY.length; i++) out.push({ axis: "Y", offset: g.guidesY[i] });
  return out;
}

async function buildOverlay(it, o, nameSuffix) {
  var g = it.geo, i;
  var ov = figma.createFrame();
  ov.name = TAG + " - " + it.title + nameSuffix;
  ov.resize(it.w, it.h);
  ov.fills = [];
  ov.clipsContent = true;
  ov.setPluginData(PD_KEY, "overlay");
  var op = o.opacity / 100;

  if (o.mode !== "guides") {
    for (i = 0; i < g.zones.length; i++) {
      var z = g.zones[i];
      var r = figma.createRectangle();
      r.name = z.label || z.id;
      r.x = z.x; r.y = z.y;
      r.resize(px(z.w), px(z.h));
      r.fills = solid(zoneColor(o, z.kind), z.kind === "comfort" ? op * 0.7 : op);
      ov.appendChild(r);
    }
  }

  if (o.outline) {
    var sw = Math.max(2, Math.round(Math.min(it.w, it.h) / 360));
    var s = figma.createRectangle();
    s.name = "Safe area";
    s.x = g.safe.x; s.y = g.safe.y;
    s.resize(px(g.safe.w), px(g.safe.h));
    s.fills = [];
    s.strokes = solid(o.colors.safe);
    s.strokeWeight = sw;
    s.strokeAlign = "INSIDE";
    ov.appendChild(s);
  }

  for (i = 0; i < g.crops.length; i++) {
    var c = g.crops[i];
    var cr = figma.createRectangle();
    cr.name = c.label;
    cr.x = c.x; cr.y = c.y;
    cr.resize(px(c.w), px(c.h));
    cr.fills = [];
    cr.strokes = solid(c.color || o.colors.crop);
    cr.strokeWeight = 2;
    cr.strokeAlign = "INSIDE";
    cr.dashPattern = [24, 14];
    ov.appendChild(cr);
  }

  if (o.labels && o.mode !== "guides") {
    try {
      var font = { family: "Inter", style: "Bold" };
      await figma.loadFontAsync(font);
      var fs = fontSize(it);
      for (i = 0; i < g.zones.length; i++) {
        var zz = g.zones[i];
        if (!zz.label || zz.h < fs * 1.6 || zz.w < fs * 8) continue;
        var t = figma.createText();
        t.fontName = font;
        t.characters = zz.label;
        t.fontSize = fs;
        t.fills = solid([1, 1, 1]);
        t.x = zz.x + fs * 0.6; t.y = zz.y + fs * 0.5;
        var bg = figma.createRectangle();
        bg.name = "label background";
        bg.x = t.x - 4; bg.y = t.y - 2;
        bg.resize(px(t.width + 8), px(t.height + 4));
        bg.fills = solid([0, 0, 0], 0.55);
        ov.appendChild(bg);
        ov.appendChild(t);
        t.name = "label - " + zz.label;
      }
    } catch (e) { /* labels are optional */ }
  }

  ov.locked = true;
  return ov;
}

function freeSpotX() {
  var kids = figma.currentPage.children, maxX = null, i;
  for (i = 0; i < kids.length; i++) {
    var n = kids[i];
    if (typeof n.x !== "number" || typeof n.width !== "number") continue;
    var right = n.x + n.width;
    if (maxX === null || right > maxX) maxX = right;
  }
  return maxX === null ? 0 : Math.round(maxX + 400);
}

function selectedFrame() {
  var sel = figma.currentPage.selection;
  for (var i = 0; i < sel.length; i++) {
    var n = sel[i];
    if (n.type === "FRAME" || n.type === "COMPONENT" || n.type === "INSTANCE") return n;
  }
  return null;
}

async function create(job) {
  var o = job.opts, x = freeSpotX(), frames = [], sections = [], i;
  for (i = 0; i < job.items.length; i++) {
    var it = job.items[i];
    var frame = figma.createFrame();
    frame.name = it.name;
    frame.resize(it.w, it.h);
    frame.fills = solid([1, 1, 1]);
    frame.guides = guidesFor(it.geo, o);

    var section = figma.createSection();
    section.name = it.name;
    section.appendChild(frame);
    frame.x = 0; frame.y = 0;
    if (needOverlay(it, o)) {
      var ov = await buildOverlay(it, o, " (not exported)");
      section.appendChild(ov);
      ov.x = 0; ov.y = 0;
    }
    section.resizeWithoutConstraints(it.w, it.h);
    section.x = x; section.y = 0;
    x += it.w + 200;
    frames.push(frame); sections.push(section);
  }
  figma.currentPage.selection = frames;
  figma.viewport.scrollAndZoomIntoView(sections);
  var n = job.items.length;
  return "OK|Created " + n + " frame" + (n > 1 ? "s" : "");
}

async function apply(job) {
  var f = selectedFrame();
  if (!f) return "ERR|Select a frame first.";
  var it = job.items[0], o = job.opts;
  if (f.type === "FRAME") {
    var existing = (f.guides || []).slice();
    f.guides = existing.concat(guidesFor(it.geo, o));
  }
  if (!needOverlay(it, o)) return "OK|Added guides to \"" + f.name + "\"";

  var parent = f.parent;
  var free = parent && (parent.type === "PAGE" || parent.type === "SECTION" ||
             (parent.type === "FRAME" && parent.layoutMode === "NONE"));
  if (free) {
    // sibling right above the frame: visible on canvas, never in the frame's export
    var ov = await buildOverlay(it, o, " (not exported)");
    var idx = parent.children.indexOf(f);
    parent.insertChild(idx + 1, ov);
    ov.x = f.x; ov.y = f.y;
    return "OK|Added " + it.title + " over \"" + f.name + "\" (not included in its export)";
  }
  // nested in auto-layout: put it inside, floating above the content
  var inner = await buildOverlay(it, o, " (hide before export)");
  f.appendChild(inner);
  if (f.layoutMode && f.layoutMode !== "NONE") inner.layoutPositioning = "ABSOLUTE";
  inner.x = 0; inner.y = 0;
  return "OK|Added " + it.title + " inside \"" + f.name + "\" — hide it before exporting";
}

function toggle() {
  var nodes = figma.currentPage.findAll(function (n) { return n.getPluginData(PD_KEY) === "overlay"; });
  if (!nodes.length) return "ERR|No Safe Zones overlays on this page.";
  var state = !nodes[0].visible;
  for (var i = 0; i < nodes.length; i++) nodes[i].visible = state;
  return "OK|" + (state ? "Showing " : "Hiding ") + nodes.length + " overlay" + (nodes.length > 1 ? "s" : "");
}

function size() {
  var f = selectedFrame();
  if (!f) return "NONE|Select a frame first.";
  return "OK|" + Math.round(f.width) + "|" + Math.round(f.height) + "|" + f.name;
}

// Evaluation guard: the panel already stops at expiry; the main thread refuses too.
async function licenseBlocks() {
  var cfg = globalThis.FP_LICENSE_CONFIG, L = globalThis.FPLicense;
  if (!cfg || !L || cfg.mode === "licensed") return null;
  var LIC = L.create(cfg), rec = null;
  try {
    var store = (await figma.clientStorage.getAsync(STORE_KEY)) || {};
    rec = L.parseRecord(store[LIC.storageKey]);
  } catch (e) {}
  if (!rec) return null;                       // panel hasn't recorded a first launch yet
  var st = LIC.load([rec]);
  return st.state === "expired" ? LIC.expiredMessage() : null;
}

async function runJob(job) {
  var blocked = await licenseBlocks();
  if (blocked) return "ERR|" + blocked;
  try {
    if (job.action === "size") return size();
    if (job.action === "create") return await create(job);
    if (job.action === "apply") return await apply(job);
    if (job.action === "toggle") return toggle();
    return "ERR|Unknown action: " + job.action;
  } catch (e) {
    return "ERR|" + (e && e.message ? e.message : String(e));
  }
}

figma.ui.onmessage = async function (msg) {
  if (!msg || typeof msg !== "object") return;
  if (msg.type === "job") {
    var result = await runJob(msg.job);
    var parts = String(result).split("|");
    if (parts[0] === "OK" && msg.job.action !== "size") figma.notify(parts.slice(1).join("|"));
    figma.ui.postMessage({ type: "result", id: msg.id, result: result });
  } else if (msg.type === "store") {
    try { await figma.clientStorage.setAsync(STORE_KEY, msg.data); } catch (e) {}
  } else if (msg.type === "open") {
    if (/^https:\/\//.test(msg.url)) figma.openExternal(msg.url);
  }
};

(async function start() {
  var store = {};
  try { store = (await figma.clientStorage.getAsync(STORE_KEY)) || {}; } catch (e) {}
  var literal = JSON.stringify(JSON.stringify(store));
  var html = __html__.replace('"__SZ_STORE__"', function () { return literal; });
  figma.showUI(html, { width: 340, height: 760, title: "Feedproof" });
})();
